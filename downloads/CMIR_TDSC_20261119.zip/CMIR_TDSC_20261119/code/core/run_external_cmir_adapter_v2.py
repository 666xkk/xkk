#!/usr/bin/env python3
"""Label-free node-output CMIR adapter for PIDSMaker results."""
import argparse, csv, json
from collections import defaultdict
from datetime import datetime
from pathlib import Path
from statistics import mean
from zoneinfo import ZoneInfo
import torch


def args():
    p=argparse.ArgumentParser()
    p.add_argument("--manifest",type=Path,required=True)
    p.add_argument("--output-dir",type=Path,required=True)
    p.add_argument("--node-top-k",type=int,default=10)
    p.add_argument("--window-budget",type=int,default=20)
    p.add_argument("--scales",type=int,nargs="+",default=[1,4])
    p.add_argument("--max-gap",type=int,default=2)
    p.add_argument("--top-score-count",type=int,default=3)
    p.add_argument("--timezone",default="America/New_York")
    p.add_argument("--attack-start",default="2018-04-11 13:54:00")
    p.add_argument("--attack-end",default="2018-04-11 14:48:00")
    p.add_argument("--velox-window-dir",type=Path)
    return p.parse_args()


def ns(text,tz):
    d=datetime.strptime(text,"%Y-%m-%d %H:%M:%S").replace(tzinfo=ZoneInfo(tz))
    return int(d.timestamp()*1_000_000_000)


def write(path,rows):
    path.parent.mkdir(parents=True,exist_ok=True)
    if not rows:return
    with path.open("w",newline="") as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)


def manifest(path):
    with path.open() as f: rows=list(csv.DictReader(f,delimiter="\t"))
    pairs={(r["model"],int(r["seed"])) for r in rows}
    expected={(m,s) for m in ("velox","magic","threatrace") for s in range(5)}
    if len(rows)!=15 or pairs!=expected: raise ValueError("manifest is not complete")
    return sorted(rows,key=lambda r:(r["model"],int(r["seed"])))


def filename_ns(text,tz):
    """Parse PIDSMaker's local timestamp with up to nanosecond precision."""
    stem=text.removesuffix(".csv")
    base,_,fraction=stem.partition(".")
    d=datetime.strptime(base,"%Y-%m-%d %H:%M:%S").replace(tzinfo=ZoneInfo(tz))
    return int(d.timestamp())*1_000_000_000+int((fraction+"000000000")[:9])


def windows(path,k,a0,a1,tz,velox_window_dir=None):
    data=torch.load(path,map_location="cpu",weights_only=False)
    groups=defaultdict(list)
    has_ranges=any(v.get("time_range") is not None for v in data.values())

    if not has_ranges:
        if velox_window_dir is None:
            raise ValueError(f"time ranges are absent and --velox-window-dir was not set: {path}")
        files=sorted(velox_window_dir.glob("*.csv"))
        if not files:
            raise ValueError(f"no CSV files in {velox_window_dir}")
        for v in data.values():
            tw=int(v.get("tw_with_max_loss",-1))
            if tw>=0: groups[tw].append(float(v["score"]))
        out=[]
        for tw,file in enumerate(files):
            parts=file.name.removesuffix(".csv").split("~")
            if len(parts)!=2: raise ValueError(f"invalid VELOX window filename: {file.name}")
            start,end=(filename_ns(x,tz) for x in parts)
            values=sorted(groups.get(tw,[]),reverse=True);used=min(k,len(values))
            out.append(dict(window=tw,start_ns=start,end_ns=end,nodes=len(values),
              node_top_k_used=used,raw_collective_score=mean(values[:used]) if used else 0.0,
              is_attack_window=(start<=a1 and end>=a0)))
        invalid=sorted(x for x in groups if x>=len(files))
        if invalid: raise ValueError(f"VELOX tw exceeds the {len(files)} filenames: {invalid[:10]}")
        return out

    for v in data.values():
        tr=v.get("time_range")
        if tr is not None and len(tr)==2 and tr[0] is not None and tr[1] is not None:
            groups[(int(tr[0]),int(tr[1]))].append(float(v["score"]))
    out=[]
    for i,((start,end),values) in enumerate(sorted(groups.items())):
        values.sort(reverse=True); used=min(k,len(values))
        out.append(dict(window=i,start_ns=start,end_ns=end,nodes=len(values),
          node_top_k_used=used,raw_collective_score=mean(values[:used]),
          is_attack_window=(start<=a1 and end>=a0)))
    if not out: raise ValueError(f"no valid windows: {path}")
    return out


def scale_rows(base,h,budget):
    raw=[x["raw_collective_score"] for x in base]
    scores=[mean(raw[max(0,i-h+1):i+1]) for i in range(len(raw))]
    order=sorted(range(len(base)),key=lambda i:(-scores[i],i))
    ranks={idx:r for r,idx in enumerate(order,1)}; den=max(1,len(base)-1)
    return [dict(**x,temporal_scale=h,causal_collective_score=scores[i],
      rank=ranks[i],rank_percentile=1-(ranks[i]-1)/den,
      selected=ranks[i]<=budget) for i,x in enumerate(base)]


def merge(scales):
    hs=sorted(scales); out=[]
    for i in range(len(scales[hs[0]])):
        b=scales[hs[0]][i]; chosen=[h for h in hs if scales[h][i]["selected"]]
        r=dict(window=b["window"],start_ns=b["start_ns"],end_ns=b["end_ns"],
          nodes=b["nodes"],raw_collective_score=b["raw_collective_score"],
          selected_scales=";".join(map(str,chosen)),scale_support=len(chosen),
          multiscale_score=max(scales[h][i]["rank_percentile"] for h in hs),
          selected=bool(chosen),is_attack_window=b["is_attack_window"])
        for h in hs:
            r[f"scale{h}_score"]=scales[h][i]["causal_collective_score"]
            r[f"scale{h}_rank"]=scales[h][i]["rank"]
            r[f"scale{h}_selected"]=scales[h][i]["selected"]
        out.append(r)
    return out


def incidents(rows,g,q):
    groups=[]
    for r in (x for x in rows if x["selected"]):
        if not groups or r["window"]-groups[-1][-1]["window"]>g:groups.append([r])
        else:groups[-1].append(r)
    out=[]
    for group in groups:
        vals=sorted((x["multiscale_score"] for x in group),reverse=True)
        used=min(q,len(vals))
        out.append(dict(start_window=group[0]["window"],end_window=group[-1]["window"],
          windows=";".join(str(x["window"]) for x in group),selected_windows=len(group),
          incident_score=mean(vals[:used]),scale_support=sum(x["scale_support"] for x in group),
          is_attack_incident=any(x["is_attack_window"] for x in group)))
    out.sort(key=lambda x:(-x["incident_score"],-x["scale_support"],x["start_window"]))
    for rank,x in enumerate(out,1):x["incident_rank"]=rank
    return out


def main():
    a=args();a0=ns(a.attack_start,a.timezone);a1=ns(a.attack_end,a.timezone);summary=[]
    for item in manifest(a.manifest):
        model=item["model"];seed=int(item["seed"]);path=Path(item["result_path"])
        base=windows(path,a.node_top_k,a0,a1,a.timezone,
          a.velox_window_dir if model=="velox" else None)
        sr={h:scale_rows(base,h,a.window_budget) for h in a.scales}
        multi=merge(sr); inc=incidents(multi,a.max_gap,a.top_score_count)
        root=a.output_dir/model
        for h,rows in sr.items():write(root/f"scale{h}"/f"window_scores_seed{seed}.csv",rows)
        write(root/"multiscale"/f"window_scores_seed{seed}.csv",multi)
        write(root/"multiscale"/f"incidents_seed{seed}.csv",inc)
        aw=sum(x["is_attack_window"] for x in multi)
        cw=sum(x["is_attack_window"] and x["selected"] for x in multi)
        ranks=[x["incident_rank"] for x in inc if x["is_attack_incident"]]
        selected=sum(x["selected"] for x in multi)
        summary.append(dict(model=model,seed=seed,windows=len(multi),selected_windows=selected,
          incidents=len(inc),attack_windows=aw,covered_attack_windows=cw,
          attack_window_recall=cw/aw if aw else 0,attack_episodes=1,
          covered_attack_episodes=int(bool(ranks)),attack_episode_recall=float(bool(ranks)),
          attack_incident_ranks=";".join(map(str,ranks)),
          window_reduction_ratio=1-len(inc)/max(1,selected),result_path=str(path)))
        print(f"{model} seed={seed} windows={len(multi)} selected={selected} "
              f"incidents={len(inc)} episode_recall={float(bool(ranks)):.1f}")
    write(a.output_dir/"per_seed.csv",summary)
    cfg={k:(str(v) if isinstance(v,Path) else v) for k,v in vars(a).items()}
    cfg.update(attack_start_ns=a0,attack_end_ns=a1)
    (a.output_dir/"run_config.json").write_text(json.dumps(cfg,indent=2)+"\n")


if __name__=="__main__":main()
