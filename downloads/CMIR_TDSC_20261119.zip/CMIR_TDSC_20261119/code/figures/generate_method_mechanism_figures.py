#!/usr/bin/env python3
"""Generate three IEEE-TDSC-style CMIR mechanism diagrams.

Run from the repository root:
    python TDSC/generate_method_mechanism_figures.py

The deterministic numbers are explanatory examples of the exact equations,
not additional experimental observations. Primary parameters are K=10,
H={1,4}, B=20 per scale, g=2, and q=3.
"""
from pathlib import Path
import argparse
import os

# Keep Matplotlib/font caches inside a writable location on servers whose home
# directory is read-only. Users may override this variable before execution.
os.environ.setdefault("MPLCONFIGDIR", "/tmp/cmir-matplotlib")
os.environ.setdefault("XDG_CACHE_HOME", "/tmp/cmir-cache")

import matplotlib as mpl
import matplotlib.pyplot as plt
import numpy as np
from matplotlib.patches import FancyArrowPatch, FancyBboxPatch, Rectangle

mpl.rcParams.update({
    "font.family": "serif",
    "font.serif": ["Times New Roman", "Times", "Nimbus Roman", "Liberation Serif", "DejaVu Serif"],
    "mathtext.fontset": "stix", "font.size": 9, "axes.titlesize": 10,
    "axes.labelsize": 9, "xtick.labelsize": 8, "ytick.labelsize": 8,
    "legend.fontsize": 8, "pdf.fonttype": 42, "ps.fonttype": 42,
    "figure.facecolor": "white", "axes.facecolor": "white",
    "savefig.facecolor": "white",
})

NAVY, BLUE, ORANGE = "#1F4E79", "#4C78A8", "#F28E2B"
GREEN, RED, PURPLE = "#2A9D8F", "#D1495B", "#7A5195"
LBLUE, LORANGE, LGREEN = "#DCEAF7", "#FBE4C6", "#D8EFEA"
LGRAY, DARK, GRAY = "#EEF1F4", "#20262E", "#7B8794"


def box(ax, xy, w, h, text="", fc="white", ec=DARK, lw=1.0,
        fs=8.2, weight="normal", radius=0.035):
    p = FancyBboxPatch(xy, w, h, boxstyle=f"round,pad=0.012,rounding_size={radius}",
                       facecolor=fc, edgecolor=ec, linewidth=lw, zorder=2)
    ax.add_patch(p)
    ax.text(xy[0]+w/2, xy[1]+h/2, text, ha="center", va="center",
            fontsize=fs, fontweight=weight, color=DARK, zorder=3)
    return p


def arrow(ax, a, b, color=DARK, lw=1.2):
    p = FancyArrowPatch(a, b, arrowstyle="-|>", mutation_scale=11,
                        linewidth=lw, color=color, shrinkA=2, shrinkB=2, zorder=5)
    ax.add_patch(p)


def panel(ax, label):
    ax.text(.005, .985, label, transform=ax.transAxes, ha="left", va="top",
            fontsize=10, fontweight="bold", color=DARK)


def save(fig, out, stem, dpi):
    out.mkdir(parents=True, exist_ok=True)
    for ext in ("pdf", "png"):
        path = out / f"{stem}.{ext}"
        kw = {"dpi": dpi} if ext == "png" else {}
        fig.savefig(path, bbox_inches="tight", pad_inches=.04, **kw)
        print(f"generated: {path}")
    plt.close(fig)


def collective(out, dpi):
    fig, axs = plt.subplots(1, 3, figsize=(7.16, 2.65))
    fig.subplots_adjust(wspace=.24, left=.025, right=.99, top=.86, bottom=.13)

    ax = axs[0]; panel(ax, "(a)"); ax.set(xlim=(0,1), ylim=(0,1)); ax.axis("off")
    ax.text(.5,.96,"Frozen edge losses in window $t$",ha="center",va="top",fontweight="bold")
    rows=[("process $p_1$","file $f_1$",.91,RED),("process $p_2$","file $f_1$",.38,GRAY),
          ("process $p_3$","file $f_2$",.78,ORANGE),("process $p_4$","file $f_3$",.74,ORANGE),
          ("process $p_5$","file $f_4$",.69,ORANGE),("process $p_6$","file $f_5$",.12,GRAY)]
    for y,(src,dst,loss,c) in zip(np.linspace(.80,.18,6),rows):
        box(ax,(.01,y-.038),.31,.076,src,LGRAY,"#AAB2BB",fs=7.1)
        box(ax,(.68,y-.038),.28,.076,dst,LBLUE,BLUE,fs=7.1)
        arrow(ax,(.33,y),(.67,y),c,1.3)
        ax.text(.50,y+.022,fr"$\ell={loss:.2f}$",ha="center",va="bottom",fontsize=7,color=c)
    ax.text(.5,.045,"Inspect source and destination roles",ha="center",fontsize=7.1,color=GRAY)

    ax=axs[1]; panel(ax,"(b)"); ax.set(xlim=(0,1),ylim=(0,1)); ax.axis("off")
    ax.text(.5,.96,"Role-aware node projection",ha="center",va="top",fontweight="bold")
    vals=[("$f_1$",.91),("$f_2$",.78),("$f_3$",.74),("$f_4$",.69),("$f_5$",.12)]
    for y,(name,val) in zip(np.linspace(.78,.22,5),vals):
        box(ax,(.05,y-.045),.20,.09,name,LBLUE,BLUE,weight="bold")
        ax.add_patch(Rectangle((.32,y-.028),.57,.056,facecolor="#E3E7EB",edgecolor="none"))
        c=RED if val>=.85 else (ORANGE if val>=.60 else GRAY)
        ax.add_patch(Rectangle((.32,y-.028),.57*val,.056,facecolor=c,edgecolor="none"))
        ax.text(.92,y,f"{val:.2f}",ha="right",va="center",fontsize=7.5)
    ax.text(.5,.08,r"$a_{v,t}=\max_{e\ni v}\ell_{e,t}$",ha="center",fontsize=10,color=NAVY)

    ax=axs[2]; panel(ax,"(c)"); ax.set(xlim=(0,1),ylim=(0,1)); ax.axis("off")
    ax.text(.5,.96,"Sparse collective evidence",ha="center",va="top",fontweight="bold")
    box(ax,(.08,.60),.84,.20,r"Top-$K$ file evidence"+"\n"+r"$0.91,\;0.78,\;0.74,\;0.69$",
        LORANGE,ORANGE,1.3,8.4,"bold")
    arrow(ax,(.5,.59),(.5,.43),NAVY,1.5)
    box(ax,(.13,.22),.74,.19,r"$r_t=\frac{1}{k_t}\sum_{i=1}^{k_t}a_{(i),t}$"+"\n"+r"$=0.780$",
        LGREEN,GREEN,1.4,9.2,"bold")
    ax.text(.5,.09,"Coordinated weak evidence survives volume dilution",ha="center",fontsize=7.1,color=GRAY)
    fig.suptitle("Role-Aware Collective Evidence Mechanism",y=.99,fontsize=11,fontweight="bold")
    save(fig,out,"fig10_collective_evidence_mechanism",dpi)


def multiscale(out,dpi):
    fig=plt.figure(figsize=(7.16,4.45))
    gs=fig.add_gridspec(3,1,height_ratios=[1.30,1.35,1.00],hspace=.62,
                        top=.91,bottom=.08,left=.08,right=.98)
    t=np.arange(1,13)
    raw=np.array([.15,.18,.22,.93,.28,.34,.49,.61,.66,.63,.31,.19])
    s4=np.array([raw[max(0,i-3):i+1].mean() for i in range(len(raw))])

    ax=fig.add_subplot(gs[0]); panel(ax,"(a)")
    ax.plot(t,raw,color=BLUE,marker="o",ms=4.5,lw=1.5,label=r"Scale 1: $c_t^{(1)}=r_t$")
    ax.plot(t,s4,color=ORANGE,marker="s",ms=4,lw=1.5,label="Scale 4: trailing mean")
    ax.axvline(8.5,color=GRAY,ls="--",lw=1); ax.axvspan(9,12.45,color=LGRAY,alpha=.85)
    ax.annotate(r"$c_8^{(4)}$ uses windows 5--8 only",xy=(8,s4[7]),xytext=(4.4,.84),
                arrowprops=dict(arrowstyle="->",color=ORANGE,lw=1.1),fontsize=8)
    ax.text(10.6,.84,"future windows\nexcluded",ha="center",va="center",fontsize=8,color=GRAY)
    ax.set(xlim=(.6,12.4),ylim=(0,1.02),ylabel="causal score",xlabel="immutable window index $t$")
    ax.set_xticks(t); ax.grid(axis="y",color="#D8DDE3",lw=.6)
    ax.legend(loc="upper right",frameon=False,ncol=1,fontsize=7.4,
              handlelength=1.8,labelspacing=.25)
    ax.spines[["top","right"]].set_visible(False)

    r1=np.argsort(np.argsort(-raw))+1; r4=np.argsort(np.argsort(-s4))+1
    p1=1-(r1-1)/(len(t)-1); p4=1-(r4-1)/(len(t)-1)
    demo=3; sel1=set(np.argsort(-raw)[:demo]+1); sel4=set(np.argsort(-s4)[:demo]+1)
    ax=fig.add_subplot(gs[1]); panel(ax,"(b)")
    ax.plot(t,p1,color=BLUE,marker="o",lw=1.3,label="Scale-1 rank percentile")
    ax.plot(t,p4,color=ORANGE,marker="s",lw=1.3,label="Scale-4 rank percentile")
    for w in sel1: ax.scatter(w,p1[w-1],s=80,facecolors="none",edgecolors=BLUE,lw=1.5,zorder=5)
    for w in sel4: ax.scatter(w,p4[w-1],s=90,facecolors="none",edgecolors=ORANGE,lw=1.5,marker="s",zorder=5)
    ax.text(.99,.05,"rings: illustrative Top-3 per scale\nprimary experiment: Top-20",
            transform=ax.transAxes,ha="right",va="bottom",fontsize=7.4,color=GRAY)
    ax.set(xlim=(.6,12.4),ylim=(-.04,1.08),ylabel=r"rank percentile $p_t^{(h)}$",xlabel="window index $t$")
    ax.set_xticks(t); ax.grid(axis="y",color="#D8DDE3",lw=.6)
    ax.legend(loc="upper left",frameon=False,ncol=1,fontsize=7.3,
              handlelength=1.8,labelspacing=.22)
    ax.spines[["top","right"]].set_visible(False)

    ax=fig.add_subplot(gs[2]); panel(ax,"(c)"); ax.set(xlim=(.4,12.6),ylim=(0,1)); ax.axis("off")
    union=sorted(sel1|sel4); ax.plot([1,12],[.52,.52],color=DARK,lw=1)
    for w in t:
        ax.plot([w,w],[.47,.57],color=DARK,lw=.8); ax.text(w,.36,str(w),ha="center",fontsize=7.5,color=GRAY)
    for w in union:
        n=int(w in sel1)+int(w in sel4); c=PURPLE if n==2 else (BLUE if w in sel1 else ORANGE)
        ax.scatter(w,.66,s=120,color=c,edgecolor="white",lw=.8,zorder=3)
        ax.text(w,.66,str(n),ha="center",va="center",color="white",fontsize=7,fontweight="bold",zorder=4)
    ax.text(.5,.91,r"Union $\widehat{\mathcal{W}}=\mathcal{S}_1\cup\mathcal{S}_4$; "
            r"$m_t=\max_h p_t^{(h)}$",
            transform=ax.transAxes,ha="center",fontsize=8.6,fontweight="bold")
    ax.text(.5,.10,"circle value = supporting scales; purple = agreement",
            transform=ax.transAxes,ha="center",fontsize=7.5,color=GRAY)
    fig.suptitle("Strictly Causal Multiscale Scoring and Rank Fusion",y=.995,fontsize=11,fontweight="bold")
    save(fig,out,"fig11_causal_multiscale_fusion",dpi)


def incidents(out,dpi):
    fig,axs=plt.subplots(2,1,figsize=(7.16,3.75),gridspec_kw={"height_ratios":[1,1.22]})
    fig.subplots_adjust(hspace=.30,left=.05,right=.98,top=.88,bottom=.09)
    groups=[[4,5],[8,9,10],[17]]; colors=[BLUE,ORANGE,GREEN]
    scores={4:.88,5:.81,8:.96,9:.84,10:.78,17:.73}
    support={4:2,5:1,8:2,9:2,10:1,17:1}

    ax=axs[0]; panel(ax,"(a)"); ax.set(xlim=(.4,18.2),ylim=(0,1)); ax.axis("off")
    ax.text(.5,.97,"Gap-based reconstruction ($g=2$)",transform=ax.transAxes,
            ha="center",va="top",fontweight="bold")
    ax.plot([1,18],[.40,.40],color=DARK,lw=1.1)
    for w in range(1,19):
        ax.plot([w,w],[.35,.45],color=DARK,lw=.7)
        ax.text(w,.25,str(w),ha="center",fontsize=7.2,color=GRAY)
    for idx,(grp,c) in enumerate(zip(groups,colors),1):
        left,right=min(grp)-.48,max(grp)+.48
        ax.add_patch(FancyBboxPatch((left,.51),right-left,.19,boxstyle="round,pad=.01,rounding_size=.07",
                                    facecolor=mpl.colors.to_rgba(c,.13),edgecolor=c,lw=1.1))
        ax.text((left+right)/2,.76,f"Incident {idx}",ha="center",fontsize=7.8,fontweight="bold",color=c)
        for w in grp:
            ax.scatter(w,.605,s=135,color=c,edgecolor="white",lw=.8,zorder=4)
            ax.text(w,.605,str(w),ha="center",va="center",fontsize=7,color="white",fontweight="bold",zorder=5)
    ax.text(6.5,.06,"gap $=3>g$",ha="center",fontsize=7.4,color=RED)
    ax.text(13.5,.06,"gap $=7>g$",ha="center",fontsize=7.4,color=RED)

    ax=axs[1]; panel(ax,"(b)"); ax.set(xlim=(0,1),ylim=(0,1)); ax.axis("off")
    ax.text(.5,.98,"Top-$q$ incident scoring ($q=3$) and final queue",ha="center",va="top",fontweight="bold")
    cards=[]
    for idx,(grp,c) in enumerate(zip(groups,colors),1):
        vals=sorted([scores[w] for w in grp],reverse=True)[:3]
        cards.append((idx,grp,float(np.mean(vals)),sum(support[w] for w in grp),c,vals))
    cards.sort(key=lambda x:(-x[2],-x[3],min(x[1])))
    for rank,(x,card) in enumerate(zip([.04,.36,.68],cards),1):
        idx,grp,sc,sup,c,vals=card
        box(ax,(x,.20),.28,.58,"",mpl.colors.to_rgba(c,.10),c,1.25)
        ax.text(x+.14,.71,f"Rank {rank}: Incident {idx}",ha="center",fontsize=8.5,fontweight="bold",color=c)
        ax.text(x+.14,.57,"windows: "+", ".join(map(str,grp)),ha="center",fontsize=7.6)
        ax.text(x+.14,.45,"Top-$q$: "+", ".join(f"{v:.2f}" for v in vals),ha="center",fontsize=7.4)
        ax.text(x+.14,.33,f"$S(I)={sc:.3f}$",ha="center",fontsize=9.2,fontweight="bold")
        ax.text(x+.14,.24,f"scale support = {sup}",ha="center",fontsize=7.3,color=GRAY)
    ax.text(.5,.07,"Selected-window coverage is unchanged; the analyst queue is compressed.",
            ha="center",fontsize=7.7,color=GRAY)
    fig.suptitle("Temporal Incident Reconstruction and Ranking",y=.99,fontsize=11,fontweight="bold")
    save(fig,out,"fig12_incident_reconstruction",dpi)


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument("--output-dir",type=Path,default=Path(__file__).resolve().parent)
    p.add_argument("--dpi",type=int,default=600)
    a=p.parse_args()
    collective(a.output_dir,a.dpi); multiscale(a.output_dir,a.dpi); incidents(a.output_dir,a.dpi)


if __name__ == "__main__":
    main()
