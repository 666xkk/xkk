# CMIR IEEE TDSC submission and reproducibility package

This package freezes the manuscript and the experiment summaries available on
2026-11-19. It intentionally excludes raw DARPA telemetry, database dumps,
model checkpoints, Python environments, and detector caches.

## Contents

- `CMIR_TDSC.tex`: final manuscript source.
- `TDSC/`: vector and raster paper figures.
- `data/`: frozen headline, external-detector, random-null, and runtime tables.
- `code/`: CMIR reconstruction, benchmark, ablation, and figure-generation code.
- `MANIFEST.sha256`: SHA-256 checksum for every packaged file.

## Important figure-transfer status

Figures `fig0` and `fig10`--`fig12` are included. Figures `fig1`--`fig9` were
generated on the experiment server but were not present in the transferred
files. The earlier figure archive contains only `fig0` and is therefore not
represented as a complete figure archive here.

Before journal upload, copy the PDF versions of `fig1`--`fig9` into the
manuscript's `TDSC/` path (and optionally retain PNG/SVG versions in this
package), then regenerate `MANIFEST.sha256`.

## Manuscript verification

The source contains 13 figure references, 8 tables, and 37 bibliography items.
Static checks found no undefined references, undefined citations, duplicate
labels, or placeholders. Full compilation requires the official `IEEEtran.cls`
from the TDSC template.

## Data interpretation

The exact native-budget null is retained alongside observed external-detector
composition. ThreaTrace attains five-seed episode recovery with joint tail
probability 0.057493; VELOX attains five-seed recovery with a broader attack
opportunity and joint probability 0.339075. MAGIC does not recover the episode
under the frozen budget.
