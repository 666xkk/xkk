# Paper 1 详细实验与消融指南

本文档对应修订版 ORTHRUS/Paper 1：泄漏封闭的事件组遮掩、时间桥采样、属性缺失建模和 collector/day 双域鲁棒性。命令应在仓库根目录、已准备 DARPA TC 数据的 `pids` 容器中执行。

## 1. 一次性准备与代码自检

```bash
cd /path/to/orthrus
# 完整训练环境按仓库 Dockerfile 构建；下面仅补充机制测试依赖
python -m pip install -r requirements-mechanisms.txt
PYTHON_BIN=python bash scripts/run_tdsc_checks.sh
```

通过标准：`test_paper1_masking_unit.py`、`test_paper2_mechanisms.py` 全部通过，且最后出现 `TDSC configuration and seed isolation: OK`。这些测试只证明机制和防泄漏约束正确，不代表检测效果。

首次运行某个数据集时不要使用 `--run_from_training`，让图构建和特征生成完成：

```bash
export PYTHONHASHSEED=0
python -u -m src.orthrus CADETS_E3 --model tdsc --seed=0 --train_only \
  --detection.gnn_training.num_epochs=1 --exp=PREP_CADETS_E3
```

对 `THEIA_E3`、`CLEARSCOPE_E3` 及 E5 数据重复。后续仅改变训练参数时可使用 `--run_from_training`；改变 `canonical_hash/Word2Vec`、图时间窗或节点字段时必须重新预处理，并使用独立 artifact 根目录，禁止复用旧特征。

## 2. 主实验：两阶段训练

所有主表至少使用 `SEEDS=(0 1 2 3 4)`。epoch、阈值和超参数只能在验证集上选择。测试集不能用于选择 checkpoint、阈值、遮掩率或损失权重。

### Stage 1：纯遮掩预训练

```bash
export PYTHONHASHSEED=0
DATASET=CADETS_E3
SEED=0
python -u -m src.orthrus "$DATASET" --model tdsc --run_from_training \
  --seed="$SEED" --train_only \
  --detection.gnn_training.num_epochs=20 \
  --detection.gnn_training.mask.enabled=true \
  --detection.gnn_training.mask.unit=unordered_pair \
  --detection.gnn_training.mask.mask_rate=0.15 \
  --detection.gnn_training.mask.sampling_prior=bridge \
  --detection.gnn_training.mask.base_type_loss_weight=0.0 \
  --detection.gnn_training.mask.type_loss_weight=1.0 \
  --detection.gnn_training.mask.link_loss_weight=1.0 \
  --detection.gnn_training.mask.time_loss_weight=0.1 \
  --exp="P1_FULL_${DATASET}_s${SEED}_stage1" \
  2>&1 | tee "runs/P1_FULL_${DATASET}_s${SEED}_stage1.log"
```

成功标志：日志中的 `[mask-config]` 与命令一致；每轮出现遮掩统计；`residual_arc_leak_count=0`；checkpoint 中含 `link_head` 和 `time_head`。记录本次运行生成的完整 `trained_models` 路径，不要用“最新目录”替代已记录路径。

可以先用一个批次级冒烟测试验证真实数据路径：

```bash
PYTHONPATH=. python tools/mask_smoke.py CADETS_E3 --model tdsc --cpu
```

### Stage 2：加载 Stage 1，关闭遮掩并训练/评估主任务

```bash
S1_DIR=/absolute/path/to/the/matching/trained_models
DATASET=CADETS_E3
SEED=0
python -u -m src.orthrus "$DATASET" --model tdsc --run_from_training \
  --seed="$SEED" \
  --detection.gnn_training.num_epochs=20 \
  --detection.gnn_training.pretrained_dir="$S1_DIR" \
  --detection.gnn_training.mask.enabled=false \
  --detection.evaluation.node_evaluation.threshold_method=max_val_loss \
  --detection.evaluation.node_evaluation.use_kmeans=false \
  --exp="P1_FULL_${DATASET}_s${SEED}_stage2" \
  2>&1 | tee "runs/P1_FULL_${DATASET}_s${SEED}_stage2.log"
```

成功标志：日志明确出现 `[pretrain] loaded`、加载的兼容 tensor 数量、验证集选出的 best epoch，以及测试评估目录。Stage 1 和 Stage 2 的 dataset、seed、特征布局和模型维度必须一致。

## 3. 主实验矩阵

在以下数据集运行五个种子：`CADETS_E3`、`THEIA_E3`、`CLEARSCOPE_E3`、`CADETS_E5`、`THEIA_E5`、`CLEARSCOPE_E5`。每个运行保存命令、git commit、配置、随机种子、checkpoint hash、验证 epoch、阈值和原始逐节点结果。

每个 dataset/seed 至少报告 AP、ROC-AUC、MCC、Precision、Recall、F1、FPR、固定 Recall 下 FPR、TP/FP/TN/FN。主表给出均值、标准差和按 dataset/seed 配对的 95% CI；同时报告绝对 FP 数。

## 4. 机制消融

除被消融参数外，数据划分、预算、epoch 选择和阈值规则完全一致。以下每条命令中的公共参数可以定义为：

```bash
COMMON="--model tdsc --run_from_training --train_only --detection.gnn_training.num_epochs=20 --detection.gnn_training.mask.enabled=true --detection.gnn_training.mask.mask_rate=0.15 --detection.gnn_training.mask.base_type_loss_weight=0.0"
```

### A. 遮掩粒度与泄漏

```bash
for UNIT in entry directed_typed unordered_pair; do
  python -u -m src.orthrus CADETS_E3 --seed=0 $COMMON \
    --detection.gnn_training.mask.unit="$UNIT" \
    --detection.gnn_training.mask.sampling_prior=uniform \
    --exp="ABL_UNIT_${UNIT}"
done
```

`entry` 是允许同组副本暴露的负对照；`unordered_pair` 是主方法。必须同时报告 `residual_arc_leak_count`、`residual_arc_leak_frac`、`triple_dup_frac`、实际被遮掩 group/event 比例。主方法的 residual leak 必须为 0。

### B. 采样先验

```bash
for PRIOR in uniform temporal hard bridge; do
  python -u -m src.orthrus CADETS_E3 --seed=0 $COMMON \
    --detection.gnn_training.mask.unit=unordered_pair \
    --detection.gnn_training.mask.sampling_prior="$PRIOR" \
    --exp="ABL_PRIOR_${PRIOR}"
done
```

bridge 臂额外报告 `bridge_eligible_frac`、`bridge_mean_masked`、`bridge_mean_ctx` 和 `bridge_top_frac`，并验证 gap 只由训练前缀计算。主比较为 bridge 对 uniform；temporal 与 hard 是补充比较。

### C. 恢复目标

```bash
# masked type only
python -u -m src.orthrus CADETS_E3 --seed=0 $COMMON \
  --detection.gnn_training.mask.type_loss_weight=1.0 \
  --detection.gnn_training.mask.link_loss_weight=0.0 \
  --detection.gnn_training.mask.time_loss_weight=0.0 --exp=ABL_OBJ_TYPE
# link only
python -u -m src.orthrus CADETS_E3 --seed=0 $COMMON \
  --detection.gnn_training.mask.type_loss_weight=0.0 \
  --detection.gnn_training.mask.link_loss_weight=1.0 \
  --detection.gnn_training.mask.time_loss_weight=0.0 --exp=ABL_OBJ_LINK
# time only
python -u -m src.orthrus CADETS_E3 --seed=0 $COMMON \
  --detection.gnn_training.mask.type_loss_weight=0.0 \
  --detection.gnn_training.mask.link_loss_weight=0.0 \
  --detection.gnn_training.mask.time_loss_weight=1.0 --exp=ABL_OBJ_TIME
# full
python -u -m src.orthrus CADETS_E3 --seed=0 $COMMON \
  --detection.gnn_training.mask.type_loss_weight=1.0 \
  --detection.gnn_training.mask.link_loss_weight=1.0 \
  --detection.gnn_training.mask.time_loss_weight=0.1 --exp=ABL_OBJ_FULL
```

另加“无 Stage 1”对照：直接用同一 Stage 2 配置从随机初始化训练，且不提供 `pretrained_dir`。

### D. 遮掩率与负样本数

```bash
for RATE in 0.05 0.10 0.15 0.25 0.40; do
  for NEG in 1 5 10 20; do
    python -u -m src.orthrus CADETS_E3 --seed=0 $COMMON \
      --detection.gnn_training.mask.mask_rate="$RATE" \
      --detection.gnn_training.mask.link_negatives="$NEG" \
      --detection.gnn_training.mask.unit=unordered_pair \
      --detection.gnn_training.mask.sampling_prior=bridge \
      --exp="ABL_RATE_${RATE}_NEG_${NEG}"
  done
done
```

该网格只在验证集选定；主测试只运行冻结后的一个组合，避免 test-set tuning。

### E. 属性层与缺失值

```bash
for MODE in structure attributes both; do
  python -u -m src.orthrus CADETS_E3 --model tdsc --run_from_training --seed=0 \
    --detection.gnn_training.encoder.node_feature_mode="$MODE" \
    --exp="ABL_FEATURE_${MODE}"
done

# 关闭 missingness 后特征布局改变，必须重新预处理到独立 artifact
python -u -m src.orthrus CADETS_E3 --model tdsc --seed=0 \
  --edge_featurization.embed_edges.add_missingness=false --exp=ABL_NO_MISSINGNESS

# 原始 per-collector Word2Vec 对照，也需独立重新预处理
python -u -m src.orthrus CADETS_E3 --model orthrus --seed=0 --exp=ABL_WORD2VEC
```

报告不同 collector 之间相同 token 的坐标一致性检查，以及 0/20/40/60/80% 属性删除曲线。

### F. collector/day 域鲁棒性

```bash
python -u -m src.orthrus CADETS_E3 --model tdsc --run_from_training --seed=0 \
  --detection.gnn_training.domain_invariance.enabled=false --exp=ABL_DANN_OFF

for DOMAIN in collector day both; do
  python -u -m src.orthrus CADETS_E3 --model tdsc --run_from_training --seed=0 \
    --detection.gnn_training.domain_invariance.enabled=true \
    --detection.gnn_training.domain_invariance.domain_label="$DOMAIN" \
    --exp="ABL_DANN_${DOMAIN}"
done

for DROP in 0.0 0.1 0.2 0.4; do
  python -u -m src.orthrus CADETS_E3 --model tdsc --run_from_training --seed=0 \
    --detection.gnn_training.domain_invariance.attr_dropout="$DROP" \
    --exp="ABL_ATTRDROP_${DROP}"
done
```

## 5. Leave-one-collector-out

训练源域时只列源 collector。例如以 CLEARSCOPE 为目标域：

```bash
python -u -m src.orthrus CADETS_E3 --model tdsc --run_from_training --seed=0 \
  --detection.gnn_training.multi_domain=THEIA_E3,CADETS_E3 \
  --exp=LOCO_HOLDOUT_CLEARSCOPE

python -u -m src.orthrus CLEARSCOPE_E3 --model tdsc --test_only \
  --checkpoint_dir /absolute/path/to/source/trained_models \
  --detection.gnn_training.multi_domain=THEIA_E3,CADETS_E3 \
  --seed=0 --exp=LOCO_HOLDOUT_CLEARSCOPE_EVAL
```

轮换 CADETS、THEIA、CLEARSCOPE 为目标。目标 collector 不得参与 feature fitting、mask gap 统计、checkpoint 选择或源模型训练。

## 6. 鲁棒性、效率和统计

- 属性随机删除：0、20、40、60、80%。
- 时间戳 jitter：0、1、5、30、60 秒。
- 重复事件注入：0、1、2、5、10 倍。
- 自适应攻击：高频属性替换与 burst event。
- 效率：相同 GPU、batch size 和输入，报告训练时间、推理时间、峰值显存、参数量、events/s。

主方法与最强基线使用相同 dataset/seed 的配对差值，按 day/trace 做 block bootstrap 95% CI。多项主比较使用 Holm 校正，或在看测试结果前指定唯一主指标和主数据集。禁止只汇报最佳种子。

## 7. 结果验收

论文核心主张至少需要同时满足：`unordered_pair` 的残余泄漏为零；bridge 相对 uniform 在多个 collector/seed 上有稳定增益；full method 在 LOCO 上优于无 canonical/DANN 的匹配对照；增益在固定阈值协议和配对置信区间下仍成立；效率代价被完整披露。若任一条件失败，应缩小主张，而不能仅凭机制测试宣称达到高水平期刊标准。
