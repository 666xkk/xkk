from src.provnet_utils import *
from src.config import *
import torch
import torch.nn as nn
from torch_geometric.nn import SAGEConv, GATConv, TransformerConv
from torch_geometric.utils import scatter

from src.masking import StreamTimeTracker


class GraphTransformer(nn.Module):
    def __init__(self, in_dim, hid_dim, out_dim, edge_dim, dropout, activation, num_heads):
        super(GraphTransformer, self).__init__()
        self.conv = TransformerConv(in_dim, hid_dim, heads=num_heads, dropout=dropout, edge_dim=edge_dim)
        self.conv2 = TransformerConv(hid_dim * num_heads, out_dim, heads=1, concat=False, dropout=dropout, edge_dim=edge_dim)
        self.dropout = nn.Dropout(dropout)
        self.activation = activation

    def forward(self, x, edge_index, edge_feats=None, **kwargs):
        x = self.activation(self.conv(x, edge_index, edge_feats))
        x = self.dropout(x)
        x = self.conv2(x, edge_index, edge_feats)
        return x


class GATEncoder(nn.Module):
    def __init__(self, in_dim, hid_dim, out_dim, edge_dim, dropout, activation, num_heads):
        super(GATEncoder, self).__init__()
        self.conv = GATConv(in_dim, hid_dim, heads=num_heads, dropout=dropout, edge_dim=edge_dim)
        self.conv2 = GATConv(hid_dim * num_heads, out_dim, heads=1, concat=False, dropout=dropout, edge_dim=edge_dim)
        self.dropout = nn.Dropout(dropout)
        self.activation = activation

    def forward(self, x, edge_index, edge_feats=None, **kwargs):
        x = self.activation(self.conv(x, edge_index, edge_feats))
        x = self.dropout(x)
        x = self.conv2(x, edge_index, edge_feats)
        return x


class SAGEEncoder(nn.Module):
    """Edge-aware GraphSAGE.

    Vanilla SAGEConv cannot consume edge features. To keep the backbone
    ablation fair, edge features are summarized per TARGET node and added to
    the initial node features before two SAGE layers.
    """

    def __init__(self, in_dim, hid_dim, out_dim, edge_dim=None, dropout=0.0, activation=None, num_heads=None):
        super(SAGEEncoder, self).__init__()
        self.conv = SAGEConv(in_dim, hid_dim)
        self.conv2 = SAGEConv(hid_dim, out_dim)
        self.dropout = nn.Dropout(dropout)
        self.activation = activation if activation is not None else nn.ReLU()
        self.edge_proj = nn.Linear(edge_dim, in_dim) if edge_dim else None

    def forward(self, x, edge_index, edge_feats=None, **kwargs):
        if self.edge_proj is not None and edge_feats is not None and edge_index.numel() > 0:
            edge_msg = scatter(edge_feats, edge_index[1], dim=0, dim_size=x.size(0), reduce="mean")
            x = x + self.edge_proj(edge_msg)
        x = self.activation(self.conv(x, edge_index))
        x = self.dropout(x)
        x = self.conv2(x, edge_index)
        return x


class LinearEncoder(nn.Module):
    """Graph-agnostic linear backbone (VELOX-style lower bound)."""

    def __init__(self, in_dim, hid_dim=None, out_dim=None, edge_dim=None, dropout=0.0, activation=None, num_heads=None):
        super(LinearEncoder, self).__init__()
        self.lin = nn.Linear(in_dim, out_dim)

    def forward(self, x, edge_index, edge_feats=None, **kwargs):
        return self.lin(x)


class OrthrusEncoder(nn.Module):
    def __init__(
        self,
        encoder,
        neighbor_loader,
        in_dim,
        temporal_dim,
        use_node_feats_in_gnn,
        graph_reindexer,
        edge_features,
        device,
        num_nodes,
        edge_dim,
        use_time_features=False,
        masker=None,
        link_negatives=5,
    ):
        super(OrthrusEncoder, self).__init__()
        self.encoder = encoder
        self.neighbor_loader = neighbor_loader
        self.device = device
        self.assoc = torch.empty(num_nodes, dtype=torch.long, device=device)
        self.num_nodes = num_nodes

        self.edge_features = edge_features
        self.use_node_feats_in_gnn = use_node_feats_in_gnn
        if self.use_node_feats_in_gnn:
            self.src_linear = nn.Linear(in_dim, temporal_dim)
            self.dst_linear = nn.Linear(in_dim, temporal_dim)

        self.graph_reindexer = graph_reindexer

        # --- Paper 1: context-event masked modeling ---
        self.masker = masker
        self.link_negatives = link_negatives
        self.stream_tracker = StreamTimeTracker(num_nodes=num_nodes, device=device)
        self.use_time_features = use_time_features
        self._mask_lookup = None          # transient bool tensor, per forward

        # exposed for tests / debugging
        self.last_all_e_id = None
        self.last_visible_e_id = None

    # ---------------------------------------------------------------- helpers
    def _ensure_lookup_capacity(self, needed):
        if self._mask_lookup is not None and self._mask_lookup.numel() >= needed:
            return
        cap = needed if self._mask_lookup is None else self._mask_lookup.numel()
        while cap < needed:
            cap *= 2
        self._mask_lookup = torch.zeros(max(cap, 1), dtype=torch.bool, device=self.device)

    def _sample_negatives(self, visible_edge_index, u_local, v_local, num_nodes):
        """Filtered uniform negatives for (u, v) pairs.
        Excluded: the true destination v, u itself, and any node adjacent to u
        in the VISIBLE context graph (either direction) -> no false negatives.
        Returns (neg_local [m, K], neg_valid [m, K])."""
        m = u_local.numel()
        K = self.link_negatives
        if m == 0 or K <= 0 or num_nodes < 3:
            return None, None
        K = min(K, num_nodes - 2)
        cand = torch.randint(0, num_nodes, (m, K), device=self.device)
        cand = torch.where(cand == u_local.unsqueeze(1), (cand + 1) % num_nodes, cand)

        if visible_edge_index.numel() > 0:
            a = visible_edge_index[0].long()
            b = visible_edge_index[1].long()
            keys_ab = torch.sort(a * num_nodes + b).values
            keys_ba = torch.sort(b * num_nodes + a).values
            q = u_local.unsqueeze(1) * num_nodes + cand
            adjacent = self._contains(keys_ab, q) | self._contains(keys_ba, q)
        else:
            adjacent = torch.zeros_like(cand, dtype=torch.bool)

        neg_valid = (~adjacent) & (cand != v_local.unsqueeze(1))
        return cand, neg_valid

    @staticmethod
    def _contains(sorted_keys, query):
        if sorted_keys.numel() == 0:
            return torch.zeros_like(query, dtype=torch.bool)
        idx = torch.searchsorted(sorted_keys, query).clamp(max=sorted_keys.numel() - 1)
        return sorted_keys[idx] == query

    # ---------------------------------------------------------------- forward
    def forward(self, edge_index, t, msg, x, full_data, inference=False, edge_types=None, **kwargs):
        src, dst = edge_index
        x_src, x_dst = x
        batch_edge_index = edge_index.clone()

        # 1) temporal context
        n_id = torch.cat([src, dst]).unique()
        n_id, ctx_edge_index, e_id = self.neighbor_loader(n_id)
        self.assoc[n_id] = torch.arange(n_id.size(0), device=self.device)
        self.last_all_e_id = e_id

        # 2) leak-tight ARC-GROUP masking (v2): sample unordered pairs {u,v}
        #    and remove ALL their events (both directions) from THIS forward.
        recovery = None
        masked_eids = dt_m = dt_valid_m = None
        self._last_mask_stats = {}
        if self.masker is not None and not inference and e_id.numel() > 0:
            e_id_cpu = e_id.cpu()
            u = full_data.src[e_id_cpu].to(self.device).long()
            v = full_data.dst[e_id_cpu].to(self.device).long()
            lo = torch.minimum(u, v)
            hi = torch.maximum(u, v)
            arc_key = lo * self.num_nodes + hi
            out = self.masker.sample(e_id, arc_key,
                                     self.stream_tracker.event_dt,
                                     self.stream_tracker.event_dt_valid)
            keep = out["keep"]
            if not bool(keep.all()):
                ctx_edge_index = ctx_edge_index[:, keep]
                e_id = e_id[keep]
            if out["masked_eids"].numel() > 0:
                masked_eids = out["masked_eids"]
                dt_m, dt_valid_m = out["dt"], out["dt_valid"]
                self._last_mask_stats = {
                    "n_groups_masked": int(masked_eids.numel()),
                    "frac_groups_with_dups": float((out["group_size"] > 1).float().mean()),
                }
        self.last_visible_e_id = e_id

        # 3) node features
        x_src, x_dst = self.graph_reindexer.node_features_reshape(
            batch_edge_index, x_src, x_dst, max_num_node=n_id.max())
        x_proj = self.src_linear(x_src[n_id]) + self.dst_linear(x_dst[n_id])
        h = x_proj

        # 4) edge features of the VISIBLE context
        edge_feats = []
        if "edge_type" in self.edge_features:
            edge_feats.append(full_data.edge_type[e_id.cpu()].to(self.device))
        if "msg" in self.edge_features:
            edge_feats.append(full_data.msg[e_id.cpu()].to(self.device))
        if self.use_time_features and e_id.numel() > 0:
            dt_ctx = self.stream_tracker.event_dt[e_id]              # seconds
            edge_feats.append(torch.log1p(dt_ctx).unsqueeze(-1))
        edge_feats = torch.cat(edge_feats, dim=-1) if len(edge_feats) > 0 else None

        # 5) GNN forward (masked events are not in ctx_edge_index)
        h = self.encoder(h, ctx_edge_index, edge_feats=edge_feats)

        h_src = h[self.assoc[src]]
        h_dst = h[self.assoc[dst]]

        # 6) insert AFTER computing embeddings; update stream time state
        new_e_ids = self.neighbor_loader.insert(src, dst)
        self.stream_tracker.observe(src, dst, t,
                                    self.neighbor_loader.last_insert_first_e_id,
                                    self.neighbor_loader.cur_e_id)

        # 7) recovery payload for masked context events
        if masked_eids is not None and masked_eids.numel() > 0:
            u = full_data.src[masked_eids.cpu()].to(self.device)
            v = full_data.dst[masked_eids.cpu()].to(self.device)
            u_local, v_local = self.assoc[u], self.assoc[v]
            h_u, h_v = h[u_local], h[v_local]

            neg_local, neg_valid = self._sample_negatives(ctx_edge_index, u_local, v_local, n_id.numel())
            h_neg = h[neg_local] if neg_local is not None else None

            recovery = {
                "masked_eids": masked_eids,
                "h_u": h_u,
                "h_v": h_v,
                "h_neg": h_neg,
                "neg_valid": neg_valid,
                "edge_type": full_data.edge_type[masked_eids.cpu()].to(self.device),
                "dt": dt_m,
                "dt_valid": dt_valid_m,
            }

        return h_src, h_dst, recovery

    def reset_state(self):
        self.neighbor_loader.reset_state()
        self.stream_tracker.reset()