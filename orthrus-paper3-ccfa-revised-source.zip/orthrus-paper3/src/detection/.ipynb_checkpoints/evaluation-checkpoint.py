import os
import wandb
import numpy as np
from collections import defaultdict
from pprint import pprint

from src.config import get_runtime_required_args, get_yml_cfg
from . import node_evaluation
from src.data_utils import *
from src.provnet_utils import log, listdir_sorted
from .evaluation_utils import *


def standard_evaluation(cfg, evaluation_fn):
    test_losses_dir = os.path.join(cfg.detection.gnn_testing._edge_losses_dir, "test")
    val_losses_dir = os.path.join(cfg.detection.gnn_testing._edge_losses_dir, "val")

    tw_to_malicious_nodes = compute_tw_labels(cfg)

    # ---- [protocol] epoch selection uses VALIDATION loss ONLY (no test leakage)
    best_epoch, best_val_loss = select_epoch_by_val_loss(val_losses_dir)
    log(f"[protocol] epoch selected by val loss: {best_epoch} ({best_val_loss:.4f})")

    all_stats = {}
    for model_epoch_dir in listdir_sorted(test_losses_dir):
        log(f"\nEvaluation of model {model_epoch_dir}...")
        test_tw_path = os.path.join(test_losses_dir, model_epoch_dir)
        val_tw_path = os.path.join(val_losses_dir, model_epoch_dir)

        stats = evaluation_fn(val_tw_path, test_tw_path, model_epoch_dir, cfg,
                              tw_to_malicious_nodes=tw_to_malicious_nodes)

        out_dir = cfg.detection.evaluation.node_evaluation._precision_recall_dir
        stats["epoch"] = int(model_epoch_dir.split("_")[-1])
        stats["selected_by_val_loss"] = (model_epoch_dir == best_epoch)
        stats["simple_scores_img"] = wandb.Image(os.path.join(out_dir, f"simple_scores_{model_epoch_dir}.png"))

        scores = os.path.join(out_dir, f"scores_{model_epoch_dir}.png")
        if os.path.exists(scores):
            stats["scores_img"] = wandb.Image(scores)
        dor = os.path.join(out_dir, f"dor_{model_epoch_dir}.png")
        if os.path.exists(dor):
            stats["dor_img"] = wandb.Image(dor)
        pr = os.path.join(out_dir, f"pr_curve_{model_epoch_dir}.png")
        if os.path.exists(pr):
            stats["precision_recall_img"] = wandb.Image(pr)

        wandb.log(stats)
        all_stats[model_epoch_dir] = stats

    # 主表口径：val 选出的 epoch（不再比测试 MCC）
    chosen = all_stats.get(best_epoch)
    if chosen is None:
        raise RuntimeError(f"[protocol] val-selected epoch {best_epoch} has no test stats")
    wandb.log(chosen)
    log("==" * 20)
    log(f"[protocol] FINAL (val-selected {best_epoch}): "
        f"mcc={chosen['mcc']:.4f} tp={chosen['tp']} fp={chosen['fp']} "
        f"fn={chosen['fn']} tn={chosen['tn']}")
    log("==" * 20)


def main(cfg):
    method = cfg.detection.evaluation.used_method.strip()
    if method == "node_evaluation":
        standard_evaluation(cfg, evaluation_fn=node_evaluation.main)
    else:
        raise ValueError(f"Invalid evaluation method {cfg.detection.evaluation.used_method}")


if __name__ == "__main__":
    args = get_runtime_required_args()
    cfg = get_yml_cfg(args)
    main(cfg)