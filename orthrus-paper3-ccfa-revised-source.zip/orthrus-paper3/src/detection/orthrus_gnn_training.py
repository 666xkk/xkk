import logging
from time import perf_counter as timer

import torch.nn as nn
import wandb

from src.encoders import OrthrusEncoder
from config import *
from src.data_utils import *
from src.factory import *


def load_pretrained_weights(model, pretrained_dir, device):
    """Load encoder/decoder weights from a previous (pretraining) run."""
    ckpt_name = listdir_sorted(pretrained_dir)[-1]
    ckpt_path = os.path.join(pretrained_dir, ckpt_name, "state_dict.pkl")
    state = torch.load(ckpt_path, map_location="cpu")
    missing, unexpected = model.load_state_dict(state, strict=False)
    log(f"[pretrain] loaded {ckpt_path}")
    log(f"[pretrain] missing keys: {list(missing)} | unexpected keys: {list(unexpected)}")


def train(data,
          full_data,
          model,
          optimizer,
          cfg
          ):
    model.train()

    losses = []
    parts_accum = {}
    batch_loader = batch_loader_factory(cfg, data, model.graph_reindexer)

    for batch in batch_loader:
        optimizer.zero_grad()

        loss = model(batch, full_data)

        if loss.requires_grad:
            loss.backward()
            optimizer.step()
            losses.append(loss.item())
        else:
            # e.g. the first batch of an epoch has an empty context under a
            # pure masked-reconstruction objective -> nothing to optimize
            losses.append(0.0)

        for k, v in model.last_loss_parts.items():
            parts_accum.setdefault(k, []).append(v)
        # [Paper 1] leak-tightness / coverage diagnostics from the encoder
        for k, v in getattr(model.encoder, "_last_mask_stats", {}).items():
            parts_accum.setdefault(k, []).append(float(v))

    mean_parts = {k: float(np.mean(v)) for k, v in parts_accum.items()}
    return float(np.mean(losses)), mean_parts


def main(cfg):
    gnn_models_dir = cfg.detection.gnn_training._trained_models_dir
    os.makedirs(gnn_models_dir, exist_ok=True)
    device = get_device(cfg)

    if device == torch.device("cuda"):
        torch.cuda.reset_peak_memory_stats(device=device)

    train_data, _, _, full_data, max_node_num = load_all_datasets(cfg)

    model = build_model(data_sample=train_data[0], device=device, cfg=cfg, max_node_num=max_node_num)
    model = model.to(device)

    if cfg._from_weights:
        model.load_state_dict(
            torch.load(os.path.join(cfg._from_weights_path, f"{cfg.dataset.name}.pkl")),
            strict=False)  # stock weights lack the recovery heads
    else:
        pretrained_dir = (cfg.detection.gnn_training.pretrained_dir or "").strip()
        if pretrained_dir != "":
            load_pretrained_weights(model, pretrained_dir, device)

    optimizer = optimizer_factory(cfg, parameters=set(model.parameters()))

    num_epochs = 1 if cfg._from_weights else cfg.detection.gnn_training.num_epochs
    tot_loss = 0.0
    epoch_times = []
    for epoch in tqdm(range(1, num_epochs + 1), desc="Training"):
        start = timer()

        # Before each epoch, reset the temporal state (neighbor window + stream clock)
        if isinstance(model.encoder, OrthrusEncoder):
            model.encoder.reset_state()

        tot_loss = 0
        tot_parts = {}
        for g in train_data:
            g.to(device=device)
            loss, parts = train(
                data=g,  # avoids alteration of the graph across epochs
                full_data=full_data,  # full list of edge messages (do not store on CPU)
                model=model,
                optimizer=optimizer,
                cfg=cfg,
            )
            tot_loss += loss
            for k, v in parts.items():
                tot_parts.setdefault(k, []).append(v)
            g.to("cpu")

        tot_loss /= len(train_data)
        parts_str = ", ".join([f"{k}: {np.mean(v):.4f}" for k, v in tot_parts.items()])
        log(f'GNN training loss Epoch: {epoch:02d}, Loss: {tot_loss:.4f}' + (f' | {parts_str}' if parts_str else ''))
        epoch_times.append(timer() - start)

        peak_memory = torch.cuda.max_memory_allocated(device=device) / (1024 ** 3)
        log(f'Peak CUDA memory usage Epoch {epoch}: {peak_memory:.2f} GB')

        wandb.log({
            "train_epoch": epoch,
            "train_loss": round(tot_loss, 4),
            "peak_cuda_memory_GB": round(peak_memory, 2),
            **{f"train_{k}": round(float(np.mean(v)), 4) for k, v in tot_parts.items()},
        })

        if cfg._test_mode or epoch % 1 == 0:
            model_path = os.path.join(gnn_models_dir, f"model_epoch_{epoch}")
            save_model(model, model_path)

    wandb.log({
        "train_epoch_time": round(np.mean(epoch_times), 2),
    })


if __name__ == "__main__":
    args = get_runtime_required_args()
    cfg = get_yml_cfg(args)

    main(cfg)