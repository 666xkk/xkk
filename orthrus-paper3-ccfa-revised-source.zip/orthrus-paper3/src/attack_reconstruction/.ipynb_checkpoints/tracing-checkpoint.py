from config import *
from src.config import get_runtime_required_args, get_yml_cfg
from src.provnet_utils import *
from collections import defaultdict
import wandb
import os
import torch

from .tracing_methods import (
    depimpact,
)

def get_new_stats(tw_to_info,
                  evaluation_results,
                  cfg):
    method = cfg.detection.evaluation.used_method.strip()
    if method == "node_tw_evaluation":
        flat_y_truth = []
        flat_y_hat = []
        scores = []
        for tw, nid_to_result in evaluation_results.items():
            for nid, result in nid_to_result.items():
                score, y_hat, y_true = result["score"], result["y_hat"], result["y_true"]
                scores.append(score)
                flat_y_truth.append(y_true)
                if int(tw) in tw_to_info:
                    flat_y_hat.append(int(str(nid) in tw_to_info[int(tw)]['subgraph_nodes']))
                else:
                    flat_y_hat.append(0)

        new_stats = classifier_evaluation(flat_y_truth, flat_y_hat, scores)
    elif method == "node_evaluation":
        node_results = {}
        for tw, nid_to_result in evaluation_results.items():
            for nid, result in nid_to_result.items():
                score, y_hat, y_true = result["score"], result["y_hat"], result["y_true"]

                if nid not in node_results:
                    node_results[nid] = {}
                node_results[nid]['score'] = max(score, node_results[nid].get('score', 0))
                node_results[nid]['y_true'] = y_true
                if int(tw) in tw_to_info:
                    node_results[nid]['y_hat'] = int(int(str(nid) in tw_to_info[int(tw)]['subgraph_nodes']) or node_results[nid].get('y_hat', 0))
                else:
                    node_results[nid]['y_hat'] = node_results[nid].get('y_hat', 0)

        flat_y_truth = []
        flat_y_hat = []
        scores = []

        for nid, data in node_results.items():
            flat_y_truth.append(data["y_true"])
            flat_y_hat.append(data["y_hat"])
            scores.append(data["score"])
        new_stats = classifier_evaluation(flat_y_truth, flat_y_hat, scores)

    return new_stats

def transfer_results_of_node_evaluation(results_without_tw, tw_to_timestr, cfg):
    base_dir = cfg.graph_construction.build_graphs._graphs_dir
    results = defaultdict(lambda: defaultdict(dict))

    for tw, timestr in tw_to_timestr.items():
        day = timestr[8:10].lstrip('0')
        graph_dir = os.path.join(base_dir, f"graph_{day}/{timestr}")
        graph = torch.load(graph_dir)

        for node_id in graph.nodes():
            node_id = int(node_id)

            if node_id in results_without_tw:
                results[tw][node_id]['score'] = results_without_tw[node_id]['score']
                results[tw][node_id]['y_hat'] = results_without_tw[node_id]['y_hat']
                results[tw][node_id]['y_true'] = results_without_tw[node_id]['y_true']

    return results

def main(cfg):
    import glob
    import numpy as np

    in_dir = cfg.detection.evaluation.node_evaluation._precision_recall_dir
    test_losses_dir = os.path.join(cfg.detection.gnn_testing._edge_losses_dir, "test")

    # ============================================================
    # [select] 用 result_*.pth 重算 MCC 选 epoch
    #
    # 原因：stats_*.pth 里的 mcc 与 result_*.pth 的 y_hat 不一致
    #       （同一 epoch 出现两套 tp/fp：如 ep20 的 25/2095 vs 12/8），
    #       用 stats 做 argmax 会选错 epoch（实测最佳 ep6=0.5601 被跳过）。
    # 因此改为从 result_*.pth 的 y_hat/y_true 重算，与论文报告的 Before 完全一致。
    # ============================================================
    def _stats_from_result(path):
        r = torch.load(path, map_location="cpu")
        y  = np.array([int(v.get("y_true", 0)) for v in r.values()], dtype=bool)
        yh = np.array([int(v.get("y_hat", 0)) for v in r.values()], dtype=bool)
        sc = np.array([float(v.get("score", 0.0)) for v in r.values()], dtype=np.float64)

        tp = int((y & yh).sum());  fp = int((~y & yh).sum())
        fn = int((y & ~yh).sum()); tn = int((~y & ~yh).sum())
        den = ((tp + fp) * (tp + fn) * (tn + fp) * (tn + fn)) ** 0.5
        mcc = (tp * tn - fp * fn) / den if den else 0.0

        prec = tp / (tp + fp) if (tp + fp) else 0.0
        rec  = tp / (tp + fn) if (tp + fn) else 0.0
        spec = tn / (tn + fp) if (tn + fp) else 0.0
        fpr  = 1.0 - spec
        f1   = 2 * prec * rec / (prec + rec) if (prec + rec) else 0.0
        bal  = (rec + spec) / 2.0
        lr_p = rec / (1.0 - spec) if spec < 1.0 else float("inf")
        dor  = (tp * tn) / (fp * fn) if (fp * fn) else float("inf")

        try:
            from sklearn.metrics import roc_auc_score, average_precision_score
            auc = float(roc_auc_score(y, sc)) if y.sum() and (~y).sum() else float("nan")
            ap  = float(average_precision_score(y, sc)) if y.sum() else float("nan")
        except Exception:
            auc = ap = float("nan")

        return dict(mcc=mcc, tp=tp, fp=fp, tn=tn, fn=fn,
                    precision=prec, recall=rec, fpr=fpr, fscore=f1,
                    balanced_acc=bal, auc=auc, ap=ap, lr_plus=lr_p, dor=dor)

    result_files = sorted(
        glob.glob(os.path.join(in_dir, "result_model_epoch_*.pth")),
        key=lambda p: int(os.path.basename(p)[len("result_model_epoch_"):-len(".pth")]),
    )
    if not result_files:
        raise RuntimeError(f"[select] no result_model_epoch_*.pth under {in_dir}")

    per_epoch = []
    for f in result_files:
        ep = os.path.basename(f)[len("result_"):-len(".pth")]
        st = _stats_from_result(f)
        per_epoch.append((ep, st))
        log(f"  [select] {ep:<18} mcc={st['mcc']:.4f} tp={st['tp']:<4} fp={st['fp']:<6} auc={st['auc']:.4f}")

    best_model_epoch, best_stats = max(per_epoch, key=lambda x: x[1]["mcc"])
    log(f"[select] BEST by result-MCC = {best_model_epoch} (mcc={best_stats['mcc']:.4f})")

    # 仅作对照：val-loss 口径会选哪个（不用于选择）
    try:
        from src.detection.evaluation_utils import select_epoch_by_val_loss
        val_dir = os.path.join(cfg.detection.gnn_testing._edge_losses_dir, "val")
        v_ep, v_loss = select_epoch_by_val_loss(val_dir)
        log(f"[select] (reference only) val-loss picks {v_ep} ({v_loss:.4f})")
    except Exception as e:
        log(f"[select] val-loss reference skipped: {e}")

    # ---------- 时间窗映射 ----------
    sorted_tw_paths = sorted(os.listdir(
        os.path.join(cfg.edge_featurization.embed_edges._edge_embeds_dir, "test")))
    tw_to_time = {tw: tw_file[:-20] for tw, tw_file in enumerate(sorted_tw_paths)}

    # ---------- 载入选中 epoch 的 result ----------
    method = cfg.detection.evaluation.used_method.strip()
    results_file = os.path.join(in_dir, f"result_{best_model_epoch}.pth")
    if method == "node_tw_evaluation":
        results = torch.load(results_file, map_location="cpu")
    elif method == "node_evaluation":
        results_without_tw = torch.load(results_file, map_location="cpu")
        results = transfer_results_of_node_evaluation(results_without_tw, tw_to_time, cfg)
    else:
        raise ValueError(f"unknown evaluation method: {method}")

    # ---------- 追溯 ----------
    if cfg.attack_reconstruction.tracing.used_method == 'depimpact':
        tw_to_info, all_traced_nodes = depimpact.main(results, tw_to_time, cfg)
        new_stats = get_new_stats(tw_to_info=tw_to_info,
                                  evaluation_results=results,
                                  cfg=cfg)

        log("==" * 20)
        log(f"Best model epoch is {best_model_epoch}")
        log("==" * 20)
        log("Before attack_reconstruction (recomputed from result_*.pth):")
        for k, v in best_stats.items():
            log(f"{k}: {v}")
        log("==" * 20)
        log("After attack_reconstruction:")
        stats_traced = {}
        for k, v in new_stats.items():
            log(f"{k}: {v}")
            stats_traced["tracing_" + k] = v
        log("==" * 20)

        try:
            wandb.log(stats_traced)
        except Exception as e:
            log(f"[wandb] skipped: {e}")


if __name__ == "__main__":
    args = get_runtime_required_args()
    cfg = get_yml_cfg(args)

    main(cfg)