import torch
import torch.nn as nn

from src.masking import ContextEventMasker
from src.recovery import MaskedLinkHead, TimeGapHead
from src.provnet_utils import *
from src.config import *
from src.model import *
from src.encoders import *
from src.decoders import *
from src.data_utils import *
from src.temporal import LastAggregator, LastNeighborLoader

def build_model(data_sample, device, cfg, max_node_num):
    """
    Builds and loads the initial model into memory.
    The `data_sample` is required to infer the shape of the layers.
    """
    msg_dim, edge_dim, in_dim = get_dimensions_from_data_sample(data_sample)

    graph_reindexer = GraphReindexer(
        num_nodes=max_node_num,
        device=device,
    )
    
    encoder = encoder_factory(cfg, msg_dim=msg_dim, in_dim=in_dim, edge_dim=edge_dim, graph_reindexer=graph_reindexer, device=device, max_node_num=max_node_num)
    decoder = decoder_factory(cfg, in_dim=in_dim, device=device, max_node_num=max_node_num)
    model = model_factory(encoder, decoder, cfg, in_dim=in_dim, graph_reindexer=graph_reindexer, device=device, max_node_num=max_node_num)
    
    return model

def model_factory(encoder, decoders, cfg, in_dim, graph_reindexer, device, max_node_num):
    mask_cfg = cfg.detection.gnn_training.mask
    node_out_dim = cfg.detection.gnn_training.node_out_dim
    node_hid_dim = cfg.detection.gnn_training.node_hid_dim

    link_head, time_head = None, None
    if mask_cfg.enabled:
        if mask_cfg.link_loss_weight > 0:
            link_head = MaskedLinkHead(node_dim=node_out_dim, hid_dim=node_hid_dim)
        if mask_cfg.time_loss_weight > 0:
            time_head = TimeGapHead(node_dim=node_out_dim, hid_dim=node_hid_dim)
        total_w = (mask_cfg.base_type_loss_weight + mask_cfg.type_loss_weight +
                   mask_cfg.link_loss_weight + mask_cfg.time_loss_weight)
        if total_w <= 0:
            raise ValueError("All masked-modeling loss weights are zero; the objective would be empty.")

    model = Orthrus(
        encoder=encoder,
        decoders=decoders,
        num_nodes=max_node_num,
        device=device,
        in_dim=in_dim,
        out_dim=node_out_dim,
        use_contrastive_learning="predict_edge_contrastive" in cfg.detection.gnn_training.decoder.used_methods,
        graph_reindexer=graph_reindexer,
        link_head=link_head,
        time_head=time_head,
        base_type_loss_weight=mask_cfg.base_type_loss_weight if mask_cfg.enabled else 1.0,
        masked_type_loss_weight=mask_cfg.type_loss_weight if mask_cfg.enabled else 0.0,
        link_loss_weight=mask_cfg.link_loss_weight if mask_cfg.enabled else 0.0,
        time_loss_weight=mask_cfg.time_loss_weight if mask_cfg.enabled else 0.0,
    )
    return model.to(device)


def encoder_factory(cfg, msg_dim, in_dim, edge_dim, graph_reindexer, device, max_node_num):
    train_cfg = cfg.detection.gnn_training
    node_hid_dim = train_cfg.node_hid_dim
    node_out_dim = train_cfg.node_out_dim
    temporal_dim = train_cfg.encoder.temporal_dim

    edge_dim = 0
    edge_features = [x.strip() for x in train_cfg.encoder.edge_features.split(",")]
    for edge_feat in edge_features:
        if edge_feat == "edge_type":
            edge_dim += cfg.dataset.num_edge_types
        elif edge_feat == "msg":
            edge_dim += msg_dim
        elif edge_feat == "none":
            pass
        else:
            raise ValueError(f"Invalid edge feature {edge_feat}")

    use_time_features = train_cfg.encoder.use_time_features
    if use_time_features:
        edge_dim += 1

    original_in_dim = in_dim
    in_dim = temporal_dim

    architecture = train_cfg.encoder.architecture
    inner_kwargs = dict(
        in_dim=in_dim,
        hid_dim=node_hid_dim,
        out_dim=node_out_dim,
        edge_dim=edge_dim or None,
        dropout=train_cfg.encoder.graph_attention.dropout,
        activation=activation_fn_factory(train_cfg.encoder.graph_attention.activation),
        num_heads=train_cfg.encoder.graph_attention.num_heads,
    )
    if architecture == "graph_transformer":
        encoder = GraphTransformer(**inner_kwargs)
    elif architecture == "gat":
        encoder = GATEncoder(**inner_kwargs)
    elif architecture == "sage":
        encoder = SAGEEncoder(**inner_kwargs)
    elif architecture == "linear":
        encoder = LinearEncoder(**inner_kwargs)
    else:
        raise ValueError(f"Invalid encoder architecture: {architecture}")

    neighbor_size = train_cfg.encoder.neighbor_size
    neighbor_loader = LastNeighborLoader(max_node_num, size=neighbor_size, device=device)

    mask_cfg = train_cfg.mask
    masker = None
    if mask_cfg.enabled:
        gen = None
        try:
            gen = torch.Generator(device=device).manual_seed(cfg._seed)
        except Exception:
            gen = None
        masker = ContextEventMasker(
            mask_rate=mask_cfg.mask_rate,
            sampling_prior=mask_cfg.sampling_prior,
            prior_strength=mask_cfg.prior_strength,
            generator=gen,
        )

    encoder = OrthrusEncoder(
        encoder=encoder,
        neighbor_loader=neighbor_loader,
        in_dim=original_in_dim,
        temporal_dim=temporal_dim,
        use_node_feats_in_gnn=train_cfg.encoder.use_node_feats_in_gnn,
        graph_reindexer=graph_reindexer,
        edge_features=edge_features,
        device=device,
        num_nodes=max_node_num,
        edge_dim=edge_dim,
        use_time_features=use_time_features,
        masker=masker,
        link_negatives=mask_cfg.link_negatives,
    )

    return encoder

def decoder_factory(cfg, in_dim, device, max_node_num):
    node_out_dim = cfg.detection.gnn_training.node_out_dim

    decoders = []
    for method in map(lambda x: x.strip(), cfg.detection.gnn_training.decoder.used_methods.split(",")):
        if method == "predict_edge_type":
            def cross_entropy(x, y, inference=False, **kwargs):
                reduction = "none" if inference else "mean"
                return F.cross_entropy(x, y, reduction=reduction)

            loss_fn = cross_entropy
            activation = activation_fn_factory(cfg.detection.gnn_training.decoder.predict_edge_type.custom.activation)

            decoder = EdgeTypeDecoder(
                in_dim=node_out_dim,
                num_edge_types=cfg.dataset.num_edge_types,
                loss_fn=loss_fn,
                dropout=cfg.detection.gnn_training.decoder.predict_edge_type.custom.dropout,
                num_layers=cfg.detection.gnn_training.decoder.predict_edge_type.custom.num_layers,
                activation=activation,
            )
            decoders.append(decoder)

        else:
            raise ValueError(f"Invalid decoder {method}")

    return decoders

def batch_loader_factory(cfg, data, graph_reindexer):
    return custom_temporal_data_loader(data, batch_size=cfg.detection.gnn_training.encoder.batch_size)
    
    data = graph_reindexer.reindex_graph(data)
    return [data]

def activation_fn_factory(activation: str):
    if activation == "sigmoid":
        return nn.Sigmoid()
    if activation == "relu":
        return nn.ReLU()
    if activation == "tanh":
        return nn.Tanh()
    if activation == "none":
        return nn.Identity()
    raise ValueError(f"Invalid activation function {activation}")

def optimizer_factory(cfg, parameters):
    lr = cfg.detection.gnn_training.lr
    weight_decay = cfg.detection.gnn_training.weight_decay

    return torch.optim.Adam(parameters, lr=lr, weight_decay=weight_decay) # TODO: parametrize

def get_dimensions_from_data_sample(data):
    msg_dim = data.msg.shape[1]
    edge_dim = data.edge_feats.shape[1] if hasattr(data, "edge_feats") else None
    in_dim = data.x_src.shape[1]
    
    return msg_dim, edge_dim, in_dim
