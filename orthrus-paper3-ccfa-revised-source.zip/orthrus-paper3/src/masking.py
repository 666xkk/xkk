"""Context-event masking and streaming time tracking for ORTHRUS (Paper 1).

Objective: *temporal context-event masked modeling*.

Masking unit = one context event already inserted in the neighbor loader
(part of the visible temporal context of the current batch). For each forward
pass we sample a fraction of context events, remove them from the GNN
aggregation of THIS forward only, and reconstruct them from the remaining
visible context. Since the retrieval window holds both older and more recent
events, this is a bidirectional masked-reconstruction objective *within the
retained context window* -- not next-event prediction. Masking is resampled
every forward (BERT-style); no state persists across batches.

`StreamTimeTracker` maintains per-node last-event-time over the processed
stream and stores each event's inter-arrival gap `event_dt[e_id]`, used for
(a) temporal-prior mask sampling and (b) time-gap reconstruction targets.
"""
import torch


def compute_event_endpoint_gaps(src, dst, t):
    """Offline per-event prev/next endpoint gaps over the full event stream.

    Mirrors `StreamTimeTracker.observe` semantics event-by-event:
      prev gap = t(e) - t(e_last), e_last = most recent event sharing >= 1
                 endpoint with e (max over the two endpoints),
      next gap = t(e_next) - t(e), e_next = soonest event sharing >= 1
                 endpoint with e (min over the two endpoints).
    Self-loops never use themselves as predecessor/successor.
    The stream must be in temporal order (events are indexed by position).

    Paper 2: these two sides define the *temporal bridge score*
    min(log1p(prev), log1p(next)) used by the bridge sampling prior.
    Computed offline over the training corpus as a mask-sampling curriculum
    only; no future information enters any reconstruction target (the time
    head is supervised on the causal prev-gap) or the detection-time model.

    Returns (prev_dt, prev_valid, next_dt, next_valid), float32 [E], seconds.
    """
    src = src.long()
    dst = dst.long()
    t = t.long()
    E = int(src.numel())
    zeros = torch.zeros(E, dtype=torch.float32, device=src.device)
    falses = torch.zeros(E, dtype=torch.bool, device=src.device)
    if E == 0:
        return zeros, falses, zeros, falses

    dev = src.device
    eidx = torch.arange(E, device=dev)
    nodes = torch.cat([src, dst])
    es = torch.cat([eidx, eidx])
    role = torch.cat([torch.zeros(E, dtype=torch.long, device=dev),
                      torch.ones(E, dtype=torch.long, device=dev)])
    keep = ~((role == 1) & (src[es] == dst[es]))   # self-loops: one endpoint entry
    nodes, es, role = nodes[keep], es[keep], role[keep]

    def adjacent_time(reverse):
        # Occurrences grouped per node; inside a block ordered by stream
        # position (reverse=True -> from the end), the adjacent element is
        # the previous/next occurrence of that endpoint.
        key = -es if reverse else es
        perm = torch.argsort(key, stable=True)
        perm = perm[torch.argsort(nodes[perm], stable=True)]
        ns, es_s, rs = nodes[perm], es[perm], role[perm]
        tt = t[es_s]
        nbr = torch.full_like(tt, -1)
        first = torch.cat([torch.tensor([True], device=dev), ns[1:] != ns[:-1]])
        nbr[1:] = torch.where(first[1:], torch.full_like(tt[1:], -1), tt[:-1])
        by = torch.full((2, E), -1, dtype=tt.dtype, device=dev)
        by[rs, es_s] = nbr
        return by[0], by[1]

    prev_src, prev_dst = adjacent_time(reverse=False)
    next_src, next_dst = adjacent_time(reverse=True)

    self_loop = src == dst
    prev_dst = torch.where(self_loop, prev_src, prev_dst)
    next_dst = torch.where(self_loop, next_src, next_dst)

    prev_valid = (prev_src >= 0) | (prev_dst >= 0)
    prev_tm = torch.maximum(prev_src, prev_dst)
    prev_dt = torch.where(prev_valid, (t - prev_tm).clamp(min=0),
                          torch.zeros_like(t)).float() / 1e9

    BIG = torch.iinfo(t.dtype).max // 2
    n_src = torch.where(next_src >= 0, next_src, torch.full_like(next_src, BIG))
    n_dst = torch.where(next_dst >= 0, next_dst, torch.full_like(next_dst, BIG))
    next_tm = torch.minimum(n_src, n_dst)
    next_valid = next_tm < BIG
    next_dt = torch.where(next_valid, (next_tm - t).clamp(min=0),
                          torch.zeros_like(t)).float() / 1e9

    return prev_dt, prev_valid, next_dt, next_valid


class StreamTimeTracker:
    """Per-node last event time + per-event inter-arrival gaps.

    Not an nn.Module (no parameters). Saved/restored with the checkpoint so
    evaluation sees the same temporal history as training
    (see data_utils.save_model / load_model).
    """

    def __init__(self, num_nodes, device, init_capacity=1 << 16):
        self.device = device
        self.last_time = torch.full((num_nodes,), -1, dtype=torch.long, device=device)
        self.event_dt = torch.zeros(init_capacity, dtype=torch.float32, device=device)
        self.event_dt_valid = torch.zeros(init_capacity, dtype=torch.bool, device=device)

    def _ensure_capacity(self, needed):
        cap = self.event_dt.numel()
        if cap >= needed:
            return
        while cap < needed:
            cap *= 2
        dt = torch.zeros(cap, dtype=self.event_dt.dtype, device=self.device)
        valid = torch.zeros(cap, dtype=self.event_dt_valid.dtype, device=self.device)
        dt[: self.event_dt.numel()] = self.event_dt
        valid[: self.event_dt_valid.numel()] = self.event_dt_valid
        self.event_dt, self.event_dt_valid = dt, valid

    @torch.no_grad()
    def observe(self, src, dst, t, first_e_id, cur_e_id):
        """Compute *event-level* inter-arrival gaps in stream order.

        The previous implementation compared every event in a batch only with
        state from the preceding batch. That silently ignored earlier events in
        the same batch, which is especially damaging when batches contain many
        repeated process/file/socket nodes. This implementation obtains the
        previous occurrence of each endpoint within the current batch using a
        stable node/event ordering, then falls back to the cross-batch state.
        """
        n = int(t.numel())
        self._ensure_capacity(cur_e_id)
        if n == 0:
            return t.float(), torch.zeros(0, dtype=torch.bool, device=self.device)

        src = src.to(self.device).long()
        dst = dst.to(self.device).long()
        t = t.to(self.device).long()
        event_idx = torch.arange(n, device=self.device)

        # Two endpoint occurrences per event; remove the duplicate occurrence
        # for self-loops so an event cannot become its own predecessor.
        nodes = torch.cat([src, dst])
        eidx = torch.cat([event_idx, event_idx])
        role = torch.cat([torch.zeros(n, dtype=torch.long, device=self.device),
                          torch.ones(n, dtype=torch.long, device=self.device)])
        keep = ~((role == 1) & (src[eidx] == dst[eidx]))
        nodes, eidx, role = nodes[keep], eidx[keep], role[keep]

        # Stable lexicographic order: node first, event index second.
        perm = torch.argsort(eidx, stable=True)
        perm = perm[torch.argsort(nodes[perm], stable=True)]
        ns, es, rs = nodes[perm], eidx[perm], role[perm]
        prev_occ = self.last_time[ns].clone()
        same_node_as_prev = ns[1:] == ns[:-1]
        prev_occ[1:] = torch.where(same_node_as_prev, t[es[:-1]], prev_occ[1:])
        # The previous occurrence is always the immediately preceding event
        # for this node because events are supplied in temporal stream order.
        prev_by_event_role = torch.full((2, n), -1, dtype=torch.long, device=self.device)
        prev_by_event_role[rs, es] = prev_occ
        prev_src, prev_dst = prev_by_event_role[0], prev_by_event_role[1]
        # For a self-loop, source and destination are the same endpoint.
        self_loop = src == dst
        prev_dst = torch.where(self_loop, prev_src, prev_dst)
        valid = (prev_src >= 0) | (prev_dst >= 0)
        prev = torch.maximum(prev_src, prev_dst)
        dt_ns = (t - prev).clamp(min=0)
        dt = torch.where(valid, dt_ns, torch.zeros_like(dt_ns)).float() / 1e9

        e_ids = torch.arange(first_e_id, first_e_id + n, device=self.device)
        self.event_dt[e_ids] = dt
        self.event_dt_valid[e_ids] = valid

        # Update cross-batch state only after all gaps for this batch are known.
        self.last_time.index_reduce_(0, torch.cat([src, dst]), torch.cat([t, t]),
                                     "amax", include_self=True)
        return dt, valid

    def reset(self):
        self.last_time.fill_(-1)

    def state_dict(self):
        return {
            "last_time": self.last_time.detach().cpu(),
            "event_dt": self.event_dt.detach().cpu(),
            "event_dt_valid": self.event_dt_valid.detach().cpu(),
        }

    def load_state_dict(self, sd):
        self.last_time = sd["last_time"].to(self.device)
        self.event_dt = sd["event_dt"].to(self.device)
        self.event_dt_valid = sd["event_dt_valid"].to(self.device)


class ContextEventMasker:
    """Samples ARC GROUPS (unordered node pair {u,v}) of context entries to mask.

    v2 (leak-tight): all context entries between u and v (both orientations,
    all types) are removed together, so the reconstruction heads cannot copy
    the answer from a duplicate event left in the visible context.

    Priors:
      uniform  : uniform over groups
      temporal : monotone in the group's global inter-arrival gap (v1 behavior)
      hard     : temporal * (1 + strength * [group occurs once in this context])
                 -> prefers masking arcs whose evidence is unique/irreplaceable
      bridge   : temporal * (1 + bridge_strength * bridge score), where the
                 bridge score is the group's min(log1p(prev gap), log1p(next
                 gap)) normalized over the context. Large bridge score == the
                 event sits in a temporal hole for its endpoints (both
                 neighboring endpoint occurrences far away), so only genuine
                 long-range temporal reasoning can recover it.
                 `bridge_strength > 0` additionally boosts temporal/hard.

    Paper 2: the bridge prior is the "bridge-first" curriculum -- masking
    concentrates on events whose temporal evidence cannot be copied.
    """

    def __init__(self, mask_rate=0.15, sampling_prior="temporal",
                 prior_strength=1.0, max_mask_frac=0.5, generator=None,
                 bridge_strength=0.0):
        assert 0.0 < mask_rate < 1.0, "mask_rate must be in (0, 1)"
        assert sampling_prior in ("uniform", "temporal", "hard", "bridge")
        self.mask_rate = mask_rate
        self.sampling_prior = sampling_prior
        self.prior_strength = prior_strength
        self.max_mask_frac = max_mask_frac
        self.generator = generator
        # "bridge" prior implies the bridge boost; explicit bridge_strength
        # also composes with temporal/hard.
        if sampling_prior == "bridge" and bridge_strength <= 0.0:
            bridge_strength = prior_strength
        self.bridge_strength = bridge_strength

    @torch.no_grad()
    def sample(self, e_id_ctx, arc_key, event_dt, event_dt_valid,
               triple_key=None,
               bridge_prev=None, bridge_prev_valid=None,
               bridge_next=None, bridge_next_valid=None):
        """e_id_ctx: [E] context entry event ids (may duplicate per direction)
        arc_key  : [E] int64, canonical id of the unordered pair {u,v}
        triple_key: [E] int64, canonical id of the directed (src,dst,type)
                   triple -- used ONLY for leak-tightness diagnostics
        bridge_prev/next(_valid): [E] per-entry prev/next endpoint gaps
                   (see compute_event_endpoint_gaps), for the bridge prior
        Returns dict:
          keep        : [E] bool, entries kept in this forward's aggregation
          masked_eids : [m] representative e_id per masked group (first entry)
          dt, dt_valid: [m] reconstruction targets (representative's global gap)
          group_size  : [m] entries-per-group in this context (diagnostics)
          stats       : dict of leak-tightness / bridge-selection diagnostics
        """
        device = e_id_ctx.device
        E = e_id_ctx.numel()
        empty_out = dict(keep=torch.ones(0, dtype=torch.bool, device=device),
                         masked_eids=torch.empty(0, dtype=torch.long, device=device),
                         masked_group_rep_eids=torch.empty(0, dtype=torch.long, device=device),
                         dt=torch.empty(0, device=device),
                         dt_valid=torch.empty(0, dtype=torch.bool, device=device),
                         group_size=torch.empty(0, dtype=torch.long, device=device),
                         stats={})
        if E == 0:
            return empty_out

        uniq_key, inv = torch.unique(arc_key, return_inverse=True)   # inv: [E] group id
        G = uniq_key.numel()
        # Count distinct event IDs per arc group, not adjacency slots. The
        # neighbor loader can expose one event from both endpoint histories;
        # counting slots would incorrectly treat that single event as repeated
        # evidence and corrupt the hard/rarity prior and duplicate diagnostics.
        group_event_pairs = torch.unique(torch.stack([inv, e_id_ctx], dim=1), dim=0)
        gsize = torch.bincount(group_event_pairs[:, 0], minlength=G)

        # representative = first entry of each group
        pos = torch.arange(E, device=device)
        first_pos = torch.full((G,), E, dtype=torch.long, device=device)
        first_pos.scatter_reduce_(0, inv, pos, reduce="amin")        # torch>=1.13
        rep_eid = e_id_ctx[first_pos]
        # Aggregate temporal evidence over the full arc group. A representative
        # chosen by tensor order may have an invalid/old gap even when another
        # event in the same group has a valid, larger gap.
        dt_entries = event_dt[e_id_ctx]
        valid_entries = event_dt_valid[e_id_ctx]
        dt_g = torch.zeros(G, dtype=dt_entries.dtype, device=device)
        dt_g.scatter_reduce_(0, inv, torch.where(valid_entries, dt_entries,
                                                  torch.zeros_like(dt_entries)),
                             reduce="amax", include_self=True)
        valid_g = torch.zeros(G, dtype=torch.float32, device=device)
        valid_g.scatter_reduce_(0, inv, valid_entries.float(), reduce="amax",
                                include_self=True)
        valid_g = valid_g.bool()

        # ---- Paper 2 diagnostics -------------------------------------------
        stats = {}
        if triple_key is not None and triple_key.numel() == E:
            _, inv_t, counts = torch.unique(triple_key, return_counts=True,
                                            return_inverse=True)
            dup = counts > 1
            stats["triple_dup_frac"] = float(dup.float().mean())          # distinct triples
            stats["entries_triple_dup_frac"] = float(dup[inv_t].float().mean())  # entries

        bridge_g = None
        if (self.bridge_strength > 0.0 and bridge_prev is not None
                and bridge_prev.numel() == E):
            inf = torch.finfo(dt_entries.dtype).max
            pv = (bridge_prev_valid if bridge_prev_valid is not None
                  else torch.ones(E, dtype=torch.bool, device=device))
            nv = (bridge_next_valid if bridge_next_valid is not None
                  else torch.ones(E, dtype=torch.bool, device=device))
            p = torch.where(pv, torch.log1p(bridge_prev),
                            torch.full_like(bridge_prev, inf))
            n = torch.where(nv, torch.log1p(bridge_next),
                            torch.full_like(bridge_next, inf))
            m = torch.minimum(p, n)
            has = m < inf
            m = torch.where(has, m, torch.zeros_like(m))
            g_bridge = torch.zeros(G, dtype=m.dtype, device=device)
            g_bridge.scatter_reduce_(0, inv, m, reduce="amax", include_self=True)
            g_has = torch.zeros(G, dtype=torch.float32, device=device)
            g_has.scatter_reduce_(0, inv, has.float(), reduce="amax", include_self=True)
            g_has = g_has.bool()
            ref_b = g_bridge[g_has].max().clamp(min=1e-6) if g_has.any() else torch.tensor(1e-6, device=device)
            bridge_g = (g_bridge / ref_b).clamp(0.0, 1.0)
            if g_has.any():
                stats["bridge_mean_ctx"] = float(bridge_g[g_has].float().mean())
        # ---------------------------------------------------------------------

        n_mask = int(round(self.mask_rate * G))
        n_mask = min(n_mask, max(1, int(self.max_mask_frac * G)))
        n_mask = max(1, min(n_mask, G))

        w = self._weights(dt_g, valid_g, gsize, bridge=bridge_g)
        u = torch.rand(w.shape, device=device, generator=self.generator).clamp_min(1e-12)
        gumbel = -torch.log(-torch.log(u))
        scores = torch.log(w.clamp_min(1e-12)) + gumbel
        idx = torch.topk(scores, n_mask, largest=True, sorted=False).indices

        sel = torch.zeros(G, dtype=torch.bool, device=device)
        sel[idx] = True
        masked_entry = sel[inv]
        keep = ~masked_entry
        # The whole arc group is removed from message passing. Supervise every
        # hidden event for event type and time-gap recovery; keep one positive
        # pair per selected group for link recovery to avoid duplicate-pair
        # over-weighting. Targets are returned in the same order as e_id_ctx.
        # e_id_ctx can contain the same historical event twice (one adjacency
        # entry per endpoint). Deduplicate IDs before defining reconstruction
        # targets, otherwise repeated context representations overweight a
        # single event and make target counts depend on endpoint visibility.
        masked_eids = torch.unique(e_id_ctx[masked_entry], sorted=True)
        masked_dt = event_dt[masked_eids]
        masked_dt_valid = event_dt_valid[masked_eids]

        if bridge_g is not None:
            stats["bridge_mean_masked"] = float(bridge_g[idx].float().mean())
            stats["bridge_top_frac"] = float((bridge_g[idx] >= 0.5).float().mean())

        return dict(keep=keep,
                    masked_eids=masked_eids,
                    masked_group_rep_eids=rep_eid[idx],
                    dt=masked_dt,
                    dt_valid=masked_dt_valid,
                    group_size=gsize[idx],
                    stats=stats)

    def _weights(self, dt, valid, gsize, bridge=None):
        if self.sampling_prior == "uniform":
            w = torch.ones_like(dt)
        else:
            w = torch.ones_like(dt)
            if valid.any():
                log_gap = torch.log1p(dt)
                ref = log_gap[valid].max().clamp(min=1e-6)
                norm_gap = (log_gap / ref).clamp(0.0, 1.0)
                w = torch.where(valid, 1.0 + self.prior_strength * norm_gap,
                                torch.ones_like(dt))
            if self.sampling_prior == "hard":
                w = w * (1.0 + self.prior_strength * (gsize == 1).float())
        if bridge is not None and self.bridge_strength > 0.0:
            w = w * (1.0 + self.bridge_strength * bridge)
        return w
