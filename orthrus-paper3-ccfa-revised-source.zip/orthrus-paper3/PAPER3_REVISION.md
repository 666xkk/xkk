# Paper-3 revision record

## Reproduction guides

- `PAPER1_EXPERIMENT_GUIDE.md`: complete two-stage experiment procedure,
  ablation commands, leave-one-collector-out protocol, and acceptance checks.
- `PAPER2_FOLLOWUP_EXPERIMENT_GUIDE.md`: causal rerun, missing runner
  contract, required baselines, contamination, cross-detector evaluation, and
  statistical reporting.

## Implemented

- Paper-1 `MaskedLinkHead` is exposed through causal prefix snapshots.
- Paper-2 rolling block p-values construct label-free repair seeds.
- Paper-3 fusion combines learned link compatibility, calibrated endpoint
  evidence, and an optional structural term.
- Controlled hidden-link masks are fingerprinted and checked across embedding
  export and evaluation.
- Oracle labels are isolated behind an explicit upper-bound flag.
- Adamic--Adar replaces the identically-zero exact-edge structural baseline.
- TBFS uses remapped node IDs and directed nondecreasing event times.
- Lexical hashing is deterministic across Python processes.
- Candidate coverage, unconditional/conditional Recall@B, Precision@B, AP,
  MRR, NDCG, and hop-stratified recall are produced separately.
- Precision uses the actual selected count when the budget exceeds candidates.
- Ground-truth links that remain visible abort the experiment.
- A frozen experiment protocol and stop conditions are documented.

## Verification

`python tests/test_paper3_link_repair.py` exercises pure method logic and future
leakage invariants. `python tests/test_paper3_integration.py` runs a complete
calibrated-seed -> masked-embedding -> budgeted-repair experiment and verifies
that a mismatched mask is rejected.

## Still requires real data/GPU runs

- Export link-head snapshots from trained Paper-1 checkpoints.
- Run all collectors, seeds, days, baselines, and causal masks.
- Select fusion weights and all protocol hyperparameters on validation only.
- Add at least one non-ORTHRUS detector for the portability claim.
- Produce block-bootstrap confidence intervals and measured system overhead.

Passing the code checks establishes implementation integrity, not CCF-A
acceptance or empirical superiority.
