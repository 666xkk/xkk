"""Small end-to-end runner test without DB, labels, torch, or GPU."""
import subprocess
import sys
import tempfile
from pathlib import Path

import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from paper3.run_link_repair import pair_hash


def main():
    with tempfile.TemporaryDirectory() as tmp:
        root = Path(tmp)
        edge_root = root / "edge"
        for split in ("train", "test"):
            directory = edge_root / split / "model_epoch_1"
            directory.mkdir(parents=True)
            rows = []
            for time, (src, dst) in enumerate([(0, 1), (1, 2), (2, 3), (3, 4)]):
                rows.append(dict(loss=float(src + 1), srcnode=src, dstnode=dst,
                                 srcmsg=f"process node{src}", dstmsg=f"file node{dst}",
                                 time=float(time)))
            pd.DataFrame(rows).to_csv(directory / "window_11.csv", index=False)

        seeds = root / "seeds.csv"
        pd.DataFrame([dict(node=i, pvalue=0.01 if i == 0 else 1.0)
                      for i in range(5)]).to_csv(seeds, index=False)
        hidden = root / "hidden.csv"
        pd.DataFrame([dict(src=0, dst=2)]).to_csv(hidden, index=False)

        emb = np.eye(5, dtype=np.float32)
        query = np.eye(5, dtype=np.float32)
        query[0] = emb[2]
        dump = root / "emb.npz"
        np.savez_compressed(dump, nodes=np.arange(5), emb=emb, query=query,
                            causal=np.asarray(True), temperature=np.asarray(0.1),
                            masked_links_sha256=np.asarray(pair_hash({(0, 2)})))
        out = root / "out"
        command = [sys.executable, str(ROOT / "paper3" / "run_link_repair.py"),
                   "--edge-losses-dir", str(edge_root), "--epoch", "model_epoch_1",
                   "--eval-days", "11", "--seed-mode", "calibrated",
                   "--seed-pvalues", str(seeds), "--gt-links", str(hidden),
                   "--hidden-links", str(hidden), "--embeddings", str(dump),
                   "--max-gap", "100", "--B-grid", "1,3", "--out", str(out)]
        subprocess.run(command, check=True, capture_output=True, text=True)
        ranking = pd.read_csv(out / "ranking_model_epoch_1.csv")
        assert "paper3_fusion" in set(ranking.method)
        frontier = pd.read_csv(out / "frontier_model_epoch_1.csv")
        assert set(frontier.budget) == {1, 3}
        protocol = out / "protocol_model_epoch_1.json"
        assert protocol.exists()
        bad_dump = root / "bad_emb.npz"
        np.savez_compressed(bad_dump, nodes=np.arange(5), emb=emb, query=query,
                            causal=np.asarray(True), temperature=np.asarray(0.1),
                            masked_links_sha256=np.asarray("wrong-mask"))
        bad_command = command.copy()
        bad_command[bad_command.index(str(dump))] = str(bad_dump)
        failed = subprocess.run(bad_command, capture_output=True, text=True)
        assert failed.returncode != 0 and "same hidden-link mask" in failed.stderr
    print("[ok] end-to-end calibrated causal repair")


if __name__ == "__main__":
    main()
