"""Dependency-light tests for the three-paper integration."""
import sys
from pathlib import Path

import numpy as np

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from paper3.calibrated_seeds import aggregate_seed_evidence, causal_seed_pvalues
from paper3.link_repair import (
    bh_select, budget_frontier, candidate_coverage, conformal_edge_pvalues,
    connector_diagnostics, enumerate_candidates, hop_of,
    hop_stratified_recall, ranking_metrics, score_allowlist, score_bfs,
    score_calibrated_fusion, score_learned, score_linear, score_structural,
    temporal_mask,
)
from paper3.run_link_repair import _day_of, msg_features, pair_hash


def test_candidate_contract():
    tmin = np.arange(6, dtype=float)
    tmax = tmin + 1
    visible = np.array([[0, 1], [1, 2], [2, 3]])
    candidates = enumerate_candidates([0], tmin, tmax, visible, 4, direction="both")
    pairs = set(map(tuple, candidates.tolist()))
    assert (0, 1) not in pairs and (0, 0) not in pairs
    assert (0, 2) in pairs and (2, 0) in pairs
    assert temporal_mask([0], tmin, tmax, 2)[2]


def test_paper1_learned_score():
    candidates = np.array([[0, 1], [0, 2]])
    query = np.array([[1., 0.], [0., 1.], [0., 1.]])
    emb = np.array([[0., 1.], [1., 0.], [0., 1.]])
    scores = score_learned(query, emb, candidates)
    assert scores[0] > scores[1]


def test_structural_baseline_scores_absent_edges():
    # Missing 0--2 is supported by common neighbor 1; 0--3 is not.
    visible = np.array([[0, 1], [1, 2], [3, 4]])
    candidates = np.array([[0, 2], [0, 3]])
    scores = score_structural(visible, candidates)
    assert scores[0] > 0 and scores[1] == 0


def test_feature_baselines():
    candidates = np.array([[0, 1], [0, 2]])
    assert score_allowlist([0, 3, 1], candidates).tolist() == [3, 1]
    features = np.array([[1, 0], [1, 0], [0, 1]], dtype=float)
    assert score_linear(features, candidates)[0] > score_linear(features, candidates)[1]
    messages = {7: "process /usr/bin/bash --login"}
    assert np.array_equal(msg_features(messages, [7]), msg_features(messages, [7]))
    assert pair_hash({(2, 1), (1, 2)}) == pair_hash({(1, 2), (2, 1)})
    assert _day_of("events_2018-04-10_12-00.csv") == "10"


def test_bfs_and_tbfs():
    visible = np.array([[0, 1], [1, 2], [2, 3]])
    candidates = np.array([[0, 1], [0, 2], [0, 3], [0, 9]])
    assert score_bfs(visible, [0], candidates, 10).tolist() == [-1, -2, -3, -9]
    times = {(0, 1): 5., (1, 2): 3., (2, 3): 10.}
    temporal = score_bfs(visible, [0], candidates, 10, temporal=True, edge_time=times)
    assert temporal[0] == -1 and temporal[1] == -9


def test_causal_seed_calibration_has_no_future_leakage():
    prefix = [("w0", {0: 1.}), ("w1", {0: 2.}), ("w2", {1: 3.})]
    original = causal_seed_pvalues(prefix, history_length=2)
    changed_future = causal_seed_pvalues(prefix + [("w3", {99: 1e9})], history_length=2)
    assert original == changed_future[:len(original)]
    assert original[0][1] == {} and original[1][1] == {}
    assert 1 in original[2][1]
    evidence = aggregate_seed_evidence(original, alpha=0.5)
    assert evidence[1]["n_scored_windows"] == 1


def test_calibrated_fusion_uses_seed_evidence():
    candidates = np.array([[0, 2], [1, 2]])
    learned = np.array([0., 0.])
    pvalues = np.array([0.001, 0.5, 1.0])
    fused = score_calibrated_fusion(learned, candidates, pvalues)
    assert fused[0] > fused[1]


def test_edge_conformal_and_bh():
    pvalues = conformal_edge_pvalues([0., 1., 2., 3.], [4., 2.])
    assert np.allclose(pvalues, [0.2, 0.6])
    assert bh_select([0.001, 0.02, 0.9], 0.05).tolist() == [True, True, False]


def test_budget_metrics_separate_coverage():
    candidates = np.array([[0, 1], [0, 2], [0, 3]])
    gt = np.array([[0, 1], [0, 2], [9, 9]])
    scores = np.array([3., 2., 1.])
    result = budget_frontier(scores, candidates, gt, [1, 2, 9])
    assert result["hits"].tolist() == [1, 2, 2]
    assert np.isclose(result["precision"][-1], 2 / 3)  # divide by selected, not budget
    assert np.isclose(result["candidate_coverage"]["coverage"], 2 / 3)
    assert np.isclose(result["conditional_recall"][1], 1.0)
    metrics = ranking_metrics(scores, candidates, gt)
    assert metrics["mrr"] == 1.0 and metrics["ap"] == 1.0
    assert candidate_coverage(candidates, gt)["covered_gt"] == 2


def test_hops_and_connector_diagnostics():
    visible = np.array([[0, 1], [1, 2], [2, 3]])
    assert hop_of([1, 2, 3], [0], visible).tolist() == [1, 2, 3]
    strata = hop_stratified_recall([[0, 1]], [[0, 1], [0, 2]], [0], visible)
    assert strata[1] == 1 and strata[2] == 0
    t = np.arange(5, dtype=float)
    diag = connector_diagnostics([0], [0, 2, 4], t, t + 1, visible, 10,
                                 direction="both")
    assert diag["n_hidden"] == 2  # seed is excluded from hidden nodes
    assert 0 <= diag["coverable_frac"] <= 1


if __name__ == "__main__":
    for name, value in sorted(globals().items()):
        if name.startswith("test_") and callable(value):
            value()
            print(f"[ok] {name}")
    print("all Paper-3 tests passed")
