# Paper 2 后续补充实验指南

本文档对应 Paper 2 的因果滚动块校准。当前论文中历史性的 node-level 诊断结果可以保留，但所有关于在线 window-level FPR 的结果必须重新运行；任何使用“整段 test trace 的节点最大分数”回填早期窗口的结果都无效。

## 1. 当前可直接运行的检查

在 Paper 1/2 ORTHRUS 仓库根目录：

```bash
python -m pip install -r requirements-mechanisms.txt
PYTHONPATH=. python tests/test_paper2_mechanisms.py
```

对已有 edge-loss 和 evaluation artifact 做 seen/unseen FP 归因：

```bash
python tools/rq12_novelty_attrib.py \
  --edge-losses-dir artifacts/detection/gnn_testing/EDGE_HASH/CADETS_E3/edge_losses \
  --eval-dir artifacts/detection/evaluation/EVAL_HASH/CADETS_E3/precision_recall_dir \
  --epoch model_epoch_20 --alpha 0.01 \
  --out paper2/results/novelty
```

该工具是 retrospective node-level 诊断，不能替代后面的 causal window experiment。

Paper 3 包中保留了 Paper 2 的因果 rolling 实现，可先生成单方法结果：

```bash
python paper3/run_online.py \
  --dataset CADETS_E3 \
  --edge-losses artifacts/detection/gnn_testing/EDGE_HASH/CADETS_E3/edge_losses \
  --eval-dir artifacts/detection/evaluation/EVAL_HASH/CADETS_E3/precision_recall_dir \
  --epoch model_epoch_20 --history-length 40 --alpha 0.05 \
  --out paper2/results/causal
```

输出 `causal_online_*.csv` 和 `causal_online_summary_*.csv`。实现按窗口计算 incident-edge 最大值，在当前决策后才把 block maximum 放入 FIFO；历史不足 N 时标记 warm-up。

## 2. 必须补写的统一实验 runner

当前代码尚未实现 Paper 2 终稿要求的完整基线、参数冻结、bootstrap 和跨检测器接口。新增 runner 时建议固定如下命令行契约，随后所有论文命令都调用同一入口：

```text
paper2/run_causal_suite.py
  --edge-losses-dir DIR --eval-dir DIR --dataset NAME --epoch auto
  --method {fixed_validation,static_block,sliding_quantile,aci,rolling_rank}
  --alpha FLOAT --window-seconds FLOAT --history-length INT
  --validation-days CSV --test-days CSV --continuous-buffer
  --seed INT --out DIR
```

`--epoch auto` 必须只用 validation mean loss 选 epoch。runner 必须输出逐窗口表，至少包含：窗口起止时间、warm-up、block score、p-value/threshold、alert、alerted node 数、benign/malicious window、首个 true alert 和方法状态。再输出一行 summary：window FPR、FPR/alpha、alarms/day、alerted nodes/day、malicious-window recall、node recall、detection delay、coverage。

在完整 runner 合入前，只能把上节 `run_online.py` 结果当作 rolling-rank 的实现检查，不能宣称已完成 Paper 2 的基线比较。

## 3. 冻结阶段

先创建不可变 protocol 文件，记录：dataset、checkpoint hash、验证选出的 epoch、window width、N、alpha、最小 warm-up、day boundary 规则、tie 规则、空窗口规则和随机种子。协议在打开 test 结果前冻结。

推荐验证网格：

```bash
WINDOWS=(60 300 900 1800 3600)
HISTORY=(20 40 80 160)
ALPHAS=(0.001 0.01 0.05)
SEEDS=(0 1 2 3 4)
```

只用 train/validation timeline 选择一个主 `window_seconds` 和 `history_length`。测试表同时给出预先指定的敏感性曲线，不能从 test 网格中挑最好组合。

## 4. 主 causal comparison

冻结参数后，对每个 dataset/seed 运行五种方法：

```bash
for METHOD in fixed_validation static_block sliding_quantile aci rolling_rank; do
  python paper2/run_causal_suite.py \
    --edge-losses-dir "$EDGE_DIR" --eval-dir "$EVAL_DIR" \
    --dataset CADETS_E3 --epoch auto --method "$METHOD" \
    --alpha 0.01 --window-seconds 900 --history-length 40 \
    --validation-days 03,04,05 --test-days 06,07,08 \
    --continuous-buffer --seed 0 \
    --out "paper2/results/main/CADETS_E3/s0/${METHOD}"
done
```

五种方法必须接收完全相同的 window-local node scores 和 benign/malicious window 定义：

1. `fixed_validation`：验证期阈值固定到 test 结束。
2. `static_block`：预先指定的历史 benign block pool，test 时不更新。
3. `sliding_quantile`：前 N 个 block 的经验分位数。
4. `aci`：Adaptive Conformal Inference；学习率在 validation 冻结。
5. `rolling_rank`：当前 block 与前 N 个已完成 block 做有限样本 conformal rank。

当前窗口只能在决策后写入 history；buffer 跨自然日持续。每日 reset 只能作为消融。

## 5. 必做消融命令

### Causal 与未来泄漏负对照

```bash
for SCORE_SCOPE in window_local whole_trace; do
  python paper2/run_causal_suite.py ... --score-scope "$SCORE_SCOPE" \
    --method rolling_rank --out "paper2/results/ablation/scope_${SCORE_SCOPE}"
done
```

`whole_trace` 只量化未来信息造成的偏差，不能作为有效在线方法。

### 连续 buffer 与每日 reset

```bash
python paper2/run_causal_suite.py ... --continuous-buffer --method rolling_rank \
  --out paper2/results/ablation/continuous
python paper2/run_causal_suite.py ... --reset-each-day --method rolling_rank \
  --out paper2/results/ablation/daily_reset
```

同时报告 warm-up 覆盖率和 warm-up 内是否存在攻击窗口。

### Window width、N 与聚合函数

```bash
for W in 60 300 900 1800 3600; do
  for N in 20 40 80 160; do
    for AGG in max q95 topk_mean; do
      python paper2/run_causal_suite.py ... --method rolling_rank \
        --window-seconds "$W" --history-length "$N" --score-aggregation "$AGG" \
        --out "paper2/results/ablation/w${W}_n${N}_${AGG}"
    done
  done
done
```

`max` 是论文主定义；其他聚合仅作为敏感性分析。

### Seen/unseen 与类型分层

```bash
for STRAT in global novelty node_type novelty_x_type; do
  python paper2/run_causal_suite.py ... --method rolling_rank \
    --stratification "$STRAT" --min-stratum-size 2000 \
    --out "paper2/results/ablation/strat_${STRAT}"
done
```

报告每层 population share、conditional FPR 和 fallback 到 global pool 的比例。不能把 novelty 的相关性写成因果关系。

## 6. Calibration contamination

受控污染至少覆盖 prevalence 与 score magnitude 两轴，并含低分、普通分、高分及自适应注入：

```bash
for RATE in 0 0.001 0.005 0.01 0.05 0.10; do
  for SCALE in 0.5 1.0 2.0 5.0; do
    python paper2/run_causal_suite.py ... --method rolling_rank \
      --contamination-rate "$RATE" --contamination-scale "$SCALE" \
      --contamination-seed 0 \
      --out "paper2/results/contam/r${RATE}_x${SCALE}"
  done
done
```

攻击 block 必须按协议注入并在实验后用标签审计；部署算法不得用标签清除 buffer。报告污染使方法变得保守还是反保守，不预设方向。

## 7. 跨 collector 与跨 detector

### 跨 collector

固定源 collector 的 calibration state，在目标 collector 不调参直接测试：

```bash
python paper2/run_causal_suite.py \
  --edge-losses-dir "$TARGET_EDGE_DIR" --eval-dir "$TARGET_EVAL_DIR" \
  --dataset THEIA_E3 --epoch "$SOURCE_SELECTED_EPOCH" \
  --method fixed_validation --external-calibration "$CADETS_CALIBRATION_FILE" \
  --alpha 0.01 --window-seconds 900 --history-length 40 \
  --test-days 10,12 --seed 0 --out paper2/results/cross/CADETS_to_THEIA
```

这项是 stress test。失败结果说明源阈值不能安全迁移，不能推断所有目标域适配方法都失败。

### 跨 detector

至少加入 THREATRACE 和 KAIROS，使用统一中间格式：

```text
window_id,time,srcnode,dstnode,loss,detector,dataset,split
```

转换后运行同一 causal suite：

```bash
for DETECTOR in orthrus threatrace kairos; do
  python paper2/run_causal_suite.py \
    --edge-losses-dir "paper2/score_traces/${DETECTOR}" \
    --eval-dir "paper2/labels/${DETECTOR}" --dataset CADETS_E3 \
    --epoch frozen --method rolling_rank --alpha 0.01 \
    --window-seconds 900 --history-length 40 --seed 0 \
    --out "paper2/results/detectors/${DETECTOR}"
done
```

在这两个额外 detector 的真实 score trace 完成前，论文应写“score-level interface”，不能写“已证明 detector-independent”。

## 8. 攻击检测与重构

每种 calibrator 都会改变 seed set，因此必须重新运行 precision、recall、MCC、QoA 与 attack reconstruction。不能沿用旧阈值下的 reconstruction 数字。保存每个窗口的 flagged node CSV，并将其作为唯一 seed 输入。

`export_flagged_seeds.py` 与 ORTHRUS 的 `external_seeds` 接口目前尚未实现；在接口合入前不要声称已完成重构重跑。

## 9. 统计、等效性与效率

- 以 day 或独立 trace 为 bootstrap block，不能按 node 独立重采样。
- 主终点：benign-window FPR；次终点：alarms/day、alerted nodes/day、malicious-window recall、node recall、delay、coverage。
- 在看 test 前定义等效带，例如 `alpha ± max(0.2*alpha, 0.002)`。只有整个 CI 落入等效带才称为 empirical calibration；CI 覆盖 alpha 不足以证明等效。
- 报告端到端额外延迟、峰值内存、窗口吞吐和 history 更新成本。
- 对每个 dataset/seed/day 发布原始逐窗口结果，不只发布平均值。

## 10. 论文填表顺序与验收

先用因果回归测试证明“修改未来窗口不会改变任何过去 score/alarm”；再冻结协议；然后生成主比较、参数敏感性、污染、跨 collector、跨 detector、重构与效率表。最后替换 LaTeX 中所有 `TBD after causal re-run`。

Paper 2 达到高水平投稿证据所需的最低条件是：主 causal runner 与回归测试公开；rolling 方法在多个 dataset/seed 上相对匹配基线改善 FPR 偏差，同时不显著牺牲攻击 recall；结论经 day/trace block CI 支持；污染和 warm-up 失败模式被披露；至少两个额外 detector 验证 score-level 可移植性。代码机制本身或单个 CADETS 结果不能替代这些证据。
