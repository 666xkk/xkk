"""Paper-1 masking integration smoke test.
Run from repo root:  PYTHONPATH=. python tools/mask_smoke.py CADETS_E3
Checks: masking branch executes (catches missing attrs, e.g. self.num_nodes),
>=1 batch had masked arcs, recovery losses present in last_loss_parts, backward OK.
"""
import os, sys
REPO = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
for p in (REPO, os.path.join(REPO, "src")):
    if p not in sys.path:
        sys.path.insert(0, p)

import torch
from src.config import get_runtime_required_args, get_yml_cfg
from src.data_utils import load_all_datasets
from src.factory import build_model, batch_loader_factory
from src.provnet_utils import get_device, log


def main():
    args = get_runtime_required_args()
    cfg = get_yml_cfg(args)
    assert cfg.detection.gnn_training.mask.enabled, "enable mask first"
    device = get_device(cfg)

    train_data, _, _, full_data, max_node_num = load_all_datasets(cfg)
    model = build_model(data_sample=train_data[0], device=device, cfg=cfg,
                        max_node_num=max_node_num)
    model.train()
    model.encoder.reset_state()

    g = train_data[0].to(device)
    loader = batch_loader_factory(cfg, g, model.graph_reindexer)
    seen_mask, checked = False, 0
    for i, batch in enumerate(loader):
        loss = model(batch, full_data)
        if loss.requires_grad:
            loss.backward()
        stats = getattr(model.encoder, "_last_mask_stats", {}) or {}
        parts = {k: round(float(v), 4) for k, v in (model.last_loss_parts or {}).items()}
        log(f"[batch {i}] loss={float(loss):.4f} grad={bool(loss.requires_grad)} parts={parts} stats={stats}")
        if stats.get("n_groups_masked", 0) > 0:
            seen_mask = True
            if cfg.detection.gnn_training.mask.link_loss_weight > 0:
                assert "link" in parts, "link loss missing"
            if cfg.detection.gnn_training.mask.time_loss_weight > 0:
                assert "time" in parts, "time loss missing"
        checked += 1
        if checked >= 8:
            break
    assert seen_mask, "no arc-groups masked in 8 batches; check config/context"
    log("[mask_smoke] OK: masking runs, losses present, backward OK.")


if __name__ == "__main__":
    main()