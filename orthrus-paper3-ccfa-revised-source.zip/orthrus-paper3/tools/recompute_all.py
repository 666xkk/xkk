#!/usr/bin/env python
"""从 result_*.pth 重算所有 run 的逐 epoch MCC（stats_*.pth 不可信）"""
import glob, os, re
import numpy as np, torch
from sklearn.metrics import roc_auc_score, average_precision_score
def mcc_auc(path):
    r = torch.load(path, map_location="cpu")
    y  = np.array([int(v.get("y_true", 0)) for v in r.values()], dtype=bool)
    yh = np.array([int(v.get("y_hat", 0)) for v in r.values()], dtype=bool)
    sc = np.array([float(v.get("score", 0.0)) for v in r.values()])
    tp=int((y&yh).sum()); fp=int((~y&yh).sum()); fn=int((y&~yh).sum()); tn=int((~y&~yh).sum())
    den=((tp+fp)*(tp+fn)*(tn+fp)*(tn+fn))**0.5
    mcc=(tp*tn-fp*fn)/den if den else 0.0
    auc=roc_auc_score(y,sc) if y.sum() and (~y).sum() else float("nan")
    ap =average_precision_score(y,sc) if y.sum() else float("nan")
    return mcc,tp,fp,auc,ap
for d in sorted(glob.glob("artifacts/detection/evaluation/*/CADETS_E3/precision_recall_dir")):
    h = d.split("/")[3][:8]
    rows=[]
    for f in glob.glob(os.path.join(d,"result_model_epoch_*.pth")):
        ep=int(re.search(r"model_epoch_(\d+)",f).group(1))
        rows.append((ep,)+mcc_auc(f))
    if not rows: continue
    rows.sort()
    b=max(rows,key=lambda r:r[1]); ba=max(rows,key=lambda r:r[4])
    print(f"\n{h}  bestMCC=ep{b[0]} {b[1]:.4f} (tp{b[2]}/fp{b[3]})  bestAUC=ep{ba[0]} {ba[4]:.4f}")
    print("  mcc: "+" ".join(f"{e}:{m:.3f}" for e,m,_,_,_,_ in rows))
    print("  auc: "+" ".join(f"{e}:{a:.3f}" for e,_,_,_,a,_ in rows))
