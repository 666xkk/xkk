"""tools/rq12_novelty_attrib.py — 把 alpha 门限下的 FP 归因到"校准集是否见过该节点"

用法:
  python tools/rq12_novelty_attrib.py \
    --edge-losses-dir artifacts/.../f4d0127f.../CADETS_E3/edge_losses \
    --eval-dir artifacts/.../3c19a0c6.../CADETS_E3/precision_recall_dir \
    --alpha 0.01
"""
import argparse
import glob
import os

import numpy as np
import pandas as pd
import torch


def node_scores(edge_dir, split, epoch):
    d = os.path.join(edge_dir, split, epoch)
    files = sorted(glob.glob(os.path.join(d, "*.csv")))
    if not files:
        raise SystemExit(f"[novelty] FATAL: no csv under {d}")
    best = {}
    for f in files:
        df = pd.read_csv(f, usecols=["loss", "srcnode", "dstnode"])
        for col in ("srcnode", "dstnode"):
            g = df.groupby(col)["loss"].max()
            for n, v in g.items():
                n, v = int(n), float(v)
                if v > best.get(n, -1.0):
                    best[n] = v
    print(f"[novelty] {split}/{epoch}: {len(files)} csv -> {len(best)} nodes")
    return pd.Series(best, dtype="float64")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--edge-losses-dir", required=True)
    ap.add_argument("--eval-dir", required=True)
    ap.add_argument("--epoch", default=None)
    ap.add_argument("--alpha", type=float, default=0.01)
    ap.add_argument("--out", default="paper2/results")
    a = ap.parse_args()

    if a.epoch is None:
        cands = glob.glob(os.path.join(a.eval_dir, "stats_*.pth"))
        a.epoch = os.path.basename(
            max(cands, key=lambda p: torch.load(p, map_location="cpu").get("mcc", -1))
        )[len("stats_"):-len(".pth")]
    raw = torch.load(os.path.join(a.eval_dir, f"result_{a.epoch}.pth"), map_location="cpu")
    y = {int(k): int(v.get("y_true", 0)) for k, v in raw.items()}
    print(f"[novelty] epoch={a.epoch}  {len(y)} nodes, {sum(y.values())} malicious")

    val = node_scores(a.edge_losses_dir, "val", a.epoch)
    tst = node_scores(a.edge_losses_dir, "test", a.epoch)

    thr = float(np.quantile(val.values, 1.0 - a.alpha))
    print(f"[novelty] alpha={a.alpha}  threshold={thr:.6f}  (val p{100*(1-a.alpha):.1f})")

    seen = set(int(n) for n in val.index)
    ids = tst.index.to_numpy()
    lab = np.array([y.get(int(n), 0) for n in ids])
    flg = tst.values > thr
    sn = np.array([int(n) in seen for n in ids])

    total_fp = int(flg[lab == 0].sum())
    rows = []
    for name, m in (("seen_in_val", sn), ("unseen", ~sn)):
        for kind, km in (("benign", lab == 0), ("malicious", lab == 1)):
            sel = m & km
            rows.append(dict(group=name, kind=kind, n=int(sel.sum()),
                             flagged=int(flg[sel].sum()),
                             rate=round(float(flg[sel].mean()), 6) if sel.sum() else float("nan")))
        n_fp = int((flg & (lab == 0) & m).sum())
        rows.append(dict(group=name, kind="share_of_benign_FP", n=total_fp,
                         flagged=n_fp,
                         rate=round(n_fp / total_fp, 4) if total_fp else float("nan")))

    df = pd.DataFrame(rows)
    print("\n" + df.to_string(index=False))
    os.makedirs(a.out, exist_ok=True)
    p = os.path.join(a.out, f"novelty_attrib_{a.epoch}_a{a.alpha}.csv")
    df.to_csv(p, index=False)
    print(f"\n[novelty] wrote {p}")


if __name__ == "__main__":
    main()