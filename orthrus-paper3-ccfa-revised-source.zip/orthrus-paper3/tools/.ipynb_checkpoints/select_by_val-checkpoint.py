"""tools/select_by_val.py — 三种选模口径对比（不重训/不重评测）
  A 测试MCC argmax（现行，有泄漏）  B val-loss argmin（干净）  C 末轮（无关选择）  D 全轮均值
用法: python tools/select_by_val.py CADETS_E3
"""
import glob, os, sys
import pandas as pd
import torch

DS = sys.argv[1] if len(sys.argv) > 1 else "CADETS_E3"
mt = os.path.getmtime


def mean_val_loss(val_dir, epoch):
    d = os.path.join(val_dir, epoch)
    if not os.path.isdir(d):
        return None
    tot = n = 0
    for f in os.listdir(d):
        if not f.endswith(".csv"):
            continue
        df = pd.read_csv(os.path.join(d, f))
        tot += float(df["loss"].sum()); n += len(df)
    return tot / n if n else None


evals = sorted(glob.glob(f"artifacts/detection/evaluation/*/{DS}/precision_recall_dir"))
edges = sorted(glob.glob(f"artifacts/detection/gnn_testing/*/{DS}/edge_losses"))
print(f"eval dirs={len(evals)}  edge_losses dirs={len(edges)}")

rows = []
for ev in evals:
    edge = min(edges, key=lambda e: abs(mt(e) - mt(ev)))   # 同一次 run，按时间最近配对
    stats = {}
    for f in glob.glob(os.path.join(ev, "stats_*.pth")):
        ep = os.path.basename(f)[len("stats_"):-len(".pth")]
        stats[ep] = torch.load(f, map_location="cpu")
    if not stats:
        continue
    eps = sorted(stats, key=lambda e: int(e.split("_")[-1]))
    mcc = {e: float(stats[e].get("mcc", float("nan"))) for e in eps}

    epA = max(eps, key=lambda e: mcc[e])                    # A 测试 argmax
    vl = {e: mean_val_loss(os.path.join(edge, "val"), e) for e in eps}
    vl = {e: v for e, v in vl.items() if v is not None}
    epB = min(vl, key=vl.get) if vl else None               # B val argmin
    epC = eps[-1]                                            # C 末轮

    rows.append(dict(
        hash=ev.split("/")[-3][:8], n_ep=len(eps),
        A_ep=epA, A_mcc=round(mcc[epA], 4),
        B_ep=epB, B_mcc=round(mcc[epB], 4) if epB else None,
        C_ep=epC, C_mcc=round(mcc[epC], 4),
        D_mean=round(sum(mcc.values()) / len(mcc), 4),
    ))

df = pd.DataFrame(rows).sort_values("hash")
print("\n=== 每个 run ===")
print(df.to_string(index=False))
print("\n=== 汇总 ===")
for c in ["A_mcc", "B_mcc", "C_mcc", "D_mean"]:
    v = pd.to_numeric(df[c], errors="coerce").dropna()
    if len(v):
        print(f"{c}: mean={v.mean():.4f}  sd={v.std():.4f}  min={v.min():.4f}  max={v.max():.4f}")
df.to_csv(f"runs/protocol_{DS}.csv", index=False)
print(f"\nwrote runs/protocol_{DS}.csv")