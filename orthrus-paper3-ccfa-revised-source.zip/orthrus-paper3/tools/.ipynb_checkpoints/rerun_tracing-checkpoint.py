"""Re-run ONLY the attack-reconstruction (tracing) stage.

Two modes:
  (default) auto-discover the most recent COMPLETE artifacts under ./artifacts
  (explicit) --trace-eval-dir / --trace-edge-losses-dir

No retraining, no re-testing. Requires:
  <edge_losses>/test/<epoch_dir>/*.csv
  <eval_dir>/result_<epoch_dir>.pth , stats_<epoch_dir>.pth

Usage:
  PYTHONHASHSEED=0 python -u tools/rerun_tracing.py CADETS_E3 \
    --detection.evaluation.node_evaluation.use_kmeans=false \
    --attack_reconstruction.tracing.depimpact.score_method=degree_recon \
    2>&1 | tee runs/cadets_e3_trace_degree_recon.log
"""
import glob
import os
import sys

REPO = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
for p in (REPO, os.path.join(REPO, "src")):
    if p not in sys.path:
        sys.path.insert(0, p)

from src.config import get_runtime_required_args, get_yml_cfg
from src.provnet_utils import log
from src.attack_reconstruction import tracing
# tools/rerun_tracing.py，在 tracing.main(cfg) 之前


def _newest_complete(pattern, must_contain):
    """Newest dir matching `pattern` that actually contains `must_contain`."""
    cands = []
    for d in glob.glob(pattern):
        if os.path.isdir(d) and os.path.isdir(os.path.join(d, must_contain)):
            # require at least one non-empty epoch subdir
            subs = [s for s in os.listdir(os.path.join(d, must_contain))
                    if os.path.isdir(os.path.join(d, must_contain, s))]
            if subs:
                cands.append((os.path.getmtime(d), d))
    if not cands:
        return None
    cands.sort()
    return cands[-1][1]


def _discover(cfg):
    ds = cfg.dataset.name
    root = cfg._artifact_dir
    edge = _newest_complete(
        os.path.join(root, "detection", "gnn_testing", "*", ds, "edge_losses"), "test")
    evald = _newest_complete(
        os.path.join(root, "detection", "evaluation", "*", ds, "precision_recall_dir"), "")
    # precision_recall_dir has no subdirs -> relax the completeness test
    if evald is None:
        cands = [p for p in glob.glob(
            os.path.join(root, "detection", "evaluation", "*", ds, "precision_recall_dir"))
            if any(f.startswith("result_") and f.endswith(".pth") for f in os.listdir(p))]
        evald = max(cands, key=os.path.getmtime) if cands else None
    return edge, evald


def main():
    args = get_runtime_required_args()
    cfg = get_yml_cfg(args)

    edge_override = getattr(args, "trace_edge_losses_dir", None)
    eval_override = getattr(args, "trace_eval_dir", None)

    if edge_override:
        edge = os.path.abspath(edge_override)
    else:
        edge, _ = _discover(cfg)

    if eval_override:
        evald = os.path.abspath(eval_override)
    else:
        _, evald = _discover(cfg)

    if not edge or not os.path.isdir(os.path.join(edge, "test")):
        raise SystemExit(f"[rerun_tracing] FATAL: no usable edge_losses/test at {edge}")
    if not evald or not any(f.startswith("result_") for f in os.listdir(evald)):
        raise SystemExit(f"[rerun_tracing] FATAL: no result_*.pth at {evald}")

    # override the hash-derived paths
    cfg.detection.gnn_testing._edge_losses_dir = edge
    cfg.detection.evaluation.node_evaluation._precision_recall_dir = evald

    log("[rerun_tracing] eval dir    : " + evald)
    log("[rerun_tracing] edge losses : " + edge)
    log("[rerun_tracing] epochs (test): " +
        str(sorted(os.listdir(os.path.join(edge, "test")))))
    log("[rerun_tracing] score_method: " +
        cfg.attack_reconstruction.tracing.depimpact.score_method)
    log("[rerun_tracing] used_method : " +
        cfg.attack_reconstruction.tracing.depimpact.used_method)
    log("[rerun_tracing] tracing out : " +
        cfg.attack_reconstruction.tracing._tracing_graph_dir)
    
    import wandb
    wandb.init(mode="disabled")      # 不联网、不写文件，只为让 wandb.log 不报错
    tracing.main(cfg)


if __name__ == "__main__":
    main()