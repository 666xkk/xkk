#!/usr/bin/env python
"""tools/arm_auc.py — 从 result_*.pth 重算 AUC/AP/recall@FPR（不依赖 edge_losses）"""
import glob, os
import numpy as np, pandas as pd, torch
from sklearn.metrics import roc_auc_score, average_precision_score
GRID = np.array([1e-4, 1e-3, 1e-2, 5e-2])
def recall_at(s, y, grid):
    o = np.argsort(-s); ys = y[o]
    tp = np.cumsum(ys); fp = np.cumsum(~ys)
    return np.interp(grid, fp / (~y).sum(), tp / y.sum())
rows = []
import itertools
ROOTS = ["artifacts/detection/evaluation", "artifacts/detection/evaluation_local"]
fordirs = itertools.chain(*[glob.glob(r + "/*/CADETS_E3/precision_recall_dir") for r in ROOTS])
for d in sorted(fordirs):
    st = glob.glob(os.path.join(d, "stats_*.pth"))
    if not st:
        continue
    best = max(st, key=lambda p: torch.load(p, map_location="cpu").get("mcc", -1))
    ep = os.path.basename(best)[6:-4]
    rp = os.path.join(d, f"result_{ep}.pth")
    if not os.path.exists(rp):
        continue
    raw = torch.load(rp, map_location="cpu")
    y = np.array([int(v.get("y_true", 0)) for v in raw.values()], dtype=bool)
    s = np.array([float(v.get("score", 0.0)) for v in raw.values()], dtype=np.float64)
    if y.sum() == 0 or (~y).sum() == 0:
        continue
    r = recall_at(s, y, GRID)
    st0 = torch.load(best, map_location="cpu")
    rows.append(dict(eval=d.split("/")[3][:8], epoch=ep,
                     mcc=round(float(st0.get("mcc", float("nan"))), 4),
                     tp=st0.get("tp"), fp=st0.get("fp"),
                     auc=round(float(roc_auc_score(y, s)), 4),
                     ap=round(float(average_precision_score(y, s)), 4),
                     r_1e4=round(float(r[0]), 4), r_1e3=round(float(r[1]), 4),
                     r_1e2=round(float(r[2]), 4), r_5e2=round(float(r[3]), 4)))
df = pd.DataFrame(rows).sort_values("mcc", ascending=False)
print(df.to_string(index=False))
df.to_csv("runs/arm_auc.csv", index=False)
print("\nwrote runs/arm_auc.csv")
