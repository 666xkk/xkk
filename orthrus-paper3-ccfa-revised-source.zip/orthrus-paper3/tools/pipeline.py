import os, sys, inspect

REPO = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
for p in (REPO, os.path.join(REPO, "src")):
    if p not in sys.path:
        sys.path.insert(0, p)

import wandb
wandb.init(mode="disabled")

from src.config import get_runtime_required_args, get_yml_cfg
from src.provnet_utils import log

TRAIN_ONLY = "--train-only" in sys.argv
while "--train-only" in sys.argv:
    sys.argv.remove("--train-only")

cfg = get_yml_cfg(get_runtime_required_args())

g = cfg.graph_construction.build_graphs._graphs_dir
e = cfg.edge_featurization.embed_edges._edge_embeds_dir
log("[pipeline] graphs = %s  exists=%s" % (g, os.path.isdir(g)))
log("[pipeline] embeds = %s  exists=%s" % (e, os.path.isdir(e)))
if not (os.path.isdir(g) and os.path.isdir(e)):
    log("[pipeline][FATAL] upstream missing - params mismatch with cache")
    sys.exit(2)

from src.detection import orthrus_gnn_training, orthrus_gnn_testing, evaluation

def _run(mod):
    return mod.main() if len(inspect.signature(mod.main).parameters) == 0 else mod.main(cfg)

log("[pipeline] === gnn_training ===")
_run(orthrus_gnn_training)

if TRAIN_ONLY:
    log("[pipeline] train-only: stop here")
    sys.exit(0)

log("[pipeline] === gnn_testing ===")
_run(orthrus_gnn_testing)

log("[pipeline] === evaluation ===")
_run(evaluation)

try:
    from src.attack_reconstruction import tracing
    log("[pipeline] === tracing ===")
    _run(tracing)
except Exception as ex:
    log("[pipeline] tracing skipped: %s" % ex)

log("[pipeline] ALL DONE")
