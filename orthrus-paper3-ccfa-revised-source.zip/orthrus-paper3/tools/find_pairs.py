import glob, os, torch
evals = sorted(glob.glob("artifacts/detection/evaluation/*/CADETS_E3/precision_recall_dir"))
edges = sorted(glob.glob("artifacts/detection/gnn_testing/*/CADETS_E3/edge_losses"))
out = []
for ev in evals:
    st = glob.glob(os.path.join(ev, "stats_*.pth"))
    if not st:
        continue
    best = os.path.basename(max(st, key=lambda p: torch.load(p, map_location="cpu").get("mcc", -1)))[6:-4]
    if not os.path.exists(os.path.join(ev, f"result_{best}.pth")):
        continue
    cand = [d for d in edges
            if os.path.isdir(os.path.join(d, "val", best))
            and os.path.isdir(os.path.join(d, "test", best))]
    if not cand:
        print(f"[skip] no edge_losses with epoch {best} for {ev}", flush=True)
        continue
    ed = min(cand, key=lambda d: abs(os.path.getmtime(d) - os.path.getmtime(ev)))
    mcc = torch.load(os.path.join(ev, f"stats_{best}.pth"), map_location="cpu").get("mcc", float("nan"))
    print(f"[pair] epoch={best:<18} mcc={mcc:.4f}  {ev.split('/')[-3][:8]} -> {ed.split('/')[-3][:8]}", flush=True)
    out.append(f"{ev}:{ed}")
if out:
    print("PAIRS=" + ",".join(out))
