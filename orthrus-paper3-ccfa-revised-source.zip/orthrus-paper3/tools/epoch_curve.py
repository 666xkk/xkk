#!/usr/bin/env python
"""tools/epoch_curve.py — 每个 epoch 的节点级 MCC/TP/FP/AUC（判定 undertrain vs 选模错）"""
import glob, os
import numpy as np, torch
from sklearn.metrics import roc_auc_score
for d in sorted(glob.glob("artifacts/detection/evaluation/*/CADETS_E3/precision_recall_dir")):
    rows = []
    for f in glob.glob(os.path.join(d, "stats_*.pth")):
        ep = int(f.split("_")[-1][:-4])
        s = torch.load(f, map_location="cpu")
        rp = os.path.join(d, f"result_model_epoch_{ep}.pth")
        auc = float("nan")
        if os.path.exists(rp):
            r = torch.load(rp, map_location="cpu")
            y = np.array([int(v.get("y_true", 0)) for v in r.values()], dtype=bool)
            sc = np.array([float(v.get("score", 0.0)) for v in r.values()])
            if y.sum() > 0 and (~y).sum() > 0:
                auc = roc_auc_score(y, sc)
        rows.append((ep, float(s.get("mcc", float("nan"))), s.get("tp"), s.get("fp"), auc))
    if not rows:
        continue
    rows.sort()
    best = max(rows, key=lambda r: r[1])
    h = d.split("/")[3][:8]
    print(f"\n{h}  best_ep={best[0]} mcc={best[1]:.4f}")
    print("  mcc: " + " ".join(f"{e}:{m:.3f}" for e, m, _, _, _ in rows))
    print("  auc: " + " ".join(f"{e}:{a:.3f}" for e, _, _, _, a in rows))
    print(f"  ep1 mcc={rows[0][1]:.4f} auc={rows[0][4]:.4f} | "
          f"ep20 mcc={rows[-1][1]:.4f} auc={rows[-1][4]:.4f} | "
          f"max_auc={max(r[4] for r in rows):.4f}")
