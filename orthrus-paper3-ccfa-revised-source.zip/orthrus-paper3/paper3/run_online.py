"""Causal Paper-2 window calibration retained as Paper-3 seed apparatus."""
import argparse
import glob
import os
import sys

import numpy as np
import pandas as pd

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from calibrated_seeds import causal_seed_pvalues, node_scores


def load_windows(root, split, epoch):
    loaded = []
    for path in glob.glob(os.path.join(root, split, epoch, "*.csv")):
        frame = pd.read_csv(path, usecols=["srcnode", "dstnode", "loss", "time"])
        start = float(frame.time.min()) if len(frame) else float("inf")
        loaded.append((start, os.path.basename(path),
                       node_scores(frame.srcnode, frame.dstnode, frame.loss)))
    return [(name, scores) for _, name, scores in sorted(loaded)]


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--dataset", required=True)
    ap.add_argument("--edge-losses", required=True)
    ap.add_argument("--eval-dir", default="")
    ap.add_argument("--epoch", required=True)
    ap.add_argument("--history-length", type=int, default=40)
    ap.add_argument("--alpha", type=float, default=0.05)
    ap.add_argument("--out", default="paper3/results")
    args = ap.parse_args()

    stream = load_windows(args.edge_losses, "test", args.epoch)
    decisions = causal_seed_pvalues(stream, args.history_length)
    labels = load_labels(args.eval_dir, args.epoch) if args.eval_dir else {}
    rows = []
    for (window, scores), (_, pvalues) in zip(stream, decisions):
        if not pvalues:
            rows.append(dict(window=window, warmup=True, window_alert=False,
                             benign_window=np.nan, malicious_window=np.nan,
                             n_alerted_nodes=0))
            continue
        alerted = {node for node, pvalue in pvalues.items() if pvalue <= args.alpha}
        malicious_nodes = {node for node in scores if labels.get(node, 0) == 1}
        rows.append(dict(window=window, warmup=False,
                         window_alert=bool(alerted),
                         benign_window=not bool(malicious_nodes) if labels else np.nan,
                         malicious_window=bool(malicious_nodes) if labels else np.nan,
                         n_alerted_nodes=len(alerted),
                         n_true_alerted=len(alerted & malicious_nodes) if labels else np.nan))
    frame = pd.DataFrame(rows)
    scored = frame[~frame.warmup]
    summary = dict(dataset=args.dataset, epoch=args.epoch,
                   history_length=args.history_length, alpha=args.alpha,
                   n_windows=len(frame), n_scored_windows=len(scored),
                   coverage=len(scored) / len(frame) if len(frame) else np.nan)
    if labels:
        benign = scored[scored.benign_window == True]  # noqa: E712
        malicious = scored[scored.malicious_window == True]  # noqa: E712
        summary["window_fpr"] = float(benign.window_alert.mean()) if len(benign) else np.nan
        summary["window_recall"] = float(malicious.window_alert.mean()) if len(malicious) else np.nan
    os.makedirs(args.out, exist_ok=True)
    frame.to_csv(os.path.join(args.out, f"causal_online_{args.dataset}_{args.epoch}.csv"), index=False)
    pd.DataFrame([summary]).to_csv(
        os.path.join(args.out, f"causal_online_summary_{args.dataset}_{args.epoch}.csv"), index=False)
    print(pd.Series(summary).to_string())


def load_labels(eval_dir, epoch):
    import torch
    raw = torch.load(os.path.join(eval_dir, f"result_{epoch}.pth"), map_location="cpu")
    return {int(node): int(value.get("y_true", 0)) for node, value in raw.items()}


if __name__ == "__main__":
    main()
