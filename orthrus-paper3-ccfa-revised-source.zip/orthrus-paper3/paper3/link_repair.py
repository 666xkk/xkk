"""Leak-tight primitives for calibrated, budgeted provenance-link repair.

Paper 1 supplies a masked-link compatibility score. Paper 2 supplies causal
node p-values. Paper 3 combines them to rank temporally feasible missing links
under a fixed investigation budget. This module is NumPy-only for unit tests.
"""
from __future__ import annotations

from collections import defaultdict, deque

import numpy as np

NEG_INF = float("-inf")


def _pairs(values):
    a = np.asarray(values, dtype=int)
    return a.reshape(-1, 2) if a.size else np.zeros((0, 2), dtype=int)


def temporal_mask(seeds, node_tmin, node_tmax, max_gap):
    """Return nodes whose activity interval is within ``max_gap`` of a seed."""
    seeds = np.asarray(seeds, dtype=int)
    tmin = np.asarray(node_tmin, dtype=float)
    tmax = np.asarray(node_tmax, dtype=float)
    feasible = np.zeros(len(tmin), dtype=bool)
    for u in seeds:
        feasible |= (tmax >= tmin[u] - max_gap) & (tmin <= tmax[u] + max_gap)
    return feasible


def enumerate_candidates(seeds, node_tmin, node_tmax, visible_edges, max_gap,
                         direction="out"):
    """Enumerate missing directed links incident to calibrated seed nodes."""
    if direction not in {"out", "in", "both"}:
        raise ValueError("direction must be out, in, or both")
    seeds = np.unique(np.asarray(seeds, dtype=int))
    tmin = np.asarray(node_tmin, dtype=float)
    tmax = np.asarray(node_tmax, dtype=float)
    visible = set(map(tuple, _pairs(visible_edges).tolist()))
    candidates = set()
    for u in seeds:
        near = (tmax >= tmin[u] - max_gap) & (tmin <= tmax[u] + max_gap)
        near[u] = False
        for v in np.flatnonzero(near):
            if direction in {"out", "both"} and (int(u), int(v)) not in visible:
                candidates.add((int(u), int(v)))
            if direction in {"in", "both"} and (int(v), int(u)) not in visible:
                candidates.add((int(v), int(u)))
    return _pairs(sorted(candidates))


def score_learned(node_q, node_emb, cand, temperature=0.1):
    """Paper-1 compatibility logit ``dot(query(src), key(dst))/T``."""
    c = _pairs(cand)
    if not len(c):
        return np.zeros(0, dtype=float)
    if temperature <= 0:
        raise ValueError("temperature must be positive")
    q = np.asarray(node_q, dtype=float)
    k = np.asarray(node_emb, dtype=float)
    if q.ndim != 2 or k.ndim != 2 or q.shape != k.shape:
        raise ValueError("query and embedding tables must have equal [N,d] shape")
    q = q / (np.linalg.norm(q, axis=1, keepdims=True) + 1e-12)
    k = k / (np.linalg.norm(k, axis=1, keepdims=True) + 1e-12)
    return np.einsum("ij,ij->i", q[c[:, 0]], k[c[:, 1]]) / temperature


def _undirected_neighbors(edges):
    adj = defaultdict(set)
    for u, v in _pairs(edges):
        if u != v:
            adj[int(u)].add(int(v))
            adj[int(v)].add(int(u))
    return adj


def score_structural(visible_edges, cand):
    """Adamic--Adar support for an absent link.

    The old exact-edge frequency baseline was identically zero because visible
    edges had already been removed from the candidate pool.
    """
    adj = _undirected_neighbors(visible_edges)
    out = []
    for u, v in _pairs(cand):
        common = adj[int(u)] & adj[int(v)]
        out.append(sum(1.0 / np.log(max(len(adj[z]), 2) + 1.0) for z in common))
    return np.asarray(out, dtype=float)


def score_allowlist(node_novelty, cand):
    c = _pairs(cand)
    return np.asarray(node_novelty, dtype=float)[c[:, 1]] if len(c) else np.zeros(0)


def score_linear(node_feat, cand):
    c = _pairs(cand)
    if not len(c):
        return np.zeros(0)
    f = np.asarray(node_feat, dtype=float)
    f = f / (np.linalg.norm(f, axis=1, keepdims=True) + 1e-12)
    return np.einsum("ij,ij->i", f[c[:, 0]], f[c[:, 1]])


def _adj(edges, directed=False):
    adj = defaultdict(list)
    for u, v in _pairs(edges):
        adj[int(u)].append(int(v))
        if not directed:
            adj[int(v)].append(int(u))
    return adj


def score_bfs(visible_edges, seeds, cand, n_nodes, max_hops=8, temporal=False,
              edge_time=None):
    """BFS/TBFS; TBFS follows directed, nondecreasing-time edges."""
    del n_nodes
    edges = _pairs(visible_edges)
    seeds = np.unique(np.asarray(seeds, dtype=int))
    adj = _adj(edges, directed=temporal)
    edge_time = edge_time or {}
    best = {int(s): (0, NEG_INF) for s in seeds}
    queue = deque((int(s), 0, NEG_INF) for s in seeds)
    while queue:
        u, hops, last_t = queue.popleft()
        if hops >= max_hops:
            continue
        for v in adj.get(u, []):
            t = float(edge_time.get((u, v), 0.0)) if temporal else last_t
            if temporal and t < last_t:
                continue
            new_hops = hops + 1
            old = best.get(v)
            if old is not None and old[0] <= new_hops:
                continue
            best[v] = (new_hops, t)
            queue.append((v, new_hops, t))
    return np.asarray([-best.get(int(v), (max_hops + 1, 0))[0]
                       for _, v in _pairs(cand)], dtype=float)


def _robust_z(values):
    x = np.asarray(values, dtype=float)
    if not len(x):
        return x
    finite = x[np.isfinite(x)]
    med = np.median(finite) if len(finite) else 0.0
    mad = np.median(np.abs(finite - med)) if len(finite) else 0.0
    scale = max(1.4826 * mad, 1e-12)
    return np.nan_to_num((x - med) / scale, nan=0.0, posinf=20.0, neginf=-20.0)


def score_calibrated_fusion(learned_scores, cand, seed_pvalues,
                            structural_scores=None, seed_weight=1.0,
                            structural_weight=0.0, p_floor=1e-12):
    """Paper-3 score linking Paper-1 priors with Paper-2 seed evidence.

    Fusion weights must be fixed on validation data. Lower causal seed p-values
    add evidence; robust standardization avoids dataset-specific logit scales.
    """
    c = _pairs(cand)
    learned = _robust_z(learned_scores)
    p = np.asarray(seed_pvalues, dtype=float)
    # Candidate generation can emit seed->node, node->seed, or both.  Use the
    # stronger calibrated endpoint evidence instead of assuming the seed is src.
    endpoint_p = np.minimum(p[c[:, 0]], p[c[:, 1]])
    seed_evidence = -np.log(np.clip(endpoint_p, p_floor, 1.0))
    score = learned + float(seed_weight) * seed_evidence
    if structural_scores is not None and structural_weight:
        score += float(structural_weight) * _robust_z(structural_scores)
    return score


def conformal_edge_pvalues(calibration_null_scores, test_scores):
    """Finite-sample p-values for high compatibility under a non-edge null."""
    cal = np.sort(np.asarray(calibration_null_scores, dtype=float))
    test = np.asarray(test_scores, dtype=float)
    if not len(cal):
        raise ValueError("calibration null scores must be non-empty")
    n_ge = len(cal) - np.searchsorted(cal, test, side="left")
    return (1.0 + n_ge) / (len(cal) + 1.0)


def bh_select(pvalues, alpha):
    """Benjamini--Hochberg selection mask."""
    p = np.asarray(pvalues, dtype=float)
    if not 0 < alpha < 1:
        raise ValueError("alpha must lie in (0,1)")
    order = np.argsort(p, kind="stable")
    passed = p[order] <= alpha * np.arange(1, len(p) + 1) / max(len(p), 1)
    out = np.zeros(len(p), dtype=bool)
    if passed.any():
        out[order[: np.flatnonzero(passed)[-1] + 1]] = True
    return out


def candidate_coverage(cand, ground_truth_pairs):
    candidates = set(map(tuple, _pairs(cand).tolist()))
    gt = set(map(tuple, _pairs(ground_truth_pairs).tolist()))
    covered = len(candidates & gt)
    return dict(total_gt=len(gt), covered_gt=covered,
                coverage=covered / len(gt) if gt else float("nan"))


def budget_frontier(scores, cand, ground_truth_pairs, B_grid):
    """Matched-budget metrics with candidate coverage separated from ranking."""
    scores = np.asarray(scores, dtype=float)
    cand = _pairs(cand)
    if len(scores) != len(cand):
        raise ValueError("one score is required per candidate")
    gt = set(map(tuple, _pairs(ground_truth_pairs).tolist()))
    eligible = gt & set(map(tuple, cand.tolist()))
    order = np.argsort(-scores, kind="stable")
    grid, recall, conditional, precision, hits, selected = [], [], [], [], [], []
    for budget in B_grid:
        budget = max(int(budget), 0)
        k = min(budget, len(cand))
        chosen = cand[order[:k]]
        hit = sum(tuple(p) in gt for p in chosen.tolist())
        grid.append(budget)
        selected.append(k)
        hits.append(hit)
        recall.append(hit / len(gt) if gt else float("nan"))
        conditional.append(hit / len(eligible) if eligible else float("nan"))
        precision.append(hit / k if k else 0.0)
    return dict(grid=np.asarray(grid), recall=np.asarray(recall),
                conditional_recall=np.asarray(conditional),
                precision=np.asarray(precision), hits=np.asarray(hits),
                selected=np.asarray(selected),
                candidate_coverage=candidate_coverage(cand, _pairs(ground_truth_pairs)))


def ranking_metrics(scores, cand, ground_truth_pairs):
    """Return AP, reciprocal rank, and NDCG over all candidates."""
    scores = np.asarray(scores, dtype=float)
    cand = _pairs(cand)
    gt = set(map(tuple, _pairs(ground_truth_pairs).tolist()))
    order = np.argsort(-scores, kind="stable")
    rel = np.asarray([tuple(cand[i]) in gt for i in order], dtype=float)
    positives = int(rel.sum())
    if not positives:
        return dict(ap=float("nan"), mrr=0.0, ndcg=float("nan"))
    ranks = np.arange(1, len(rel) + 1)
    ap = float(np.sum(np.cumsum(rel) / ranks * rel) / positives)
    first = int(np.flatnonzero(rel)[0]) + 1
    dcg = float(np.sum(rel / np.log2(ranks + 1)))
    ideal = float(np.sum(np.ones(positives) / np.log2(np.arange(2, positives + 2))))
    return dict(ap=ap, mrr=1.0 / first, ndcg=dcg / ideal)


def hop_of(targets, seeds, graph_edges):
    adj = _adj(graph_edges)
    dist = {int(s): 0 for s in np.asarray(seeds, dtype=int)}
    queue = deque(dist)
    while queue:
        u = queue.popleft()
        for v in adj.get(u, []):
            if v not in dist:
                dist[v] = dist[u] + 1
                queue.append(v)
    return np.asarray([dist.get(int(t), np.inf) for t in np.asarray(targets, dtype=int)])


def hop_stratified_recall(selected_pairs, ground_truth_pairs, seeds, graph_edges):
    gt = _pairs(ground_truth_pairs)
    if not len(gt):
        return {0: float("nan"), 1: float("nan"), 2: float("nan"), "3+": float("nan")}
    selected = set(map(tuple, _pairs(selected_pairs).tolist()))
    hops = hop_of(gt[:, 1], seeds, graph_edges)
    masks = {0: hops == 0, 1: hops == 1, 2: hops == 2, "3+": hops >= 3}
    return {name: (sum(tuple(p) in selected for p in gt[mask].tolist()) / mask.sum()
                   if mask.any() else float("nan")) for name, mask in masks.items()}


def connector_diagnostics(seeds, hidden_nodes, node_tmin, node_tmax,
                          visible_edges, max_gap, direction="out"):
    """Measure actual candidate-generator coverage of undetected attack nodes."""
    hidden = np.setdiff1d(np.asarray(hidden_nodes, dtype=int), np.asarray(seeds, dtype=int))
    if not len(hidden):
        return dict(n_hidden=0, n_hidden_conn=0, coverable_frac=float("nan"))
    cand = enumerate_candidates(seeds, node_tmin, node_tmax, visible_edges,
                                max_gap, direction=direction)
    incident = (set(cand[:, 1].tolist()) if direction == "out"
                else set(cand.reshape(-1).tolist()))
    covered = sum(int(v) in incident for v in hidden)
    return dict(n_hidden=len(hidden), n_hidden_conn=covered,
                coverable_frac=covered / len(hidden))
