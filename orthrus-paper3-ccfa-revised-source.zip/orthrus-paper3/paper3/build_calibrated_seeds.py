"""Build label-free, causal repair seeds from edge-loss windows."""
import argparse
import glob
import os
import sys

import pandas as pd

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from calibrated_seeds import aggregate_seed_evidence, causal_seed_pvalues, node_scores


def _load(path):
    df = pd.read_csv(path, usecols=["srcnode", "dstnode", "loss", "time"])
    scores = node_scores(df.srcnode, df.dstnode, df.loss)
    start = float(df.time.min()) if len(df) else float("inf")
    return start, os.path.basename(path), scores


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--edge-losses-dir", required=True)
    ap.add_argument("--split", default="test")
    ap.add_argument("--epoch", required=True)
    ap.add_argument("--history-length", type=int, default=40)
    ap.add_argument("--alpha", type=float, default=0.05)
    ap.add_argument("--out", required=True)
    args = ap.parse_args()

    paths = glob.glob(os.path.join(args.edge_losses_dir, args.split, args.epoch, "*.csv"))
    if not paths:
        raise SystemExit("no edge-loss windows found")
    loaded = sorted((_load(path) for path in paths), key=lambda x: (x[0], x[1]))
    stream = [(name, scores) for _, name, scores in loaded]
    evidence = aggregate_seed_evidence(
        causal_seed_pvalues(stream, args.history_length), args.alpha)
    rows = [dict(node=node, **values) for node, values in sorted(evidence.items())]
    os.makedirs(os.path.dirname(os.path.abspath(args.out)), exist_ok=True)
    pd.DataFrame(rows).to_csv(args.out, index=False)
    print(f"[calibrated-seeds] windows={len(stream)} nodes={len(rows)} -> {args.out}")


if __name__ == "__main__":
    main()
