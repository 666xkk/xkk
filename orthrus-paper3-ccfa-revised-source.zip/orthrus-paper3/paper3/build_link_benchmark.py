"""Create a deterministic, leak-tight controlled missing-link benchmark."""
import argparse
import glob
import hashlib
import json
import os

import numpy as np
import pandas as pd


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--edge-losses-dir", required=True)
    ap.add_argument("--split", default="test")
    ap.add_argument("--epoch", required=True)
    ap.add_argument("--seed-pvalues", required=True,
                    help="Paper-2 causal seed CSV; labels are never used")
    ap.add_argument("--seed-alpha", type=float, default=0.05)
    ap.add_argument("--n-links", type=int, default=100)
    ap.add_argument("--min-node-degree", type=int, default=2)
    ap.add_argument("--random-seed", type=int, default=2026)
    ap.add_argument("--out", required=True)
    args = ap.parse_args()

    paths = sorted(glob.glob(os.path.join(
        args.edge_losses_dir, args.split, args.epoch, "*.csv")))
    if not paths:
        raise SystemExit("no edge-loss windows found")
    frames = []
    for path in paths:
        frame = pd.read_csv(path, usecols=["srcnode", "dstnode", "time"])
        frames.append(frame.rename(columns={"srcnode": "src", "dstnode": "dst"}))
    events = pd.concat(frames, ignore_index=True)
    events = events[events.src != events.dst]

    seeds_frame = pd.read_csv(args.seed_pvalues)
    seeds = set(seeds_frame.loc[seeds_frame.pvalue <= args.seed_alpha, "node"].astype(int))
    if not seeds:
        raise SystemExit("calibrated seed set is empty")
    degree = pd.concat([events.src, events.dst]).value_counts().to_dict()
    grouped = events.groupby(["src", "dst"]).time.agg(["count", "min", "max"]).reset_index()
    eligible = grouped[
        (grouped.src.isin(seeds) | grouped.dst.isin(seeds))
        & grouped.src.map(degree).ge(args.min_node_degree)
        & grouped.dst.map(degree).ge(args.min_node_degree)
    ].copy()
    if len(eligible) < args.n_links:
        raise SystemExit(f"only {len(eligible)} eligible links for requested {args.n_links}")

    # Stratify on first-event time so the mask is not concentrated in one period.
    eligible["time_bin"] = pd.qcut(eligible["min"], q=min(4, len(eligible)),
                                    labels=False, duplicates="drop")
    rng = np.random.default_rng(args.random_seed)
    selected = []
    bins = sorted(eligible.time_bin.unique())
    quotas = {b: args.n_links // len(bins) for b in bins}
    for b in bins[:args.n_links % len(bins)]:
        quotas[b] += 1
    for time_bin, group in eligible.groupby("time_bin"):
        indices = rng.choice(group.index.to_numpy(), size=quotas[time_bin], replace=False)
        selected.append(eligible.loc[indices])
    result = pd.concat(selected).sort_values(["src", "dst"])
    result = result.rename(columns={"count": "event_count", "min": "first_time",
                                    "max": "last_time"})
    os.makedirs(os.path.dirname(os.path.abspath(args.out)), exist_ok=True)
    result[["src", "dst", "event_count", "first_time", "last_time", "time_bin"]].to_csv(
        args.out, index=False)
    pairs = {(int(u), int(v)) for u, v in zip(result.src, result.dst)}
    payload = "".join(f"{u},{v}\n" for u, v in sorted(pairs))
    manifest = dict(protocol="calibrated-seed-stratified-mask-v1",
                    random_seed=args.random_seed, n_links=len(result),
                    seed_alpha=args.seed_alpha,
                    masked_links_sha256=hashlib.sha256(payload.encode()).hexdigest(),
                    source_files=[os.path.basename(path) for path in paths])
    with open(args.out + ".json", "w") as handle:
        json.dump(manifest, handle, indent=2)
    print(json.dumps(manifest, indent=2))


if __name__ == "__main__":
    main()
