# Frozen evaluation protocol

## Primary hypothesis

At matched edge-review budget B, Paper-3 calibrated fusion improves held-out
link recall over the Paper-1 link prior and every non-learning baseline without
reducing seed precision or candidate coverage.

## Frozen choices

- Epoch: validation-loss argmin.
- Seed alpha, history length, maximum gap, fusion weights, mask fraction, and
  budget grid: chosen on validation timelines, recorded before test access.
- Unit of replication: model seed x collector x evaluation day.
- Labels: used only for final metrics and the explicit oracle upper bound.

## Required comparisons

1. Candidate generator alone (coverage upper bound).
2. Adamic--Adar, allowlist, lexical cosine, BFS, TBFS.
3. Paper-1 link score.
4. Paper-1 score + uncalibrated top-k seeds.
5. Paper-1 score + Paper-2 calibrated seeds.
6. Full Paper-3 fusion.
7. Oracle seeds (clearly labeled upper bound).

## Statistical report

Publish every run, not only the best epoch or seed. Use a hierarchical/block
bootstrap over days and seeds. Report paired effect sizes and confidence
intervals for Recall@B, AP, and NDCG. Correct the family of primary budget
comparisons or nominate one primary B before evaluation.

## Stop conditions

- Candidate coverage below 20%: the link-repair claim is unsupported; report
  the negative result and investigate candidate generation.
- Paper-1 link score does not beat structural baselines: the learned prior is
  not useful for repair even if its training accuracy is high.
- Calibrated seeds do not improve over matched top-k seeds: Paper 2 and Paper 3
  are not empirically connected.
- Fusion gains disappear under causal masking: earlier gains were leakage.
