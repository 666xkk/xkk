"""Paper-3 runner: calibrated, causal, budgeted missing-link repair."""
import argparse
import glob
import hashlib
import json
import os
import re
import sys

import numpy as np
import pandas as pd

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from link_repair import (
    budget_frontier, connector_diagnostics, enumerate_candidates,
    hop_stratified_recall, ranking_metrics, score_allowlist, score_bfs,
    score_calibrated_fusion, score_learned, score_linear, score_structural,
)

NEG_INF = float("-inf")
_TOK = re.compile(r"[^a-zA-Z0-9_./-]+")


def _day_of(path):
    name = os.path.basename(path)
    date = re.search(r"(?:19|20)\d{2}[-_](?:0[1-9]|1[0-2])[-_]"
                     r"(0[1-9]|[12][0-9]|3[01])", name)
    if date:
        return date.group(1)
    # Otherwise use the last standalone calendar-like token.
    matches = re.findall(r"(?:^|[^0-9])(0[1-9]|[12][0-9]|3[01])(?=[^0-9]|$)", name)
    return matches[-1] if matches else ""


def load_windows(edge_dir, split, epoch, days=None):
    wanted = set(days) if days else None
    paths = sorted(glob.glob(os.path.join(edge_dir, split, epoch, "*.csv")))
    paths = [p for p in paths if wanted is None or _day_of(p) in wanted]
    if not paths:
        raise SystemExit(f"no CSV under {edge_dir}/{split}/{epoch} for days={days}")
    return paths


def read_edges(files, hidden_pairs=None):
    node_score, tmin, tmax, node_msg = {}, {}, {}, {}
    edges, edge_time = set(), {}
    hidden_pairs = hidden_pairs or set()
    for path in files:
        df = pd.read_csv(path, usecols=["loss", "srcnode", "dstnode",
                                        "srcmsg", "dstmsg", "time"])
        for row in df.itertuples(index=False):
            u, v, t, loss = int(row.srcnode), int(row.dstnode), float(row.time), float(row.loss)
            if (u, v) in hidden_pairs:
                continue
            for node in (u, v):
                node_score[node] = max(node_score.get(node, NEG_INF), loss)
                tmin[node] = min(tmin.get(node, t), t)
                tmax[node] = max(tmax.get(node, t), t)
            node_msg[u], node_msg[v] = str(row.srcmsg), str(row.dstmsg)
            edges.add((u, v))
            edge_time[(u, v)] = min(edge_time.get((u, v), t), t)
    return node_score, tmin, tmax, node_msg, edges, edge_time


def _msg_fields(message):
    fields = [x for x in _TOK.split(str(message or "")) if x]
    return (fields[0] if fields else ""), fields[1:]


def _stable_bucket(token, dim):
    digest = hashlib.blake2b(token.encode("utf-8"), digest_size=8).digest()
    return int.from_bytes(digest, "little") % dim


def msg_features(node_msg, node_ids, dim=256):
    features = np.zeros((len(node_ids), dim), dtype=np.float32)
    for i, node in enumerate(node_ids):
        _, tokens = _msg_fields(node_msg.get(node, ""))
        for token in tokens:
            features[i, _stable_bucket(token, dim)] += 1.0
    return features


def build_allowlist_novelty(train_msg, eval_msg, node_ids):
    seen = {token for message in train_msg.values() for token in _msg_fields(message)[1]}
    return np.asarray([sum(token not in seen for token in _msg_fields(eval_msg.get(node, ""))[1])
                       for node in node_ids], dtype=float)


def load_seed_pvalues(path, ids):
    df = pd.read_csv(path)
    required = {"node", "pvalue"}
    if not required.issubset(df.columns):
        raise SystemExit(f"seed file must contain {sorted(required)}")
    lookup = {int(row.node): float(row.pvalue) for row in df.itertuples(index=False)}
    return np.asarray([lookup.get(node, 1.0) for node in ids], dtype=float)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--edge-losses-dir", required=True)
    ap.add_argument("--eval-dir", default="", help="labels; required only for diagnostics/oracle")
    ap.add_argument("--epoch", default="auto")
    ap.add_argument("--eval-days", required=True)
    ap.add_argument("--max-gap", type=float, default=15.0 * 60)
    ap.add_argument("--direction", choices=["out", "in", "both"], default="both")
    ap.add_argument("--seed-mode", choices=["calibrated", "topk", "oracle"], default="calibrated")
    ap.add_argument("--seed-pvalues", default="")
    ap.add_argument("--seed-alpha", type=float, default=0.05)
    ap.add_argument("--seed-topk", type=int, default=50)
    ap.add_argument("--allow-oracle", action="store_true")
    ap.add_argument("--B-grid", default="5,10,20,50,100,200,500")
    ap.add_argument("--gt-links", default="")
    ap.add_argument("--hidden-links", default="",
                    help="controlled benchmark links removed before all scoring")
    ap.add_argument("--embeddings", default="")
    ap.add_argument("--baseline-only", action="store_true")
    ap.add_argument("--seed-weight", type=float, default=1.0)
    ap.add_argument("--structural-weight", type=float, default=0.0)
    ap.add_argument("--out", default="paper3/results")
    args = ap.parse_args()
    os.makedirs(args.out, exist_ok=True)

    if args.epoch == "auto":
        args.epoch = select_epoch_by_val_loss(args.edge_losses_dir)
    days = [x.strip() for x in args.eval_days.split(",") if x.strip()]
    files = load_windows(args.edge_losses_dir, "test", args.epoch, days)
    hidden_raw = load_pair_csv(args.hidden_links) if args.hidden_links else set()
    node_score, tmin, tmax, node_msg, edges, edge_time = read_edges(files, hidden_raw)
    ids = sorted(node_score)
    idx = {node: i for i, node in enumerate(ids)}
    labels = load_attack_nodes(args.eval_dir, args.epoch) if args.eval_dir else {}

    seed_p = np.ones(len(ids), dtype=float)
    if args.seed_mode == "calibrated":
        if not args.seed_pvalues:
            raise SystemExit("--seed-mode calibrated requires --seed-pvalues")
        seed_p = load_seed_pvalues(args.seed_pvalues, ids)
        seeds = [ids[i] for i in np.flatnonzero(seed_p <= args.seed_alpha)]
    elif args.seed_mode == "topk":
        seeds = [node for node, _ in sorted(node_score.items(), key=lambda x: (-x[1], x[0]))
                 [:args.seed_topk]]
        # Rank-derived evidence is an explicit baseline, not calibrated evidence.
        for rank, node in enumerate(seeds, start=1):
            seed_p[idx[node]] = rank / (len(seeds) + 1.0)
    else:
        if not args.allow_oracle:
            raise SystemExit("oracle seeds are an upper bound; pass --allow-oracle explicitly")
        if not labels:
            raise SystemExit("oracle mode requires --eval-dir labels")
        seeds = [node for node in ids if labels.get(node, 0) == 1]
        seed_p[[idx[n] for n in seeds]] = 1.0 / (len(ids) + 1.0)
    if not seeds:
        raise SystemExit("seed selection produced no nodes")

    tmin_a = np.asarray([tmin[n] for n in ids], dtype=float)
    tmax_a = np.asarray([tmax[n] for n in ids], dtype=float)
    seeds_i = np.asarray([idx[n] for n in seeds], dtype=int)
    attack_i = np.asarray([idx[n] for n in ids if labels.get(n, 0) == 1], dtype=int)
    visible = np.asarray([[idx[u], idx[v]] for u, v in sorted(edges)], dtype=int).reshape(-1, 2)
    time_i = {(idx[u], idx[v]): t for (u, v), t in edge_time.items()}

    diag = connector_diagnostics(seeds_i, attack_i, tmin_a, tmax_a, visible,
                                 args.max_gap, direction=args.direction)
    candidates = enumerate_candidates(seeds_i, tmin_a, tmax_a, visible,
                                      args.max_gap, direction=args.direction)
    if not len(candidates):
        raise SystemExit("candidate generator produced no missing links")

    scores = {
        "adamic_adar": score_structural(visible, candidates),
        "bfs": score_bfs(visible, seeds_i, candidates, len(ids)),
        "tbfs": score_bfs(visible, seeds_i, candidates, len(ids), temporal=True,
                          edge_time=time_i),
    }
    train_msg = load_train_msg(args.edge_losses_dir, args.epoch)
    scores["allowlist"] = score_allowlist(
        build_allowlist_novelty(train_msg, node_msg, ids), candidates)
    scores["linear"] = score_linear(msg_features(node_msg, ids), candidates)

    if not args.baseline_only:
        if not args.embeddings:
            raise SystemExit("Paper-3 learned method requires --embeddings; use --baseline-only otherwise")
        query, emb, metadata = embeddings_to_arrays(args.embeddings, ids)
        if not metadata.get("causal", False):
            raise SystemExit("embedding dump is not marked causal; regenerate with export_node_embeddings.py")
        if hidden_raw and metadata.get("masked_links_sha256") != pair_hash(hidden_raw):
            raise SystemExit("embedding dump was not generated with the same hidden-link mask")
        scores["paper1_link"] = score_learned(query, emb, candidates,
                                               metadata.get("temperature", 0.1))
        scores["paper3_fusion"] = score_calibrated_fusion(
            scores["paper1_link"], candidates, seed_p,
            scores["adamic_adar"], args.seed_weight, args.structural_weight)

    gt_pairs = np.zeros((0, 2), dtype=int)
    if args.gt_links:
        gt = pd.read_csv(args.gt_links)
        gt_pairs = np.asarray([[idx[int(u)], idx[int(v)]]
                               for u, v in zip(gt.src, gt.dst)
                               if int(u) in idx and int(v) in idx], dtype=int).reshape(-1, 2)
        overlap = set(map(tuple, visible.tolist())) & set(map(tuple, gt_pairs.tolist()))
        if overlap:
            raise SystemExit("ground-truth missing links are visible; this would leak the target")

    rows, ranks = [], []
    budgets = [int(x) for x in args.B_grid.split(",") if x.strip()]
    if len(gt_pairs):
        for method, values in scores.items():
            frontier = budget_frontier(values, candidates, gt_pairs, budgets)
            metrics = ranking_metrics(values, candidates, gt_pairs)
            ranks.append(dict(method=method, **metrics,
                              **frontier["candidate_coverage"]))
            for i, budget in enumerate(frontier["grid"]):
                rows.append(dict(method=method, budget=int(budget),
                                 selected=int(frontier["selected"][i]),
                                 hits=int(frontier["hits"][i]),
                                 recall=float(frontier["recall"][i]),
                                 conditional_recall=float(frontier["conditional_recall"][i]),
                                 precision=float(frontier["precision"][i])))
        pd.DataFrame(rows).to_csv(os.path.join(args.out, f"frontier_{args.epoch}.csv"), index=False)
        pd.DataFrame(ranks).to_csv(os.path.join(args.out, f"ranking_{args.epoch}.csv"), index=False)
        representative = "paper3_fusion" if "paper3_fusion" in scores else "adamic_adar"
        order = np.argsort(-scores[representative], kind="stable")
        selected = candidates[order[:min(max(budgets), len(candidates))]]
        hops = hop_stratified_recall(selected, gt_pairs, seeds_i, visible)
    else:
        hops = {}

    out = pd.DataFrame({"src": [ids[u] for u, _ in candidates],
                        "dst": [ids[v] for _, v in candidates]})
    for method, values in scores.items():
        out[method] = values
    out.to_csv(os.path.join(args.out, f"candidates_{args.epoch}.csv"), index=False)
    report = dict(epoch=args.epoch, seed_mode=args.seed_mode, n_nodes=len(ids),
                  n_seeds=len(seeds), n_candidates=len(candidates),
                  connector=diag, hop_recall=hops,
                  learned_method="paper3_fusion" in scores)
    with open(os.path.join(args.out, f"protocol_{args.epoch}.json"), "w") as handle:
        json.dump(report, handle, indent=2, allow_nan=True)
    print(json.dumps(report, indent=2, allow_nan=True))


def select_epoch_by_val_loss(edge_dir):
    candidates = sorted(os.path.basename(path) for path in
                        glob.glob(os.path.join(edge_dir, "test", "model_epoch_*"))
                        if os.path.isdir(path))
    best = None
    for epoch in candidates:
        total = count = 0
        for path in glob.glob(os.path.join(edge_dir, "val", epoch, "*.csv")):
            losses = pd.read_csv(path, usecols=["loss"]).loss
            total += float(losses.sum())
            count += len(losses)
        if count and (best is None or total / count < best[0]):
            best = (total / count, epoch)
    if best is None:
        raise SystemExit("validation loss is unavailable for epoch selection")
    return best[1]


def load_attack_nodes(eval_dir, epoch):
    import torch
    path = os.path.join(eval_dir, f"result_{epoch}.pth")
    if not os.path.exists(path):
        return {}
    raw = torch.load(path, map_location="cpu")
    return {int(node): int(value.get("y_true", 0)) for node, value in raw.items()}


def load_pair_csv(path):
    frame = pd.read_csv(path)
    if not {"src", "dst"}.issubset(frame.columns):
        raise SystemExit(f"pair file {path} must contain src,dst")
    return {(int(u), int(v)) for u, v in zip(frame.src, frame.dst)}


def pair_hash(pairs):
    payload = "".join(f"{u},{v}\n" for u, v in sorted(set(pairs)))
    return hashlib.sha256(payload.encode("utf-8")).hexdigest()


def load_train_msg(edge_dir, epoch):
    messages = {}
    for path in glob.glob(os.path.join(edge_dir, "train", epoch, "*.csv")):
        df = pd.read_csv(path, usecols=["srcnode", "dstnode", "srcmsg", "dstmsg"])
        for row in df.itertuples(index=False):
            messages[int(row.srcnode)] = str(row.srcmsg)
            messages[int(row.dstnode)] = str(row.dstmsg)
    return messages


def embeddings_to_arrays(path, ids):
    if path.endswith(".npz"):
        raw = np.load(path, allow_pickle=False)
        nodes, emb, query = raw["nodes"], raw["emb"], raw["query"]
        metadata = {"causal": bool(raw["causal"]),
                    "temperature": float(raw["temperature"]),
                    "masked_links_sha256": str(raw["masked_links_sha256"])
                    if "masked_links_sha256" in raw else ""}
        lookup = {int(node): i for i, node in enumerate(nodes)}
        missing = [node for node in ids if node not in lookup]
        if missing:
            raise SystemExit(f"embedding dump misses {len(missing)} evaluated nodes")
        order = [lookup[node] for node in ids]
        return query[order], emb[order], metadata
    import torch
    raw = torch.load(path, map_location="cpu")
    emb, query = raw["emb"], raw["q"]
    missing = [node for node in ids if node not in emb or node not in query]
    if missing:
        raise SystemExit(f"embedding dump misses {len(missing)} evaluated nodes")
    return (np.stack([query[n].numpy() for n in ids]),
            np.stack([emb[n].numpy() for n in ids]), raw.get("metadata", {}))


if __name__ == "__main__":
    main()
