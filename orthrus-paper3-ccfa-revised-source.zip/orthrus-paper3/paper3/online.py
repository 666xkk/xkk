"""ONLINE-PIDS: online FDR control + adaptive conformal for PIDS alerting."""
import numpy as np


# ---------------------------------------------------------------- p-values
def pvalues(cal_sorted, scores):
    n = len(cal_sorted)
    k = np.searchsorted(cal_sorted, scores, side="left")
    return (1.0 + (n - k)) / (n + 1.0)


# ---------------------------------------------------------------- LORD++
class LORDPlusPlus:
    """Javanmard & Montanari (ICML 2018) 的 LORD++.
    每次拒绝后，把后续时刻的 alpha 预算提高。保证 mFDR <= alpha。"""

    def __init__(self, alpha, gamma_a=0.0722):
        self.alpha = float(alpha)
        self.w0 = float(alpha)
        self.gamma_a = float(gamma_a)
        self.tau = []          # 历史拒绝时刻（1-indexed）

    def _gamma(self, j):
        if j < 1:
            return 0.0
        return self.gamma_a * np.log(max(j, 2)) / j

    def alpha_at(self, t):
        a = self.w0 * self._gamma(t)
        for tau in self.tau:
            a += self.w0 * self._gamma(t - tau)
        return min(a, self.alpha)

    def step(self, t, p):
        a = self.alpha_at(t)
        rej = bool(p <= a)
        if rej:
            self.tau.append(t)
        return rej, a


# ---------------------------------------------------------------- SAFFRON
class SAFFRON:
    """Ramdas et al. (JMLR 2018) 的 SAFFRON（更紧的在线 FDR）。"""

    def __init__(self, alpha, lambda_=0.5, gamma_a=0.0722):
        self.alpha = float(alpha)
        self.lam = float(lambda_)
        self.gamma_a = float(gamma_a)
        self.w0 = float(alpha) * (1.0 - self.lam)
        self.tau = []

    def _gamma(self, j):
        if j < 1:
            return 0.0
        return self.gamma_a * np.log(max(j, 2)) / j

    def alpha_at(self, t):
        a = self.w0 * self._gamma(t)
        for tau in self.tau:
            a += self.w0 * self._gamma(max(t - tau, 1))
        return min(a, self.alpha)

    def step(self, t, p):
        a = self.alpha_at(t)
        if p <= a:
            self.tau.append(t)
            return True, a
        if p > self.lam:
            # 候选池亏损：不影响 tau
            return False, a
        return False, a


# ---------------------------------------------------------------- adaptive conformal
class AdaptiveConformal:
    """Gibbs & Candes (2021). 维护分位数 q，使长期误报率趋近 alpha。"""

    def __init__(self, alpha, q0, gamma=0.005, lo=0.0, hi=1e6):
        self.alpha = float(alpha)
        self.q = float(q0)
        self.g = float(gamma)
        self.lo, self.hi = lo, hi
        self.hist = []

    def step(self, x):
        """x 为该时刻分数；返回 (是否告警, 当前 q)"""
        flag = bool(x > self.q)
        # 告警视为"覆盖失败"：若告警则 err=1，需抬高 q
        err = 1.0 if flag else 0.0
        self.q = float(np.clip(self.q + self.g * (err - self.alpha), self.lo, self.hi))
        self.hist.append(self.q)
        return flag, self.q


# ---------------------------------------------------------------- 离线基准
def bh_reject(p, alpha):
    """离线 Benjamini-Hochberg，作为 oracle 上界（用到了未来信息）。"""
    p = np.asarray(p, float)
    n = len(p)
    if n == 0:
        return np.zeros(0, bool)
    order = np.argsort(p)
    thr = alpha * np.arange(1, n + 1) / n
    passed = p[order] <= thr
    k = np.max(np.where(passed)[0]) + 1 if passed.any() else 0
    rej = np.zeros(n, bool)
    if k:
        rej[order[:k]] = True
    return rej
