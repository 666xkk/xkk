"""Causal Paper-2 calibration used to construct Paper-3 repair seeds."""
from __future__ import annotations

from collections import deque

import numpy as np


def node_scores(src, dst, edge_scores):
    """Worst incident-edge score per node inside one window only."""
    out = {}
    for u, v, score in zip(src, dst, edge_scores):
        score = float(score)
        out[int(u)] = max(out.get(int(u), float("-inf")), score)
        out[int(v)] = max(out.get(int(v), float("-inf")), score)
    return out


def causal_seed_pvalues(windows, history_length=40):
    """Yield causal node p-values for a chronological window stream.

    Each input item is ``(window_id, {node: score})``.  A block maximum is
    appended only after the current decision, so modifying a future window
    cannot alter any prior output.  Warm-up windows return an empty mapping.
    """
    if history_length < 1:
        raise ValueError("history_length must be positive")
    history = deque(maxlen=history_length)
    output = []
    for window_id, scores in windows:
        scores = {int(k): float(v) for k, v in scores.items()}
        if len(history) == history_length:
            cal = np.sort(np.asarray(history, dtype=float))
            pvals = {node: (1.0 + len(cal) - np.searchsorted(cal, score, side="left"))
                     / (len(cal) + 1.0) for node, score in scores.items()}
        else:
            pvals = {}
        output.append((window_id, pvals))
        if scores:
            history.append(max(scores.values()))
    return output


def aggregate_seed_evidence(window_pvalues, alpha=0.05):
    """Aggregate window decisions without labels; return min-p and counts."""
    if not 0 < alpha < 1:
        raise ValueError("alpha must lie in (0,1)")
    evidence = {}
    for window_id, pvalues in window_pvalues:
        for node, pvalue in pvalues.items():
            row = evidence.setdefault(int(node), {
                "pvalue": 1.0, "n_flagged_windows": 0,
                "n_scored_windows": 0, "first_flag_window": ""})
            row["pvalue"] = min(row["pvalue"], float(pvalue))
            row["n_scored_windows"] += 1
            if pvalue <= alpha:
                row["n_flagged_windows"] += 1
                if not row["first_flag_window"]:
                    row["first_flag_window"] = str(window_id)
    return evidence
