# Paper 3: Calibrated Causal Link Repair under Investigation Budgets

## Three-paper research chain

1. **Paper 1 -- representation:** leak-tight masked event modeling trains
   `MaskedLinkHead`. Its directed compatibility logit estimates whether the
   current causal context supports a missing `src -> dst` relation.
2. **Paper 2 -- decision:** a causal rolling block calibrator converts node
   anomaly scores into label-free p-values. Paper 3 uses these p-values to
   construct the seed set; attack labels are evaluation-only.
3. **Paper 3 -- investigation:** given calibrated seeds and a fixed analyst
   budget, recover missing causal links and measure both candidate coverage and
   ranking quality.

The Paper-3 fusion score is

```text
robust_z(link_logit(u,v))
  + lambda_seed * -log(min(p_seed(u), p_seed(v)))
  + lambda_struct * robust_z(AdamicAdar(u,v)).
```

All weights are selected on validation data and frozen before test evaluation.
The learned logit is a compatibility score, not a calibrated probability.

## Leakage controls

- `build_calibrated_seeds.py` appends a window maximum only after scoring the
  current window. Future windows cannot change an earlier seed decision.
- `export_node_embeddings.py` exports the latest endpoint state at an explicit
  prefix cutoff instead of averaging the complete test split.
- A controlled missing-link benchmark passes the same mask to the runner and
  embedding exporter. The runner verifies the SHA-256 mask fingerprint.
- `oracle` seeds require `--allow-oracle` and are reported only as an upper
  bound.
- Ground-truth missing links that remain visible cause a fatal error.

## Evaluation contract

Every method receives the same candidate set and budget grid. Report:

- candidate coverage over all held-out links;
- unconditional Recall@B and conditional Recall@B among eligible links;
- Precision@B using the number actually selected as the denominator;
- AP, MRR, NDCG, and hop-stratified recall;
- per-seed and per-day results with block-bootstrap confidence intervals;
- measured runtime, peak memory, and candidates per seed.

Required baselines are Adamic--Adar, allowlist novelty, deterministic lexical
cosine, BFS, TBFS, Paper-1 link prior alone, and Paper-3 calibrated fusion.

## Reproduction order

```bash
# 1. Select the model epoch by validation loss only.

# 2. Produce causal Paper-2 seed evidence.
python paper3/build_calibrated_seeds.py \
  --edge-losses-dir <edge_losses> --epoch model_epoch_XX \
  --history-length 40 --alpha 0.05 \
  --out paper3/results/seeds.csv

# 3. Build a deterministic controlled mask from calibrated seeds.
python paper3/build_link_benchmark.py \
  --edge-losses-dir <edge_losses> --epoch model_epoch_XX \
  --seed-pvalues paper3/results/seeds.csv --n-links 100 \
  --out paper3/results/hidden_links.csv

# 4. Export a causal Paper-1 snapshot with the same links hidden.
python paper3/export_node_embeddings.py THEIA_E3 \
  --epoch model_epoch_XX --split test --through-window <cutoff> \
  --mask-links paper3/results/hidden_links.csv \
  --out paper3/results/causal_embeddings.npz

# 5. Evaluate all matched-budget methods.
python paper3/run_link_repair.py \
  --edge-losses-dir <edge_losses> --eval-days <days> \
  --epoch model_epoch_XX --seed-mode calibrated \
  --seed-pvalues paper3/results/seeds.csv \
  --gt-links paper3/results/hidden_links.csv \
  --hidden-links paper3/results/hidden_links.csv \
  --embeddings paper3/results/causal_embeddings.npz \
  --B-grid 5,10,20,50,100,200,500
```

## Claims that require experiments

Code correctness does not establish CCF-A-level evidence. Before submission,
the repository must contain preregistered dataset splits, at least three model
seeds, at least three collectors, a second detector family, confidence
intervals, and complete negative/failed results. Do not claim false discovery
control for repaired links unless the null calibration assumptions and
dependence conditions are stated and tested.
