"""Export a causal Paper-1 link-prior snapshot for Paper 3.

The encoder computes endpoint representations before inserting the current
batch into temporal memory. We retain each node's latest representation up to
an explicit prefix cutoff. Unlike the old whole-test average, later windows can
never revise an earlier exported snapshot.
"""
import argparse
import hashlib
import os
import sys

import numpy as np
import torch

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from src.config import get_runtime_required_args, get_yml_cfg
from src.data_utils import load_all_datasets, load_model
from src.factory import batch_loader_factory, build_model


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("dataset")
    parser.add_argument("--epoch", default="model_epoch_1")
    parser.add_argument("--split", default="test", choices=["train", "val", "test"])
    parser.add_argument("--through-window", type=int, default=-1,
                        help="inclusive zero-based prefix cutoff; -1 uses the split end")
    parser.add_argument("--mask-links", default="",
                        help="CSV src,dst links omitted from temporal memory")
    parser.add_argument("--out", default="paper3/results/embeddings.npz")
    known, unknown = parser.parse_known_args()

    runtime_args, _ = get_runtime_required_args(
        return_unknown_args=True, args=[known.dataset] + unknown)
    cfg = get_yml_cfg(runtime_args)
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    train, val, test, full_data, max_nodes = load_all_datasets(cfg)
    split_data = {"train": train, "val": val, "test": test}[known.split]
    cutoff = len(split_data) - 1 if known.through_window < 0 else known.through_window
    if cutoff < 0 or cutoff >= len(split_data):
        raise SystemExit(f"through-window must be in [0,{len(split_data)-1}]")
    masked = set()
    masked_hash = ""
    if known.mask_links:
        import pandas as pd
        frame = pd.read_csv(known.mask_links)
        if not {"src", "dst"}.issubset(frame.columns):
            raise SystemExit("mask-links CSV must contain src,dst")
        masked = {(int(u), int(v)) for u, v in zip(frame.src, frame.dst)}
        payload = "".join(f"{u},{v}\n" for u, v in sorted(masked))
        masked_hash = hashlib.sha256(payload.encode("utf-8")).hexdigest()

    model = build_model(split_data[0], device, cfg, max_nodes)
    model = load_model(model, os.path.join(
        cfg.detection.gnn_training._trained_models_dir, known.epoch)).to(device)
    model.eval()
    if not getattr(model, "link_head", None):
        raise RuntimeError("checkpoint has no trained MaskedLinkHead")

    latest = {}
    with torch.no_grad():
        model.encoder.reset_state()
        for window_index, graph in enumerate(split_data[:cutoff + 1]):
            graph.to(device=device)
            loader = batch_loader_factory(cfg, graph, model.graph_reindexer)
            for batch in loader:
                raw_edges = (batch.original_edge_index if hasattr(batch, "original_edge_index")
                             else batch.edge_index)
                if masked:
                    keep_list = [(int(u), int(v)) not in masked
                                 for u, v in zip(raw_edges[0].tolist(), raw_edges[1].tolist())]
                    keep = torch.tensor(keep_list, dtype=torch.bool, device=batch.edge_index.device)
                    if not bool(keep.any()):
                        continue
                    edge_index = batch.edge_index[:, keep]
                    raw_edges = raw_edges[:, keep]
                    batch_t, batch_msg = batch.t[keep], batch.msg[keep]
                    batch_x = (batch.x_src[keep], batch.x_dst[keep])
                else:
                    edge_index, batch_t, batch_msg = batch.edge_index, batch.t, batch.msg
                    batch_x = (batch.x_src, batch.x_dst)
                h_src, h_dst, _ = model.encoder(
                    edge_index=edge_index, t=batch_t, msg=batch_msg,
                    x=batch_x, full_data=full_data,
                    inference=True)
                for node, embedding in zip(raw_edges[0].tolist(), h_src.cpu()):
                    latest[int(node)] = embedding.float().clone()
                for node, embedding in zip(raw_edges[1].tolist(), h_dst.cpu()):
                    latest[int(node)] = embedding.float().clone()
            graph.to("cpu")

    nodes = sorted(latest)
    embeddings = torch.stack([latest[node] for node in nodes])
    with torch.no_grad():
        queries = model.link_head.query(embeddings.to(device)).cpu()
    temperature = float(model.link_head.temperature)
    metadata = dict(format_version=2, causal=True, split=known.split,
                    cutoff_window=cutoff, epoch=known.epoch,
                    temperature=temperature, aggregation="latest-prefix-state")
    if masked_hash:
        metadata["masked_links_sha256"] = masked_hash
    os.makedirs(os.path.dirname(os.path.abspath(known.out)), exist_ok=True)
    if known.out.endswith(".npz"):
        np.savez_compressed(known.out, nodes=np.asarray(nodes, dtype=np.int64),
                            emb=embeddings.numpy(), query=queries.numpy(),
                            causal=np.asarray(True), temperature=np.asarray(temperature),
                            cutoff_window=np.asarray(cutoff),
                            masked_links_sha256=np.asarray(masked_hash))
    else:
        torch.save({"emb": {n: embeddings[i] for i, n in enumerate(nodes)},
                    "q": {n: queries[i] for i, n in enumerate(nodes)},
                    "metadata": metadata}, known.out)
    print(f"[causal-export] nodes={len(nodes)} cutoff={cutoff} -> {known.out}")


if __name__ == "__main__":
    main()
