"""paper3/export_node_features.py — 导出原始节点特征（linear 骨干基线的输入）。

linear 骨干基线需要"无 GNN 的原始特征"：这里直接取 edge embeds 里的
x_src/x_dst（= w2v + type + presence 向量），按节点做 mean 聚合，得到
{node_id: (d,) tensor}。

不需要模型/DB（edge embeds 已在盘上）。与 export_node_embeddings.py 的区别：
它导出的是编码器输出 h（有 GNN），这里导出的是 GNN **输入**特征（无 GNN）。

用法（在 pids 容器、已跑完 embed_edges）：
  python paper3/export_node_features.py THEIA_E3 \
    --split test --out paper3/results/feat_theia_e3.pth

该 dump 可被 run_link_repair.py 的 linear 基线（或装置 exp3c 的 --p1-feat）消费。
"""
import argparse
import glob
import os
import sys

import torch

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from src.config import get_runtime_required_args, get_yml_cfg


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("dataset")
    ap.add_argument("--split", default="test", choices=["train", "val", "test"])
    ap.add_argument("--out", default="paper3/results/node_features.pth")
    known, _ = ap.parse_known_args()

    args, _ = get_runtime_required_args(return_unknown_args=True, args=[known.dataset])
    cfg = get_yml_cfg(args)

    embeds_dir = os.path.join(cfg.edge_featurization.embed_edges._edge_embeds_dir, known.split)
    files = sorted(glob.glob(os.path.join(embeds_dir, "*.TemporalData.simple")))
    if not files:
        raise SystemExit(f"[FATAL] no edge embeds under {embeds_dir}")

    accum, cnt = {}, {}
    for f in files:
        data = torch.load(f, map_location="cpu")
        src = data.src.tolist()
        dst = data.dst.tolist()
        x_src = data.x_src
        x_dst = data.x_dst
        for n, x in zip(src, x_src):
            accum[n] = accum.get(n, 0.0) + x
            cnt[n] = cnt.get(n, 0) + 1
        for n, x in zip(dst, x_dst):
            accum[n] = accum.get(n, 0.0) + x
            cnt[n] = cnt.get(n, 0) + 1

    node_feat = {int(n): (accum[n] / cnt[n]).float() for n in accum}
    os.makedirs(os.path.dirname(os.path.abspath(known.out)), exist_ok=True)
    torch.save(node_feat, known.out)
    print(f"[export_node_features] {len(node_feat)} nodes -> {known.out}")


if __name__ == "__main__":
    main()
