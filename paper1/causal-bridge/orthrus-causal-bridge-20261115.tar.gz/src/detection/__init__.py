"""Detection package.

Submodules are intentionally not imported eagerly.  The historical eager
imports pulled the complete training stack (and its legacy top-level imports)
even when a standalone post-processing module was invoked with ``python -m``.
Python still resolves statements such as ``from detection import evaluation``
as submodule imports, so the training pipeline keeps its existing API.
"""

__all__ = [
    "evaluation",
    "orthrus_gnn_testing",
    "orthrus_gnn_training",
]
