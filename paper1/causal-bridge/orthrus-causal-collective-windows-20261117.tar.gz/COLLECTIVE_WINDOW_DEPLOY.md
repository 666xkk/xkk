# Causal collective weak-evidence windows

This standalone stage consumes frozen ORTHRUS per-window edge-loss CSV files.
It does not retrain or modify a detector checkpoint.

For every window it assigns each configured-role node the maximum incident
edge loss, averages the ten highest node scores, and then averages the current
and preceding three window scores.  The causal score for a historical window
is invariant to appending future files.  Attack intervals are optional and are
read only after scoring and budget selection for evaluation.

## Verify

```bash
python -m py_compile \
  src/detection/causal_collective_windows.py \
  tests/test_causal_collective_windows.py

python -m pytest -q \
  tests/test_causal_collective_windows.py
```

## ClearScope development reproduction

```bash
python -u -m src.detection.causal_collective_windows \
  --metadata-root \
    paper1/results/CLEARSCOPE_E3/VALIDATION_SELECTED_BASELINE/metadata \
  --node-role file \
  --node-top-k 10 \
  --temporal-scale 4 \
  --window-budget 20 \
  --attack-interval \
    '2018-04-11 13:54:00~2018-04-11 14:48:00' \
  --output-dir \
    paper1/results/CLEARSCOPE_E3/VALIDATION_SELECTED_BASELINE/causal_collective_windows
```

Omit `--attack-interval` for label-free operational scoring.  `summary.csv`
contains only post-generation evaluation, while `window_scores_seedN.csv`
records every raw and causal score plus the fixed analyst-budget selection.

The batch Top-20 flag represents a fixed offline analyst-review budget.  The
underlying score itself is strictly causal and can instead be compared against
a validation-frozen threshold in a streaming deployment.
