# Causal Bridge deployment

The causal-bridge stage is an offline, label-free candidate generator over
frozen ORTHRUS scores. It does not retrain or modify a checkpoint. Ground-truth
labels are consulted only after candidate generation for the optional summary
metrics. The density gate rejects relation families whose graph expansion
exceeds a fixed operational budget; this decision also never reads labels.

## Verify

From the repository root:

```bash
python -m py_compile \
  src/detection/causal_bridge.py \
  src/config.py \
  tests/test_causal_bridge.py

python -m pytest -q tests/test_causal_bridge.py

python -m src.detection.causal_bridge --help
```

## CADETS_E3 development reproduction

```bash
python -u -m src.detection.causal_bridge \
  --dataset CADETS_E3 \
  --results-root paper1/results/CADETS_E3/VALIDATION_SELECTED_BASELINE/raw_results \
  --test-loss-dir artifacts/detection/gnn_testing/3189d7b511a8dd11e8c9e1f5c6c59f4a626691df3cd618ecce9c976acbcf7053/CADETS_E3/edge_losses/test/model_epoch_20 \
  --edge-dir artifacts/edge_featurization/CADETS_E3/embed_edges/448b85fc77d872274d02e7d3f88dba1a484361d89ee828c603c7c3aa8f729876/edge_embeds/test \
  --node-map artifacts/graph_construction/CADETS_E3/build_graphs/3eb70eba13d9538396c158583c8370762c55ba1c3a9228ca8f30b5d9f5dbeddc/node_id_to_path/node_to_paths.pkl \
  --anchor-budget 100 \
  --subject-to-netflow \
  --file-to-subject \
  --density-gate \
  --max-relation-expansion-ratio 1.0 \
  --max-hops 1 \
  --output-dir paper1/results/CADETS_E3/VALIDATION_SELECTED_BASELINE/causal_bridge
```

Expected files:

- `summary.csv`: per-seed matched-budget evaluation;
- `episodes_seedN.csv`: label-free evidence edges for each seed;
- `episodes_raw_seedN.csv`: pre-gate evidence with the gate decision attached;
- `relation_gate_seedN.csv`: auditable per-relation expansion decisions;
- `run_config.json`: an exact run manifest.

Use `--skip-evaluation` to generate operational episodes without reading
`y_true`. Do not enable `--subject-to-file` for the main `bridge_core` result;
it is the higher-workload extended ablation. Multi-hop expansion is rejected
by design because the CADETS_E3 audit showed uncontrolled candidate growth.

## Density-gate protocol

For each enabled relation family, compute
`unique_candidates / anchor_budget`. Accept the family when the ratio is at
most `--max-relation-expansion-ratio` (1.0 in the frozen protocol). The rule is
inclusive and is fixed before evaluation. On THEIA_E3, this keeps the compact
`file_to_subject` relation while rejecting the dataset-specific explosion of
`subject_to_netflow`. Omit `--density-gate` only for explicit ablations of the
ungated method.
