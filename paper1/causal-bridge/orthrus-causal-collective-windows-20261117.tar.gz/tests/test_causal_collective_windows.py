import csv
import subprocess
import sys
from pathlib import Path

from src.detection.causal_collective_windows import (
    CollectiveWindowConfig,
    causal_rolling_mean,
    message_has_role,
    node_scores_from_rows,
    parse_attack_interval,
    select_window_indices,
    top_k_mean,
)


def test_module_help_does_not_import_training_stack():
    result = subprocess.run(
        [sys.executable, "-m", "src.detection.causal_collective_windows", "--help"],
        cwd=Path(__file__).resolve().parents[1],
        check=False,
        capture_output=True,
        text=True,
    )
    assert result.returncode == 0, result.stderr
    assert "--temporal-scale" in result.stdout


def test_role_recognition_supports_serialized_dict_styles():
    assert message_has_role("{'file': '/tmp/a'}", "file")
    assert message_has_role('{"file": "/tmp/a"}', "file")
    assert not message_has_role("{'subject': 'bash'}", "file")


def test_current_window_node_scores_use_max_and_both_endpoints():
    rows = [
        {
            "loss": "0.2",
            "srcnode": "1",
            "dstnode": "2",
            "srcmsg": "{'file': 'a'}",
            "dstmsg": "{'subject': 'p'}",
        },
        {
            "loss": "0.7",
            "srcnode": "3",
            "dstnode": "1",
            "srcmsg": "{'subject': 'q'}",
            "dstmsg": "{'file': 'a'}",
        },
    ]
    assert node_scores_from_rows(rows, "file", True) == {1: 0.7}
    assert node_scores_from_rows(rows, "file", False) == {1: 0.2}


def test_top_k_mean_uses_only_requested_tail():
    assert top_k_mean({1: 1.0, 2: 3.0, 3: 5.0}, 2) == 4.0
    assert top_k_mean({}, 10) == 0.0


def test_causal_rolling_mean_matches_fixed_scale_four():
    assert causal_rolling_mean([1, 2, 3, 4, 9], 4) == [1.0, 1.5, 2.0, 2.5, 4.5]


def test_future_append_cannot_change_historical_scores():
    prefix = [1.0, 7.0, 2.0, 4.0]
    before = causal_rolling_mean(prefix, 4)
    after = causal_rolling_mean(prefix + [1000.0, -1000.0], 4)
    assert after[: len(prefix)] == before


def test_review_selection_is_deterministic_on_ties():
    assert select_window_indices([0.1, 0.5, 0.5, 0.2], 2) == [1, 2]


def test_attack_interval_parser_rejects_reverse_time():
    start, end = parse_attack_interval(
        "2018-04-11 13:54:00~2018-04-11 14:48:00"
    )
    assert end > start


def test_config_rejects_nonpositive_parameters():
    try:
        CollectiveWindowConfig(temporal_scale=0).validate()
    except ValueError as error:
        assert "temporal_scale" in str(error)
    else:
        raise AssertionError("zero temporal scale must be rejected")
