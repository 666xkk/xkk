import csv
import json
import subprocess
import sys
from pathlib import Path

from src.detection.causal_bridge import (
    BridgeConfig,
    BridgeWitness,
    apply_relation_density_gate,
    evaluate_candidates,
    expand_one_window,
    generate_candidates,
    parse_interval_name,
    select_anchors,
)


def test_package_module_help_does_not_import_training_stack():
    result = subprocess.run(
        [sys.executable, "-m", "src.detection.causal_bridge", "--help"],
        cwd=Path(__file__).resolve().parents[1],
        check=False,
        capture_output=True,
        text=True,
    )
    assert result.returncode == 0, result.stderr
    assert "--subject-to-netflow" in result.stdout
    assert "--density-gate" in result.stdout


def test_anchor_selection_is_score_only_and_deterministic():
    scores = {9: 0.5, 3: 0.5, 7: 0.2}
    assert select_anchors(scores, 2) == {3, 9}


def test_core_bridge_is_asymmetric_and_role_constrained():
    config = BridgeConfig(anchor_budget=2)
    anchors = {1, 2}
    node_types = {
        1: "subject",
        2: "file",
        3: "netflow",
        4: "subject",
        5: "file",
        6: "netflow",
    }
    edges = [
        (1, 3),  # subject anchor -> netflow: include
        (6, 1),  # netflow -> subject anchor: exclude
        (2, 4),  # file anchor -> subject: include
        (4, 2),  # subject -> file anchor: include
        (1, 5),  # subject anchor -> file: disabled in core
    ]
    candidates, witnesses = expand_one_window(
        edges, anchors, node_types, time_window=8, config=config
    )
    assert candidates == {3, 4}
    assert {w.relation for w in witnesses} == {
        "subject_src_to_netflow",
        "file_src_to_subject",
        "file_dst_from_subject",
    }


def test_extended_bridge_adds_subject_to_file():
    config = BridgeConfig(subject_to_file=True)
    candidates, _ = expand_one_window(
        edges=[(1, 2)],
        anchors={1},
        node_types={1: "subject", 2: "file"},
        time_window=0,
        config=config,
    )
    assert candidates == {2}


def test_generation_is_independent_of_labels():
    config = BridgeConfig(anchor_budget=1)
    scores = {1: 10.0, 2: 0.0}
    windows = {1: 4, 2: 4}
    node_types = {1: "subject", 2: "netflow"}
    edge_windows = {4: [(1, 2)]}

    anchors, candidates, _ = generate_candidates(
        scores,
        windows,
        node_types,
        edge_windows.__getitem__,
        config,
    )
    assert anchors == {1}
    assert candidates == {2}

    # Labels enter only after the candidate set is frozen.
    first = evaluate_candidates(scores, {1: 0, 2: 1}, anchors, candidates)
    second = evaluate_candidates(scores, {1: 1, 2: 0}, anchors, candidates)
    assert first["candidates"] == second["candidates"] == 1
    assert candidates == {2}


def test_matched_budget_gain_is_computed_against_raw_ranking():
    scores = {1: 10.0, 2: 9.0, 3: 1.0, 4: 0.0}
    labels = {1: 1, 2: 0, 3: 0, 4: 1}
    stats = evaluate_candidates(scores, labels, anchors={1}, candidates={4})
    assert stats["covered_positives"] == 2
    assert stats["raw_hits_same_budget"] == 1
    assert stats["gain_over_raw"] == 1


def test_nanosecond_interval_parser():
    start, end = parse_interval_name(
        "2018-04-06 11:11:23.986188916~"
        "2018-04-06 11:27:15.756165904.csv",
        ".csv",
    )
    assert end > start
    assert end - start == 951_769_976_988


def test_configured_max_hops_rejects_unconstrained_expansion():
    try:
        BridgeConfig(max_hops=2).validate()
    except ValueError as error:
        assert "max_hops=1" in str(error)
    else:
        raise AssertionError("multi-hop expansion must not be silently enabled")


def test_density_gate_rejects_only_the_explosive_relation_without_labels():
    config = BridgeConfig(
        anchor_budget=2,
        density_gate_enabled=True,
        max_relation_expansion_ratio=1.0,
    )
    witnesses = {
        BridgeWitness(0, 1, 10, "subject_src_to_netflow"),
        BridgeWitness(0, 1, 11, "subject_src_to_netflow"),
        BridgeWitness(0, 1, 12, "subject_src_to_netflow"),
        BridgeWitness(0, 2, 20, "file_src_to_subject"),
    }
    accepted_candidates, accepted_witnesses, decisions = (
        apply_relation_density_gate({10, 11, 12, 20}, witnesses, config)
    )
    assert accepted_candidates == {20}
    assert {w.candidate_id for w in accepted_witnesses} == {20}
    by_family = {row["relation_family"]: row for row in decisions}
    assert by_family["subject_to_netflow"]["accepted"] is False
    assert by_family["file_to_subject"]["accepted"] is True


def test_density_gate_boundary_is_inclusive_and_gate_can_be_disabled():
    witnesses = {
        BridgeWitness(0, 1, 10, "subject_src_to_netflow"),
        BridgeWitness(0, 1, 11, "subject_src_to_netflow"),
        BridgeWitness(0, 1, 12, "subject_src_to_netflow"),
    }
    enabled = BridgeConfig(
        anchor_budget=2,
        file_to_subject=False,
        density_gate_enabled=True,
        max_relation_expansion_ratio=1.5,
    )
    candidates, _, decisions = apply_relation_density_gate(
        {10, 11, 12}, witnesses, enabled
    )
    assert candidates == {10, 11, 12}
    assert decisions[0]["expansion_ratio"] == 1.5

    disabled = BridgeConfig(
        anchor_budget=1,
        file_to_subject=False,
        density_gate_enabled=False,
    )
    candidates, _, decisions = apply_relation_density_gate(
        {10, 11, 12}, witnesses, disabled
    )
    assert candidates == {10, 11, 12}
    assert decisions[0]["accepted"] is True
