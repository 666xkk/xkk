"""Asymmetric role-constrained causal bridge episode construction.

This module is deliberately separate from training.  It consumes frozen node
scores and provenance windows, selects high-scoring anchors without labels,
and expands only along explicitly enabled role/direction transitions.  Ground
truth, when present in a result file, is accessed only after candidate
generation to produce an evaluation summary.

Run from the repository root with::

    python -m src.detection.causal_bridge --help
"""

from __future__ import annotations

import argparse
import calendar
import csv
import json
import re
from collections import defaultdict
from dataclasses import asdict, dataclass
from datetime import datetime
from pathlib import Path
from typing import Callable, Dict, Iterable, List, Mapping, Optional, Sequence, Set, Tuple


Edge = Tuple[int, int]


@dataclass(frozen=True)
class BridgeConfig:
    anchor_budget: int = 100
    subject_to_netflow: bool = True
    file_to_subject: bool = True
    subject_to_file: bool = False
    max_hops: int = 1
    density_gate_enabled: bool = False
    max_relation_expansion_ratio: float = 1.0

    def validate(self) -> None:
        if self.anchor_budget <= 0:
            raise ValueError("anchor_budget must be positive")
        if self.max_hops != 1:
            raise ValueError(
                "causal bridge currently supports max_hops=1 only; "
                "unconstrained multi-hop expansion is intentionally disabled"
            )
        if not (
            self.subject_to_netflow
            or self.file_to_subject
            or self.subject_to_file
        ):
            raise ValueError("at least one bridge relation must be enabled")
        if self.max_relation_expansion_ratio <= 0:
            raise ValueError("max_relation_expansion_ratio must be positive")


@dataclass(frozen=True, order=True)
class BridgeWitness:
    time_window: int
    anchor_id: int
    candidate_id: int
    relation: str


@dataclass
class SeedInputs:
    seed: int
    result_path: Path
    scores: Dict[int, float]
    windows: Dict[int, int]
    labels: Optional[Dict[int, int]]


_RELATION_FAMILY = {
    "subject_src_to_netflow": "subject_to_netflow",
    "file_src_to_subject": "file_to_subject",
    "file_dst_from_subject": "file_to_subject",
    "subject_src_to_file": "subject_to_file",
}


def enabled_relation_families(config: BridgeConfig) -> List[str]:
    """Return configured relation families in a stable order."""
    families = []
    if config.subject_to_netflow:
        families.append("subject_to_netflow")
    if config.file_to_subject:
        families.append("file_to_subject")
    if config.subject_to_file:
        families.append("subject_to_file")
    return families


def apply_relation_density_gate(
    candidates: Set[int],
    witnesses: Set[BridgeWitness],
    config: BridgeConfig,
) -> Tuple[Set[int], Set[BridgeWitness], List[Dict[str, object]]]:
    """Apply a label-free, per-relation expansion gate.

    A relation family is accepted when its number of unique candidates does
    not exceed ``anchor_budget * max_relation_expansion_ratio``. Decisions
    depend only on graph expansion volume; labels are never inspected here.
    """
    config.validate()
    candidates_by_family: Dict[str, Set[int]] = defaultdict(set)
    for witness in witnesses:
        family = _RELATION_FAMILY[witness.relation]
        candidates_by_family[family].add(witness.candidate_id)

    accepted_families: Set[str] = set()
    decisions: List[Dict[str, object]] = []
    for family in enabled_relation_families(config):
        family_candidates = candidates_by_family.get(family, set())
        ratio = len(family_candidates) / config.anchor_budget
        accepted = (
            not config.density_gate_enabled
            or ratio <= config.max_relation_expansion_ratio
        )
        if accepted:
            accepted_families.add(family)
        decisions.append(
            {
                "relation_family": family,
                "raw_candidates": len(family_candidates),
                "expansion_ratio": ratio,
                "threshold": config.max_relation_expansion_ratio,
                "gate_enabled": config.density_gate_enabled,
                "accepted": accepted,
            }
        )

    accepted_witnesses = {
        witness
        for witness in witnesses
        if _RELATION_FAMILY[witness.relation] in accepted_families
    }
    accepted_candidates = {
        witness.candidate_id for witness in accepted_witnesses
    }
    accepted_candidates.intersection_update(candidates)
    return accepted_candidates, accepted_witnesses, decisions


def select_anchors(scores: Mapping[int, float], budget: int) -> Set[int]:
    """Select anchors using scores only, with a deterministic node-id tie break."""
    if budget <= 0:
        raise ValueError("budget must be positive")
    ordered = sorted(scores, key=lambda node_id: (-scores[node_id], node_id))
    return set(ordered[: min(budget, len(ordered))])


def expand_one_window(
    edges: Iterable[Edge],
    anchors: Set[int],
    node_types: Mapping[int, str],
    time_window: int,
    config: BridgeConfig,
) -> Tuple[Set[int], Set[BridgeWitness]]:
    """Generate candidates for one window without consulting any labels."""
    config.validate()
    candidates: Set[int] = set()
    witnesses: Set[BridgeWitness] = set()

    def add(anchor_id: int, candidate_id: int, relation: str) -> None:
        if candidate_id in anchors:
            return
        candidates.add(candidate_id)
        witnesses.add(
            BridgeWitness(
                time_window=time_window,
                anchor_id=anchor_id,
                candidate_id=candidate_id,
                relation=relation,
            )
        )

    for source, target in edges:
        source = int(source)
        target = int(target)
        source_type = node_types.get(source, "UNKNOWN")
        target_type = node_types.get(target, "UNKNOWN")

        if (
            config.subject_to_netflow
            and source in anchors
            and source_type == "subject"
            and target_type == "netflow"
        ):
            add(source, target, "subject_src_to_netflow")

        if config.file_to_subject:
            if (
                source in anchors
                and source_type == "file"
                and target_type == "subject"
            ):
                add(source, target, "file_src_to_subject")
            if (
                target in anchors
                and target_type == "file"
                and source_type == "subject"
            ):
                add(target, source, "file_dst_from_subject")

        if (
            config.subject_to_file
            and source in anchors
            and source_type == "subject"
            and target_type == "file"
        ):
            add(source, target, "subject_src_to_file")

    return candidates, witnesses


def generate_candidates(
    scores: Mapping[int, float],
    windows: Mapping[int, int],
    node_types: Mapping[int, str],
    edges_for_window: Callable[[int], Iterable[Edge]],
    config: BridgeConfig,
) -> Tuple[Set[int], Set[int], Set[BridgeWitness]]:
    """Build bridge candidates from frozen scores, windows, types, and edges."""
    config.validate()
    anchors = select_anchors(scores, config.anchor_budget)
    anchors_by_window: Dict[int, Set[int]] = defaultdict(set)
    for anchor_id in anchors:
        time_window = int(windows.get(anchor_id, -1))
        if time_window >= 0:
            anchors_by_window[time_window].add(anchor_id)

    candidates: Set[int] = set()
    witnesses: Set[BridgeWitness] = set()
    for time_window, window_anchors in sorted(anchors_by_window.items()):
        new_candidates, new_witnesses = expand_one_window(
            edges=edges_for_window(time_window),
            anchors=window_anchors,
            node_types=node_types,
            time_window=time_window,
            config=config,
        )
        candidates.update(new_candidates)
        witnesses.update(new_witnesses)

    candidates.difference_update(anchors)
    witnesses = {
        witness for witness in witnesses if witness.candidate_id not in anchors
    }
    return anchors, candidates, witnesses


def evaluate_candidates(
    scores: Mapping[int, float],
    labels: Mapping[int, int],
    anchors: Set[int],
    candidates: Set[int],
) -> Dict[str, float]:
    """Evaluate an already generated episode; never used during generation."""
    positives = {node_id for node_id, label in labels.items() if int(label) == 1}
    anchor_positives = anchors & positives
    candidate_positives = candidates & positives
    covered = anchor_positives | candidate_positives
    review_budget = min(len(scores), len(anchors) + len(candidates))
    raw_order = sorted(scores, key=lambda node_id: (-scores[node_id], node_id))
    raw_hits = len(set(raw_order[:review_budget]) & positives)
    return {
        "positives": len(positives),
        "anchors": len(anchors),
        "anchor_positives": len(anchor_positives),
        "candidates": len(candidates),
        "candidate_positives": len(candidate_positives),
        "benign_candidates": len(candidates - positives),
        "candidate_precision": (
            len(candidate_positives) / len(candidates) if candidates else 0.0
        ),
        "covered_positives": len(covered),
        "attack_step_coverage": len(covered) / len(positives) if positives else 0.0,
        "review_budget": review_budget,
        "raw_hits_same_budget": raw_hits,
        "gain_over_raw": len(covered) - raw_hits,
    }


_TIMESTAMP_RE = re.compile(
    r"^(?P<base>\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2})(?:\.(?P<fraction>\d{1,9}))?$"
)


def parse_timestamp_ns(value: str) -> int:
    match = _TIMESTAMP_RE.match(value)
    if match is None:
        raise ValueError(f"invalid timestamp: {value!r}")
    parsed = datetime.strptime(match.group("base"), "%Y-%m-%d %H:%M:%S")
    seconds = calendar.timegm(parsed.timetuple())
    fraction = (match.group("fraction") or "").ljust(9, "0")
    return seconds * 1_000_000_000 + int(fraction or "0")


def parse_interval_name(name: str, suffix: str) -> Tuple[int, int]:
    if not name.endswith(suffix):
        raise ValueError(f"{name!r} does not end with {suffix!r}")
    interval = name[: -len(suffix)]
    start, end = interval.split("~", 1)
    return parse_timestamp_ns(start), parse_timestamp_ns(end)


class TemporalEdgeStore:
    """Map testing windows to maximally overlapping TemporalData files."""

    def __init__(self, test_loss_dir: Path, edge_dir: Path):
        self.loss_files = sorted(test_loss_dir.glob("*.csv"))
        self.edge_files = sorted(edge_dir.glob("*.TemporalData.simple"))
        if not self.loss_files:
            raise FileNotFoundError(f"no loss CSV files in {test_loss_dir}")
        if not self.edge_files:
            raise FileNotFoundError(f"no TemporalData files in {edge_dir}")
        self.edge_intervals = [
            (path, *parse_interval_name(path.name, ".TemporalData.simple"))
            for path in self.edge_files
        ]
        self._path_cache: Dict[int, Path] = {}

    def graph_path(self, time_window: int) -> Path:
        if time_window in self._path_cache:
            return self._path_cache[time_window]
        if time_window < 0 or time_window >= len(self.loss_files):
            raise IndexError(f"invalid time window {time_window}")
        loss_start, loss_end = parse_interval_name(
            self.loss_files[time_window].name, ".csv"
        )
        matches: List[Tuple[int, Path]] = []
        for path, edge_start, edge_end in self.edge_intervals:
            overlap = min(loss_end, edge_end) - max(loss_start, edge_start)
            if overlap > 0:
                matches.append((overlap, path))
        if not matches:
            raise FileNotFoundError(
                f"no edge window overlaps loss window {self.loss_files[time_window]}"
            )
        matches.sort(key=lambda item: (item[0], str(item[1])), reverse=True)
        self._path_cache[time_window] = matches[0][1]
        return self._path_cache[time_window]

    def edges(self, time_window: int) -> Iterable[Edge]:
        data = _torch_load(self.graph_path(time_window))
        return zip(map(int, data.src.tolist()), map(int, data.dst.tolist()))


def _torch_load(path: Path):
    import torch

    try:
        return torch.load(path, map_location="cpu", weights_only=False)
    except TypeError:  # Compatibility with older torch releases.
        return torch.load(path, map_location="cpu")


def discover_seed_inputs(results_root: Path) -> List[SeedInputs]:
    seed_dirs = []
    for path in results_root.glob("seed*"):
        match = re.fullmatch(r"seed(\d+)", path.name)
        if path.is_dir() and match:
            seed_dirs.append((int(match.group(1)), path))
    if not seed_dirs:
        raise FileNotFoundError(f"no seed directories below {results_root}")

    inputs: List[SeedInputs] = []
    for seed, seed_dir in sorted(seed_dirs):
        files = list(seed_dir.glob("result_model_epoch_*.pth"))
        if len(files) != 1:
            raise RuntimeError(
                f"{seed_dir}: expected exactly one result_model_epoch_*.pth, found {files}"
            )
        obj = _torch_load(files[0])
        scores = {int(node_id): float(record["score"]) for node_id, record in obj.items()}
        windows = {
            int(node_id): int(record.get("tw_with_max_loss", -1))
            for node_id, record in obj.items()
        }
        labels = None
        if all("y_true" in record for record in obj.values()):
            labels = {
                int(node_id): int(record["y_true"]) for node_id, record in obj.items()
            }
        inputs.append(
            SeedInputs(
                seed=seed,
                result_path=files[0],
                scores=scores,
                windows=windows,
                labels=labels,
            )
        )
    return inputs


def _write_csv(path: Path, rows: Sequence[Mapping[str, object]]) -> None:
    if not rows:
        return
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0].keys()))
        writer.writeheader()
        writer.writerows(rows)


def run(args: argparse.Namespace) -> List[Dict[str, object]]:
    config = BridgeConfig(
        anchor_budget=args.anchor_budget,
        subject_to_netflow=args.subject_to_netflow,
        file_to_subject=args.file_to_subject,
        subject_to_file=args.subject_to_file,
        max_hops=args.max_hops,
        density_gate_enabled=args.density_gate,
        max_relation_expansion_ratio=args.max_relation_expansion_ratio,
    )
    config.validate()
    output_dir = Path(args.output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    node_map = _torch_load(Path(args.node_map))
    node_types = {
        int(node_id): str(metadata.get("type", "UNKNOWN"))
        for node_id, metadata in node_map.items()
    }
    edge_store = TemporalEdgeStore(Path(args.test_loss_dir), Path(args.edge_dir))
    seed_inputs = discover_seed_inputs(Path(args.results_root))
    anchors_by_seed: Dict[int, Set[int]] = {}
    anchors_by_seed_and_window: Dict[int, Dict[int, Set[int]]] = {}
    candidates_by_seed: Dict[int, Set[int]] = {}
    witnesses_by_seed: Dict[int, Set[BridgeWitness]] = {}

    # Prepare every seed before reading graph files.  We then stream each
    # required time window exactly once and apply it to all seeds that have an
    # anchor in that window.  This avoids five complete passes over large
    # TemporalData artifacts without retaining all windows in memory.
    all_windows: Set[int] = set()
    for seed_input in seed_inputs:
        anchors = select_anchors(seed_input.scores, config.anchor_budget)
        grouped: Dict[int, Set[int]] = defaultdict(set)
        for anchor_id in anchors:
            time_window = int(seed_input.windows.get(anchor_id, -1))
            if time_window >= 0:
                grouped[time_window].add(anchor_id)
                all_windows.add(time_window)
        anchors_by_seed[seed_input.seed] = anchors
        anchors_by_seed_and_window[seed_input.seed] = grouped
        candidates_by_seed[seed_input.seed] = set()
        witnesses_by_seed[seed_input.seed] = set()

    for time_window in sorted(all_windows):
        edges = list(edge_store.edges(time_window))
        for seed_input in seed_inputs:
            window_anchors = anchors_by_seed_and_window[seed_input.seed].get(
                time_window
            )
            if not window_anchors:
                continue
            new_candidates, new_witnesses = expand_one_window(
                edges=edges,
                anchors=window_anchors,
                node_types=node_types,
                time_window=time_window,
                config=config,
            )
            candidates_by_seed[seed_input.seed].update(new_candidates)
            witnesses_by_seed[seed_input.seed].update(new_witnesses)

    for seed_input in seed_inputs:
        anchors = anchors_by_seed[seed_input.seed]
        candidates_by_seed[seed_input.seed].difference_update(anchors)
        witnesses_by_seed[seed_input.seed] = {
            witness
            for witness in witnesses_by_seed[seed_input.seed]
            if witness.candidate_id not in anchors
        }

    raw_candidates_by_seed = {
        seed: set(candidates) for seed, candidates in candidates_by_seed.items()
    }
    raw_witnesses_by_seed = {
        seed: set(witnesses) for seed, witnesses in witnesses_by_seed.items()
    }
    gate_decisions_by_seed: Dict[int, List[Dict[str, object]]] = {}
    for seed_input in seed_inputs:
        seed = seed_input.seed
        gated_candidates, gated_witnesses, decisions = apply_relation_density_gate(
            candidates_by_seed[seed], witnesses_by_seed[seed], config
        )
        candidates_by_seed[seed] = gated_candidates
        witnesses_by_seed[seed] = gated_witnesses
        gate_decisions_by_seed[seed] = decisions

    summaries: List[Dict[str, object]] = []

    for seed_input in seed_inputs:
        anchors = anchors_by_seed[seed_input.seed]
        candidates = candidates_by_seed[seed_input.seed]
        witnesses = witnesses_by_seed[seed_input.seed]
        raw_witnesses = raw_witnesses_by_seed[seed_input.seed]
        accepted_witnesses = set(witnesses)
        witness_rows = []
        raw_witness_rows = []
        for witness in sorted(raw_witnesses):
            anchor_meta = node_map.get(witness.anchor_id, {})
            candidate_meta = node_map.get(witness.candidate_id, {})
            row = {
                "seed": seed_input.seed,
                "time_window": witness.time_window,
                "anchor_id": witness.anchor_id,
                "anchor_score": seed_input.scores[witness.anchor_id],
                "anchor_type": node_types.get(witness.anchor_id, "UNKNOWN"),
                "anchor_path": anchor_meta.get("path", "UNKNOWN"),
                "candidate_id": witness.candidate_id,
                "candidate_type": node_types.get(witness.candidate_id, "UNKNOWN"),
                "candidate_path": candidate_meta.get("path", "UNKNOWN"),
                "relation": witness.relation,
                "relation_family": _RELATION_FAMILY[witness.relation],
                "accepted_by_density_gate": witness in accepted_witnesses,
            }
            raw_witness_rows.append(row)
            if witness in accepted_witnesses:
                witness_rows.append(row)
        _write_csv(output_dir / f"episodes_seed{seed_input.seed}.csv", witness_rows)
        _write_csv(
            output_dir / f"episodes_raw_seed{seed_input.seed}.csv",
            raw_witness_rows,
        )
        gate_rows = [
            {"seed": seed_input.seed, **decision}
            for decision in gate_decisions_by_seed[seed_input.seed]
        ]
        _write_csv(
            output_dir / f"relation_gate_seed{seed_input.seed}.csv", gate_rows
        )

        summary: Dict[str, object] = {
            "dataset": args.dataset,
            "seed": seed_input.seed,
            "result_path": str(seed_input.result_path),
        }
        summary.update(asdict(config))
        summary["raw_witnesses"] = len(raw_witnesses)
        summary["raw_candidates"] = len(
            raw_candidates_by_seed[seed_input.seed]
        )
        summary["accepted_relations"] = ";".join(
            str(decision["relation_family"])
            for decision in gate_decisions_by_seed[seed_input.seed]
            if decision["accepted"]
        )
        summary["rejected_relations"] = ";".join(
            str(decision["relation_family"])
            for decision in gate_decisions_by_seed[seed_input.seed]
            if not decision["accepted"]
        )
        summary["witnesses"] = len(witnesses)
        if seed_input.labels is not None and not args.skip_evaluation:
            summary.update(
                evaluate_candidates(
                    seed_input.scores,
                    seed_input.labels,
                    anchors,
                    candidates,
                )
            )
        else:
            summary.update({"anchors": len(anchors), "candidates": len(candidates)})
        summaries.append(summary)
        print(
            f"seed={seed_input.seed} anchors={len(anchors)} candidates={len(candidates)} "
            f"covered={summary.get('covered_positives', 'NA')}/"
            f"{summary.get('positives', 'NA')} gain={summary.get('gain_over_raw', 'NA')}"
        )

    _write_csv(output_dir / "summary.csv", summaries)
    manifest = {
        "dataset": args.dataset,
        "results_root": str(Path(args.results_root)),
        "test_loss_dir": str(Path(args.test_loss_dir)),
        "edge_dir": str(Path(args.edge_dir)),
        "node_map": str(Path(args.node_map)),
        "skip_evaluation": args.skip_evaluation,
        **asdict(config),
    }
    with (output_dir / "run_config.json").open("w") as handle:
        json.dump(manifest, handle, indent=2, sort_keys=True)
    print(f"wrote: {output_dir / 'summary.csv'}")
    return summaries


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description="Build asymmetric role-constrained bridge episodes from frozen scores."
    )
    parser.add_argument("--dataset", required=True)
    parser.add_argument("--results-root", required=True)
    parser.add_argument("--test-loss-dir", required=True)
    parser.add_argument("--edge-dir", required=True)
    parser.add_argument("--node-map", required=True)
    parser.add_argument("--anchor-budget", type=int, default=100)
    parser.add_argument("--subject-to-netflow", action="store_true")
    parser.add_argument("--file-to-subject", action="store_true")
    parser.add_argument("--subject-to-file", action="store_true")
    parser.add_argument("--max-hops", type=int, default=1)
    parser.add_argument(
        "--density-gate",
        action="store_true",
        help=(
            "Reject relation families whose unique candidate count exceeds "
            "anchor_budget multiplied by --max-relation-expansion-ratio."
        ),
    )
    parser.add_argument(
        "--max-relation-expansion-ratio",
        type=float,
        default=1.0,
    )
    parser.add_argument("--output-dir", required=True)
    parser.add_argument(
        "--skip-evaluation",
        action="store_true",
        help="Generate episodes without reading y_true for metrics.",
    )
    return parser


def main(argv: Optional[Sequence[str]] = None) -> int:
    args = build_parser().parse_args(argv)
    run(args)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
