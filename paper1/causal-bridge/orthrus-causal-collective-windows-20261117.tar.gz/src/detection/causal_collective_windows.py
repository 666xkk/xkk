"""Strictly causal collective weak-evidence window scoring.

The module consumes frozen per-window edge-loss CSV files.  For every window,
it reduces incident edge losses to one score per node, averages the highest
``node_top_k`` scores for a configured role, and then averages only the current
and preceding ``temporal_scale - 1`` window scores.  Future files and attack
labels never enter score computation.

The optional attack intervals are used only after all scores and the fixed
review-budget selection have been frozen, to produce an evaluation summary.
"""

from __future__ import annotations

import argparse
import csv
import json
import re
from collections import deque
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Dict, Iterable, List, Mapping, Optional, Sequence, Tuple

from .causal_bridge import parse_interval_name, parse_timestamp_ns


@dataclass(frozen=True)
class CollectiveWindowConfig:
    node_role: str = "file"
    node_top_k: int = 10
    temporal_scale: int = 4
    window_budget: int = 20
    use_dst_node_loss: bool = True

    def validate(self) -> None:
        if not self.node_role.strip():
            raise ValueError("node_role must be non-empty")
        if self.node_top_k <= 0:
            raise ValueError("node_top_k must be positive")
        if self.temporal_scale <= 0:
            raise ValueError("temporal_scale must be positive")
        if self.window_budget <= 0:
            raise ValueError("window_budget must be positive")


def message_has_role(message: object, role: str) -> bool:
    """Recognize the serialized provenance-role dictionary without eval()."""
    text = str(message)
    return f"'{role}':" in text or f'"{role}":' in text


def update_maximum(scores: Dict[int, float], node_id: object, loss: object) -> None:
    node = int(node_id)
    value = float(loss)
    previous = scores.get(node)
    if previous is None or value > previous:
        scores[node] = value


def node_scores_from_rows(
    rows: Iterable[Mapping[str, object]],
    role: str,
    use_dst_node_loss: bool,
) -> Dict[int, float]:
    """Compute current-window node scores from current-window rows only."""
    scores: Dict[int, float] = {}
    for row in rows:
        if message_has_role(row.get("srcmsg", ""), role):
            update_maximum(scores, row["srcnode"], row["loss"])
        if use_dst_node_loss and message_has_role(row.get("dstmsg", ""), role):
            update_maximum(scores, row["dstnode"], row["loss"])
    return scores


def read_window_node_scores(
    path: Path,
    role: str,
    use_dst_node_loss: bool,
) -> Dict[int, float]:
    with path.open(newline="") as handle:
        return node_scores_from_rows(
            csv.DictReader(handle), role, use_dst_node_loss
        )


def top_k_mean(scores: Mapping[int, float], k: int) -> float:
    if k <= 0:
        raise ValueError("k must be positive")
    if not scores:
        return 0.0
    ordered = sorted(scores.values(), reverse=True)[:k]
    return sum(ordered) / len(ordered)


def causal_rolling_mean(values: Sequence[float], scale: int) -> List[float]:
    """Return scores using only each value and its causal prefix."""
    if scale <= 0:
        raise ValueError("scale must be positive")
    history: deque[float] = deque(maxlen=scale)
    output: List[float] = []
    running_sum = 0.0
    for value in values:
        value = float(value)
        if len(history) == scale:
            running_sum -= history[0]
        history.append(value)
        running_sum += value
        output.append(running_sum / len(history))
    return output


def select_window_indices(scores: Sequence[float], budget: int) -> List[int]:
    """Freeze a deterministic analyst-review budget after scoring."""
    if budget <= 0:
        raise ValueError("budget must be positive")
    return sorted(
        range(len(scores)), key=lambda index: (-float(scores[index]), index)
    )[: min(budget, len(scores))]


def parse_attack_interval(value: str) -> Tuple[int, int]:
    try:
        start, end = value.split("~", 1)
    except ValueError as error:
        raise argparse.ArgumentTypeError(
            "attack interval must be START~END"
        ) from error
    start_ns = parse_timestamp_ns(start)
    end_ns = parse_timestamp_ns(end)
    if end_ns <= start_ns:
        raise argparse.ArgumentTypeError("attack interval end must follow start")
    return start_ns, end_ns


def overlaps_any(
    start_ns: int,
    end_ns: int,
    intervals: Sequence[Tuple[int, int]],
) -> bool:
    return any(start_ns < attack_end and end_ns > attack_start
               for attack_start, attack_end in intervals)


_SEED_PATH_RE = re.compile(r"seed(\d+)_test_dir\.txt")


def discover_seed_test_dirs(metadata_root: Path) -> List[Tuple[int, Path]]:
    discovered = []
    for path in metadata_root.glob("seed*_test_dir.txt"):
        match = _SEED_PATH_RE.fullmatch(path.name)
        if match is None:
            continue
        test_dir = Path(path.read_text().strip())
        if not test_dir.is_dir():
            raise FileNotFoundError(f"seed test directory does not exist: {test_dir}")
        discovered.append((int(match.group(1)), test_dir))
    if not discovered:
        raise FileNotFoundError(f"no seed*_test_dir.txt below {metadata_root}")
    return sorted(discovered)


def score_seed(
    seed: int,
    test_dir: Path,
    config: CollectiveWindowConfig,
    attack_intervals: Sequence[Tuple[int, int]],
) -> Tuple[List[Dict[str, object]], Dict[str, object]]:
    config.validate()
    paths = sorted(test_dir.glob("*.csv"))
    if not paths:
        raise FileNotFoundError(f"no window CSV files in {test_dir}")

    records: List[Dict[str, object]] = []
    raw_scores: List[float] = []
    for window, path in enumerate(paths):
        node_scores = read_window_node_scores(
            path, config.node_role, config.use_dst_node_loss
        )
        raw_score = top_k_mean(node_scores, config.node_top_k)
        start_ns, end_ns = parse_interval_name(path.name, ".csv")
        raw_scores.append(raw_score)
        records.append(
            {
                "seed": seed,
                "window": window,
                "file": path.name,
                "start_ns": start_ns,
                "end_ns": end_ns,
                "role_nodes": len(node_scores),
                "raw_collective_score": raw_score,
            }
        )

    causal_scores = causal_rolling_mean(raw_scores, config.temporal_scale)
    selected = set(select_window_indices(causal_scores, config.window_budget))
    for index, record in enumerate(records):
        record["causal_collective_score"] = causal_scores[index]
        record["selected_for_review"] = index in selected

    summary: Dict[str, object] = {
        "seed": seed,
        "test_dir": str(test_dir),
        "windows": len(records),
        "selected_windows": len(selected),
        **asdict(config),
    }

    if attack_intervals:
        attack_windows = {
            index
            for index, record in enumerate(records)
            if overlaps_any(
                int(record["start_ns"]),
                int(record["end_ns"]),
                attack_intervals,
            )
        }
        ordered = sorted(
            range(len(records)),
            key=lambda index: (-causal_scores[index], index),
        )
        ranks = {index: rank for rank, index in enumerate(ordered, start=1)}
        attack_ranks = sorted(ranks[index] for index in attack_windows)
        summary.update(
            {
                "attack_windows": len(attack_windows),
                "covered_attack_windows": len(attack_windows & selected),
                "attack_window_recall": (
                    len(attack_windows & selected) / len(attack_windows)
                    if attack_windows else 0.0
                ),
                "best_attack_rank": min(attack_ranks) if attack_ranks else -1,
                "median_attack_rank": (
                    (attack_ranks[(len(attack_ranks) - 1) // 2]
                     + attack_ranks[len(attack_ranks) // 2]) / 2
                    if attack_ranks else -1
                ),
                "worst_attack_rank": max(attack_ranks) if attack_ranks else -1,
            }
        )
        for index, record in enumerate(records):
            record["is_attack_window"] = index in attack_windows

    return records, summary


def write_csv(path: Path, rows: Sequence[Mapping[str, object]]) -> None:
    if not rows:
        return
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0].keys()))
        writer.writeheader()
        writer.writerows(rows)


def run(args: argparse.Namespace) -> List[Dict[str, object]]:
    config = CollectiveWindowConfig(
        node_role=args.node_role,
        node_top_k=args.node_top_k,
        temporal_scale=args.temporal_scale,
        window_budget=args.window_budget,
        use_dst_node_loss=not args.src_only,
    )
    config.validate()
    output_dir = Path(args.output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)

    summaries = []
    for seed, test_dir in discover_seed_test_dirs(Path(args.metadata_root)):
        records, summary = score_seed(
            seed, test_dir, config, args.attack_interval
        )
        write_csv(output_dir / f"window_scores_seed{seed}.csv", records)
        summaries.append(summary)
        print(
            f"seed={seed} windows={summary['windows']} "
            f"selected={summary['selected_windows']} "
            f"attack_coverage={summary.get('covered_attack_windows', 'NA')}/"
            f"{summary.get('attack_windows', 'NA')}"
        )

    write_csv(output_dir / "summary.csv", summaries)
    manifest = {
        "metadata_root": str(Path(args.metadata_root)),
        "attack_intervals": args.attack_interval,
        **asdict(config),
    }
    with (output_dir / "run_config.json").open("w") as handle:
        json.dump(manifest, handle, indent=2, sort_keys=True)
    print(f"wrote: {output_dir / 'summary.csv'}")
    return summaries


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        description="Strictly causal collective weak-evidence window scoring."
    )
    parser.add_argument("--metadata-root", required=True)
    parser.add_argument("--node-role", default="file")
    parser.add_argument("--node-top-k", type=int, default=10)
    parser.add_argument("--temporal-scale", type=int, default=4)
    parser.add_argument("--window-budget", type=int, default=20)
    parser.add_argument(
        "--src-only",
        action="store_true",
        help="Do not propagate an edge loss to its destination node.",
    )
    parser.add_argument(
        "--attack-interval",
        action="append",
        type=parse_attack_interval,
        default=[],
        metavar="START~END",
        help="Optional evaluation interval; repeat for multiple attacks.",
    )
    parser.add_argument("--output-dir", required=True)
    return parser


def main(argv: Optional[Sequence[str]] = None) -> int:
    args = build_parser().parse_args(argv)
    run(args)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
