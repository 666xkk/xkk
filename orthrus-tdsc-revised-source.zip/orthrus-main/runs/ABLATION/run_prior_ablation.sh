#!/bin/bash
set -u
set -o pipefail
cd /hy-tmp/orthrus || exit 1
export PYTHONHASHSEED=0

DATASET=CADETS_E3
LR=0.001
RATE=0.15
EPOCHS=20
OUT=runs/ABLATION
mkdir -p "$OUT"

log(){ echo "[$(date +%H:%M:%S)] $*"; }

# ---------------------------------------------------------------- 快照
snapshot () {
  local label="$1" ev="$2"
  local d="$OUT/$label"
  mkdir -p "$d"
  [ -z "$ev" ] || [ ! -d "$ev" ] && { log "[snap][FAIL] $label: no eval dir"; return 1; }
  cp -r "$ev" "$d/precision_recall_dir" 2>/dev/null
  local h; h=$(echo "$ev" | cut -d/ -f4 | cut -c1-8)
  log "[snap] $label  hash=$h  files=$(ls "$d/precision_recall_dir" | wc -l)"
}

# ---------------------------------------------------------------- 找新生成的 stage-1
find_s1 () {
  python - "$1" <<'PY'
import sys, glob, os, torch
since = float(sys.argv[1])
c = []
for d in glob.glob("artifacts/detection/gnn_training/*/CADETS_E3/trained_models"):
    eps = sorted(glob.glob(os.path.join(d, "model_epoch_*")),
                 key=lambda p: int(p.split("_")[-1]))
    if len(eps) < 20:                      # 必须跑满 20 轮
        continue
    p = os.path.join(eps[-1], "state_dict.pkl")
    if not os.path.exists(p): continue
    if os.path.getmtime(d) <= since: continue      # 只认本次新生成的
    try: sd = torch.load(p, map_location="cpu")
    except Exception: continue
    if any("link_head" in k for k in sd):
        c.append((os.path.getmtime(d), d))
if not c:
    raise SystemExit("[FATAL] no NEW stage-1 dir with link_head")
print(max(c)[1])
PY
}

# ---------------------------------------------------------------- 单臂单 seed
run_one () {
  local arm="$1" seed="$2" opt="$3"
  local label="${arm}_s${seed}"

  log "=========== $label START ==========="

  # ---- stage-1：纯掩码预训练 ----
  local T0; T0=$(date +%s)
  python -u -m src.orthrus "$DATASET" --run_from_training --seed="$seed" --train_only \
    --detection.gnn_training.lr="$LR" \
    --detection.gnn_training.num_epochs="$EPOCHS" \
    --detection.gnn_training.mask.mask_rate="$RATE" \
    --detection.gnn_training.mask.base_type_loss_weight=0.0 \
    $opt \
    --exp="ABL_${label}_s1" 2>&1 | tee "$OUT/${label}_s1.log" \
    | grep -E "Epoch: (01|20),"

  local S1; S1=$(find_s1 "$T0") || { log "[FATAL] $label stage-1"; return 1; }
  log "[stage1] $S1"
  local n; n=$(ls "$S1" | wc -l)
  log "[stage1] ckpt dirs = $n"
  [ "$n" -lt 20 ] && { log "[FATAL] ckpt < 20"; return 1; }

  python -c "
import torch,sys
sd=torch.load('$S1/model_epoch_20/state_dict.pkl',map_location='cpu')
k=sum('link_head' in x or 'time_head' in x for x in sd)
print('heads in ckpt:',k); sys.exit(0 if k>0 else 1)" || { log "[FATAL] wrong ckpt"; return 1; }

  # ---- stage-2：加载预训练、关掩码、跑主任务 ----
  python -u -m src.orthrus "$DATASET" --run_from_training --seed="$seed" \
    --detection.gnn_training.lr="$LR" \
    --detection.gnn_training.num_epochs="$EPOCHS" \
    --detection.gnn_training.pretrained_dir="$S1" \
    --detection.gnn_training.mask.enabled=false \
    --detection.gnn_training.mask.mask_rate="$RATE" \
    $opt \
    --detection.evaluation.node_evaluation.use_kmeans=false \
    --exp="ABL_${label}_s2" 2>&1 | tee "$OUT/${label}_s2.log" \
    | grep -E "pretrain|Best model epoch|Before attack" -A13

  # ---- 快照 ----
  local ev; ev=$(grep -oE "evaluation/[0-9a-f]{64}" "$OUT/${label}_s2.log" | head -1 | cut -d/ -f2)
  if [ -n "$ev" ]; then
    snapshot "$label" "artifacts/detection/evaluation/$ev/$DATASET/precision_recall_dir"
  else
    snapshot "$label" "$(ls -dt artifacts/detection/evaluation/*/$DATASET/precision_recall_dir | head -1)"
  fi
  log "=========== $label DONE ==========="
}

# ============ 第0步：先保护将被覆盖的旧结果（只复制） ============
log ">>> 保护旧 temporal@lr1e-3 结果"
for H in 40918a90 5a786b90 73121959 3c19a0c6 6bc46c74; do
  SRC=$(ls -d artifacts/detection/evaluation/${H}*/CADETS_E3/precision_recall_dir 2>/dev/null | head -1)
  [ -e "$SRC" ] && { mkdir -p "$OUT/PRE_$H"; cp -r "$SRC" "$OUT/PRE_$H/" 2>/dev/null && log "[pre] $H saved"; }
done

# ============ 6 个 run ============
for S in 0 1 4; do
  run_one uniform  "$S" "--detection.gnn_training.mask.sampling_prior=uniform"
done
for S in 0 1 4; do
  run_one temporal "$S" "--detection.gnn_training.mask.sampling_prior=temporal"
done

log "ALL DONE"
