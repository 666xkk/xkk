"""Recovery heads for context-event masked modeling."""
import torch
import torch.nn as nn
import torch.nn.functional as F


class MaskedLinkHead(nn.Module):
    """Reconstruct the destination of a masked context event.

    Query  : contextual embedding of the masked event's source (computed
             WITHOUT the masked event).
    Positive: destination embedding.
    Negatives: sampled from the batch node pool, filtered against the
             source's VISIBLE neighbours and the true destination
             (see OrthrusEncoder._sample_negatives).
    Invalid negative slots carry -inf logits (no gradient contribution).
    """

    def __init__(self, node_dim, hid_dim, temperature=0.1):
        super().__init__()
        self.temperature = temperature
        self.q_mlp = nn.Sequential(
            nn.Linear(node_dim, hid_dim),
            nn.PReLU(),
            nn.Linear(hid_dim, node_dim),
        )

    def forward(self, h_src, h_pos, h_neg, neg_valid=None):
        q = F.normalize(self.q_mlp(h_src), dim=-1)
        h_pos = F.normalize(h_pos, dim=-1)
        h_neg = F.normalize(h_neg, dim=-1)
        pos_logit = (q * h_pos).sum(dim=-1, keepdim=True) / self.temperature
        neg_logits = (q.unsqueeze(1) * h_neg).sum(dim=-1) / self.temperature
        if neg_valid is not None:
            neg_logits = neg_logits.masked_fill(~neg_valid, float("-inf"))
        logits = torch.cat([pos_logit, neg_logits], dim=1)
        target = torch.zeros(logits.size(0), dtype=torch.long, device=logits.device)
        # [probe] if this saturates at ~1.0 in the first epoch, the negative
        # pool is too easy and the head carries little learning signal.
        self.last_acc = float((logits.argmax(dim=1) == target).float().mean().detach())
        return F.cross_entropy(logits, target)


class TimeGapHead(nn.Module):
    """Reconstruct log1p(inter-arrival gap, seconds) of a masked context event.
    Inputs contain no time value -> no leakage of the target."""

    def __init__(self, node_dim, hid_dim):
        super().__init__()
        self.mlp = nn.Sequential(
            nn.Linear(2 * node_dim, hid_dim),
            nn.PReLU(),
            nn.Linear(hid_dim, 1),
        )

    def forward(self, h_src, h_dst, dt, valid):
        pred = self.mlp(torch.cat([h_src, h_dst], dim=-1)).squeeze(-1)
        if valid.any():
            return F.mse_loss(pred[valid], torch.log1p(dt[valid]))
        return pred.sum() * 0.0