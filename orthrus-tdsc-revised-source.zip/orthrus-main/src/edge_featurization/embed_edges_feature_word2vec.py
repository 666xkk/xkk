import os

from src.config import rel2id, ntype2id, get_runtime_required_args, get_yml_cfg
from src.provnet_utils import *
from config import *

import numpy as np
import torch
import torch.nn.functional as F
from tqdm import tqdm
from torch_geometric.data import *

def cal_word_weight(n,percentage):
    d = -1 / n * percentage / 100
    a_1 = 1/n - 0.5 * (n-1) * d
    sequence = []
    for i in range(n):
        a_i = a_1 + i * d
        sequence.append(a_i)
    return sequence

def _tokens_for_node(msg, use_node_types, normalize_missing):
    text = (msg[0] + ' ' + msg[1]) if use_node_types else msg[1]
    if msg[0] == 'subject':
        return tokenize_subject(text, normalize_missing)
    if msg[0] == 'file':
        return tokenize_file(text, normalize_missing)
    return tokenize_netflow(text, normalize_missing)


def get_indexid2vec(indexid2msg, model_path, use_node_types,
                    decline_percentage, normalize_missing=False,
                    method="feature_word2vec", hash_seed=0, emb_dim=None):
    model = None
    if method == "feature_word2vec":
        from gensim.models import Word2Vec
        model = Word2Vec.load(model_path)
        log(f"Loaded model from {model_path}")
    elif method == "canonical_hash":
        from src.attr_schema import canonical_hash_embedding
        if emb_dim is None:
            raise ValueError("emb_dim is required for canonical_hash")
        log(f"Using collector-independent canonical hashing (dim={emb_dim}, "
            f"seed={hash_seed})")
    else:
        raise ValueError(f"Unsupported node featurizer: {method}")

    indexid2vec = {}
    for indexid, msg in indexid2msg.items():
        tokens = _tokens_for_node(msg, use_node_types, normalize_missing)

        if method == "canonical_hash":
            indexid2vec[int(indexid)] = canonical_hash_embedding(
                tokens, dim=emb_dim, seed=hash_seed)
            continue

        weight_list = cal_word_weight(len(tokens), decline_percentage)

        word_vectors = [model.wv[word] for word in tokens]
        weighted_vectors = [weight * word_vec for weight, word_vec in zip(weight_list, word_vectors)]
        sentence_vector = np.mean(weighted_vectors, axis=0)

        normalized_vector = sentence_vector / np.linalg.norm(sentence_vector)

        indexid2vec[int(indexid)] = np.array(normalized_vector)

    log(f"Finish generating normalized node vectors.")

    return indexid2vec

def gen_relation_onehot(rel2id):
    relvec=torch.nn.functional.one_hot(torch.arange(0, len(rel2id.keys())//2), num_classes=len(rel2id.keys())//2)
    rel2vec={}
    for i in rel2id.keys():
        if type(i) is not int:
            rel2vec[i]= relvec[rel2id[i]-1]
            rel2vec[relvec[rel2id[i]-1]]=i
    return rel2vec

def gen_vectorized_graphs(indexid2vec, etype2oh, ntype2oh, split_files, out_dir, logger, cfg, indexid2pres=None):
    base_dir = cfg.graph_construction.build_graphs._graphs_dir
    sorted_paths = get_all_files_from_folders(base_dir, split_files)
    add_miss = cfg.edge_featurization.embed_edges.add_missingness
    miss_dim = cfg.edge_featurization.embed_edges.missingness_dim

    for path in tqdm(sorted_paths, "Embedding edges"):
        # log(f"Computing edge embeddings: {path}")
        file = path.split("/")[-1]

        graph = torch.load(path)

        sorted_edges = graph.edges(data=True, keys=True)

        dataset = TemporalData()
        src = []
        dst = []
        msg = []
        t = []
        n_missing_pres = 0
        for u, v, k, attr in sorted_edges:
            src.append(int(u))
            dst.append(int(v))

            parts = [
                ntype2oh[graph.nodes[u]['node_type']],
                torch.from_numpy(indexid2vec[int(u)]),
                etype2oh[attr["label"]],
                ntype2oh[graph.nodes[v]['node_type']],
                torch.from_numpy(indexid2vec[int(v)]),
            ]
            if add_miss:
                # [Paper 2] presence (missingness) one-hot channel per node.
                bu = indexid2pres.get(int(u), 0) if indexid2pres else 0
                bv = indexid2pres.get(int(v), 0) if indexid2pres else 0
                if indexid2pres is not None and (int(u) not in indexid2pres or int(v) not in indexid2pres):
                    n_missing_pres += 1
                parts.append(F.one_hot(torch.tensor(bu), num_classes=miss_dim).float())
                parts.append(F.one_hot(torch.tensor(bv), num_classes=miss_dim).float())
            msg.append(torch.cat(parts))
            t.append(int(attr["time"]))

        if add_miss and n_missing_pres > 0:
            logger.warning(f"{file}: {n_missing_pres} edges reference nodes without "
                           f"a presence mask (defaulted to all-absent)")

        dataset.src = torch.tensor(src)
        dataset.dst = torch.tensor(dst)
        dataset.t = torch.tensor(t)
        dataset.msg = torch.vstack(msg)
        dataset.src = dataset.src.to(torch.long)
        dataset.dst = dataset.dst.to(torch.long)
        dataset.msg = dataset.msg.to(torch.float)
        dataset.t = dataset.t.to(torch.long)

        os.makedirs(out_dir, exist_ok=True)
        torch.save(dataset, os.path.join(out_dir, f"{file}.TemporalData.simple"))

        # log(f'Graph: {file}. Events num: {len(sorted_edges)}. Node num: {len(graph.nodes)}')

def main(cfg):
    logger = get_logger(
        name="embed_edges_by_feature_word2vec",
        filename=os.path.join(cfg.edge_featurization.embed_edges._logs_dir, "embed_edges.log")
    )

    use_node_types = cfg.edge_featurization.embed_nodes.feature_word2vec.use_node_types
    use_cmd =  cfg.edge_featurization.embed_nodes.feature_word2vec.use_cmd
    use_port = cfg.edge_featurization.embed_nodes.feature_word2vec.use_port
    decline_percentage = cfg.edge_featurization.embed_nodes.feature_word2vec.decline_rate
    tokenize_missing = cfg.edge_featurization.embed_nodes.feature_word2vec.tokenize_missing
    add_missingness = cfg.edge_featurization.embed_edges.add_missingness
    missingness_dim = cfg.edge_featurization.embed_edges.missingness_dim

    if add_missingness:
        from src.attr_schema import ATTR_INDEX
        expected = 1 << len(ATTR_INDEX)
        assert missingness_dim == expected, (
            f"missingness_dim must be 2 ** len(ATTR_INDEX) = {expected}; "
            f"found {missingness_dim}")

    log("Loading node msg from database...")
    cur, connect = init_database_connection(cfg)
    indexid2msg = get_indexid2msg(cur, use_cmd=use_cmd, use_port=use_port)
    indexid2msg = dict(sorted(indexid2msg.items(), key=lambda item: int(item[0])))

    indexid2pres = None
    if add_missingness:
        log("Loading node attribute presence masks from database...")
        indexid2pres = get_indexid2presence(cur, use_cmd=use_cmd, use_port=use_port)

    log("Generating node vectors...")
    method = cfg.edge_featurization.embed_nodes.used_method.strip()
    feature_word2vec_model_path = (
        cfg.edge_featurization.embed_nodes.feature_word2vec._model_dir
        + 'feature_word2vec.model' if method == "feature_word2vec" else None)
    indexid2vec = get_indexid2vec(indexid2msg=indexid2msg, model_path=feature_word2vec_model_path,
                                  use_node_types=use_node_types,
                                  decline_percentage=decline_percentage,
                                  normalize_missing=tokenize_missing,
                                  method=method,
                                  hash_seed=cfg.edge_featurization.embed_nodes.canonical_hash.seed,
                                  emb_dim=cfg.edge_featurization.embed_nodes.emb_dim)

    etype2onehot = gen_relation_onehot(rel2id=rel2id)
    ntype2onehot = gen_relation_onehot(rel2id=ntype2id)

    # Vectorize training set
    gen_vectorized_graphs(indexid2vec=indexid2vec,
                          etype2oh=etype2onehot,
                          ntype2oh=ntype2onehot,
                          split_files=cfg.dataset.train_files,
                          out_dir=os.path.join(cfg.edge_featurization.embed_edges._edge_embeds_dir, "train/"),
                          logger=logger,
                          cfg=cfg,
                          indexid2pres=indexid2pres,
                          )

    # Vectorize validation set
    gen_vectorized_graphs(indexid2vec=indexid2vec,
                          etype2oh=etype2onehot,
                          ntype2oh=ntype2onehot,
                          split_files=cfg.dataset.val_files,
                          out_dir=os.path.join(cfg.edge_featurization.embed_edges._edge_embeds_dir, "val/"),
                          logger=logger,
                          cfg=cfg,
                          indexid2pres=indexid2pres,
                          )

    # Vectorize testing set
    gen_vectorized_graphs(indexid2vec=indexid2vec,
                          etype2oh=etype2onehot,
                          ntype2oh=ntype2onehot,
                          split_files=cfg.dataset.test_files,
                          out_dir=os.path.join(cfg.edge_featurization.embed_edges._edge_embeds_dir, "test/"),
                          logger=logger,
                          cfg=cfg,
                          indexid2pres=indexid2pres,
                          )

if __name__ == '__main__':
    args = get_runtime_required_args()
    cfg = get_yml_cfg(args)

    main(cfg)
