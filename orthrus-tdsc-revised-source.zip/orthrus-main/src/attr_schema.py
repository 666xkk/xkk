"""Canonical attribute schema + missingness abstraction for cross-collector training.

THEIA (Linux) / CADETS (FreeBSD) / CLEARSCOPE (Android) report node attributes
with very different completeness (CADETS has many missing paths, Android apps
lack traditional paths, etc.). This module defines ONE canonical attribute
schema over the three node types so that every collector's nodes map to a
common representation:

    subject : path, cmd_line
    file    : path
    netflow : remote_ip, remote_port

For each node we additionally compute a *presence bitmask* over the four
canonical attributes. The bitmask is emitted as a one-hot channel alongside
the attribute embeddings and fed to the GNN ("missingness channel"), so the
model can condition its reasoning on which evidence actually exists instead
of treating ``"None"`` as a legitimate attribute value. A shared
``__missing__`` token replaces missing values in the word2vec tokenizers so
that absence is represented identically across collectors.

Paper 2: this is the attribute-abstraction layer required for
cross-collector (domain) invariance training.
"""
import hashlib

import numpy as np

# Canonical attributes per node type, shared across all collectors.
NODE_ATTR_SCHEMA = {
    "subject": ["path", "cmd_line"],
    "file": ["path"],
    "netflow": ["remote_ip", "remote_port"],
}

# Canonical bit order of the presence mask (bit i <-> ATTR_INDEX[i]).
ATTR_INDEX = ["path", "cmd_line", "remote_ip", "remote_port"]

# One token for every absent attribute value, so missingness is represented
# identically across collectors instead of as collector-specific strings.
MISSING_TOKEN = "__missing__"
_MISSING_ALIASES = {"none", "null", "nan", "na", "n/a", "unknown", "missing",
                    "''", '""'}


def is_missing(value) -> bool:
    """True iff `value` denotes an absent attribute (None/''/'None'/...)."""
    s = str(value).strip()
    return s == "" or s.lower() in _MISSING_ALIASES


def normalize_missing_tokens(tokens):
    """Map every missing-value token to the shared MISSING_TOKEN."""
    return [MISSING_TOKEN if t.lower() in _MISSING_ALIASES or t in ("''", '""')
            else t for t in tokens]


def canonical_hash_embedding(tokens, dim: int, seed: int = 0):
    """Map canonical tokens to a shared, deterministic feature space.

    Per-collector Word2Vec models use unrelated coordinate systems even when
    they have the same width. Signed feature hashing maps the same token to the
    same coordinate without fitting on any collector and preserves unseen
    tokens during zero-shot evaluation. BLAKE2 is used instead of Python's
    process-randomized ``hash`` so artifacts are reproducible across runs.
    """
    if dim <= 0:
        raise ValueError("embedding dimension must be positive")
    tokens = normalize_missing_tokens([str(token) for token in tokens])
    if not tokens:
        tokens = [MISSING_TOKEN]
    vec = np.zeros(dim, dtype=np.float32)
    prefix = int(seed).to_bytes(8, "little", signed=True)
    for token in tokens:
        digest = hashlib.blake2b(
            prefix + token.casefold().encode("utf-8"), digest_size=16).digest()
        bucket = int.from_bytes(digest[:8], "little") % dim
        sign = 1.0 if digest[8] & 1 else -1.0
        vec[bucket] += sign
    norm = float(np.linalg.norm(vec))
    if norm > 0:
        vec /= norm
    return vec


def attr_presence_bits(node_type: str, **attrs) -> int:
    """Presence bitmask of a node over ATTR_INDEX (bit i = attribute i exists)."""
    bits = 0
    for i, attr in enumerate(ATTR_INDEX):
        if attr in NODE_ATTR_SCHEMA.get(node_type, []):
            if not is_missing(attrs.get(attr)):
                bits |= 1 << i
    return bits


def node_feature_layout(cfg):
    """Canonical node-feature blocks emitted by data_utils for x_src/x_dst.

    Returns ``[(name, dim)]`` in order: attribute embeddings, node-type
    one-hot, presence one-hot. Blocks with dim 0 are omitted. The encoder
    slices the same layout (see OrthrusEncoder attr_dim/type_dim/pres_dim).
    """
    mode = cfg.detection.gnn_training.encoder.node_feature_mode
    assert mode in ("attributes", "structure", "both"), \
        f"Invalid node_feature_mode {mode!r}"
    emb_dim = cfg.edge_featurization.embed_nodes.emb_dim
    ntype = cfg.dataset.num_node_types
    pres = (cfg.edge_featurization.embed_edges.missingness_dim
            if cfg.edge_featurization.embed_edges.add_missingness else 0)

    blocks = []
    if mode in ("attributes", "both"):
        blocks.append(("emb", emb_dim))
    if mode == "structure" or cfg.detection.gnn_training.encoder.use_node_type_in_node_feats:
        blocks.append(("type", ntype))
    # `structure` is the collector-invariant lower bound: node type only.
    # Presence patterns are themselves collector fingerprints, so including
    # the missingness channel here would contradict the invariance claim.
    if pres and mode != "structure":
        blocks.append(("pres", pres))
    return blocks


def msg_disk_layout(cfg):
    """Offsets of the per-event msg columns as written by embed_edges.

    Disk order: src_type, src_emb, edge_type, dst_type, dst_emb,
    [src_pres, dst_pres if add_missingness]. Returns {name: (offset, dim)}.
    """
    emb = cfg.edge_featurization.embed_nodes.emb_dim
    nt = cfg.dataset.num_node_types
    et = cfg.dataset.num_edge_types
    pres = (cfg.edge_featurization.embed_edges.missingness_dim
            if cfg.edge_featurization.embed_edges.add_missingness else 0)
    layout = {}
    off = 0
    for name, dim in [("src_type", nt), ("src_emb", emb), ("edge_type", et),
                      ("dst_type", nt), ("dst_emb", emb),
                      ("src_pres", pres), ("dst_pres", pres)]:
        layout[name] = (off, dim)
        off += dim
    return layout
