"""Domain-invariance components (DANN-style) for cross-collector training.

A domain discriminator classifies the encoder's context-node representations
through a gradient-reversal layer. Minimizing the discriminator while the
reversal flips the gradient into the encoder pushes the shared encoder to
produce features that do NOT reveal the domain (provenance collector, or
training day), so it must rely on universal provenance semantics
(structure + time) instead of collector-specific surface statistics.

Paper 2: the domain-invariance objective behind the cross-collector
transfer story (CADETS/THEIA/CLEARSCOPE attribute-completeness shift).
"""
import torch
import torch.nn as nn
import torch.nn.functional as F


class GradientReversal(torch.autograd.Function):
    """Identity forward; backward multiplies the gradient by -lam."""

    @staticmethod
    def forward(ctx, x, lam=1.0):
        ctx.lam = lam
        return x

    @staticmethod
    def backward(ctx, grad_out):
        return -ctx.lam * grad_out, None


def grad_reverse(x, lam=1.0):
    return GradientReversal.apply(x, lam)


class DomainDiscriminator(nn.Module):
    """MLP over node embeddings -> domain logits.

    ``lam`` scales the reversed gradient flowing back into the encoder
    (the discriminator's own parameters always receive ordinary gradients,
    since the reversal sits between encoder output and discriminator input).

    Returns (loss, accuracy). Accuracy is detached and used as an invariance
    diagnostic: near-chance accuracy on held-out domains is the evidence
    that the encoder no longer encodes the domain.
    """

    def __init__(self, in_dim, hid_dim, num_domains, lam=1.0):
        super().__init__()
        assert num_domains >= 2, "a domain discriminator needs >= 2 domains"
        self.lam = lam
        self.num_domains = num_domains
        self.mlp = nn.Sequential(
            nn.Linear(in_dim, hid_dim),
            nn.ReLU(),
            nn.Linear(hid_dim, num_domains),
        )

    def forward(self, h, domain_id):
        if torch.is_tensor(domain_id):
            labels = domain_id.to(device=h.device, dtype=torch.long).reshape(-1)
            if labels.numel() == 1:
                labels = labels.expand(h.size(0))
            elif labels.numel() != h.size(0):
                raise ValueError(
                    f"domain labels have {labels.numel()} entries for "
                    f"{h.size(0)} embeddings")
        else:
            labels = torch.full((h.size(0),), int(domain_id), dtype=torch.long,
                                device=h.device)
        if labels.numel() and (int(labels.min()) < 0 or
                               int(labels.max()) >= self.num_domains):
            raise ValueError(
                f"domain label outside [0, {self.num_domains - 1}]")
        logits = self.mlp(grad_reverse(h, self.lam))
        loss = F.cross_entropy(logits, labels)
        with torch.no_grad():
            acc = (logits.argmax(dim=1) == labels).float().mean()
        return loss, acc


class MultiHeadDomainDiscriminator(nn.Module):
    """Adversarial heads for independent collector and temporal domains.

    A single DANN label cannot remove both collector-specific acquisition
    artifacts and within-collector day drift.  This module applies one GRL
    discriminator per configured nuisance variable and averages their weighted
    losses.  Each head has its own classifier parameters; only the encoder is
    shared.

    ``domain_sizes`` maps a stable label name (for example ``collector`` or
    ``day``) to its number of classes.  ``labels`` passed to :meth:`forward`
    must contain a scalar or per-embedding tensor for every configured head.
    """

    def __init__(self, in_dim, hid_dim, domain_sizes, lam=1.0,
                 head_weights=None):
        super().__init__()
        domain_sizes = dict(domain_sizes)
        if not domain_sizes:
            raise ValueError("at least one domain head is required")
        self.heads = nn.ModuleDict({
            name: DomainDiscriminator(in_dim, hid_dim, int(size), lam=lam)
            for name, size in domain_sizes.items()
            if int(size) >= 2
        })
        if not self.heads:
            raise ValueError("every domain head has fewer than two classes")
        weights = head_weights or {}
        self.head_weights = {
            name: float(weights.get(name, 1.0)) for name in self.heads
        }
        if any(weight <= 0 for weight in self.head_weights.values()):
            raise ValueError("domain head weights must be positive")

    def forward(self, h, labels):
        if not isinstance(labels, dict):
            if len(self.heads) != 1:
                raise TypeError("multi-head domain labels must be a dict")
            labels = {next(iter(self.heads)): labels}

        missing = set(self.heads) - set(labels)
        if missing:
            raise KeyError(f"missing domain labels for: {sorted(missing)}")

        total = h.sum() * 0.0
        weight_sum = 0.0
        stats = {}
        for name, head in self.heads.items():
            loss, acc = head(h, labels[name])
            weight = self.head_weights[name]
            total = total + weight * loss
            weight_sum += weight
            stats[f"domain_acc_{name}"] = float(acc)
            stats[f"domain_loss_{name}"] = float(loss.detach())
        return total / weight_sum, stats
