from src.provnet_utils import *
from src.config import *
import torch
import torch.nn as nn


class Orthrus(nn.Module):
    def __init__(self,
            encoder: nn.Module,
            decoders: list[nn.Module],
            num_nodes: int,
            in_dim: int,
            out_dim: int,
            use_contrastive_learning: bool,
            device,
            graph_reindexer,
            link_head: nn.Module = None,
            time_head: nn.Module = None,
            base_type_loss_weight: float = 1.0,
            masked_type_loss_weight: float = 0.0,
            link_loss_weight: float = 0.0,
            time_loss_weight: float = 0.0,
            domain_loss_weight: float = 0.0,   # Paper 2: DANN invariance
        ):
        super(Orthrus, self).__init__()

        self.encoder = encoder
        self.decoders = nn.ModuleList(decoders)
        self.use_contrastive_learning = use_contrastive_learning
        self.graph_reindexer = graph_reindexer

        # --- Paper 1: masked context-event recovery objectives ---
        self.link_head = link_head
        self.time_head = time_head
        self.base_type_loss_weight = base_type_loss_weight
        self.masked_type_loss_weight = masked_type_loss_weight
        self.link_loss_weight = link_loss_weight
        self.time_loss_weight = time_loss_weight
        self.domain_loss_weight = domain_loss_weight
        self.last_loss_parts = {}
        # ----------------------------------------------------------

        self.last_h_storage, self.last_h_non_empty_nodes = None, None
        if self.use_contrastive_learning:
            self.last_h_storage = torch.empty((num_nodes, out_dim), device=device)
            self.last_h_non_empty_nodes = torch.tensor([], dtype=torch.long, device=device)

    def forward(self, batch, full_data, inference=False, domain_id=None,
                domain_labels=None):
        train_mode = not inference
        x = (batch.x_src, batch.x_dst)
        edge_index = batch.edge_index

        with torch.set_grad_enabled(train_mode):
            h_src, h_dst, recovery, domain_loss = self.encoder(
                edge_index=edge_index,
                t=batch.t,
                x=x,
                msg=batch.msg,
                edge_feats=batch.edge_feats if hasattr(batch, "edge_feats") else None,
                full_data=full_data,
                inference=inference,
                edge_types=batch.edge_type,
                domain_id=domain_id,
                domain_labels=domain_labels,
            )

            if x[0].shape[0] != edge_index.shape[1]:
                x = (batch.x_src[edge_index[0]], batch.x_dst[edge_index[1]])

            if self.use_contrastive_learning:
                involved_nodes = edge_index.flatten()
                self.last_h_storage[involved_nodes] = torch.cat([h_src, h_dst]).detach()
                self.last_h_non_empty_nodes = torch.cat([involved_nodes, self.last_h_non_empty_nodes]).unique()

            loss_or_scores = (torch.zeros(1) if train_mode else
                              torch.zeros(edge_index.shape[1], dtype=torch.float)).to(h_src.device)

            # ---- base objective: predict the type of every current event ----
            base_loss = torch.zeros(1, device=h_src.device).squeeze()
            for decoder in self.decoders:
                loss = decoder(
                    h_src=h_src,
                    h_dst=h_dst,
                    x=x,
                    edge_index=edge_index,
                    edge_type=batch.edge_type,
                    inference=inference,
                    last_h_storage=self.last_h_storage,
                    last_h_non_empty_nodes=self.last_h_non_empty_nodes,
                )
                if train_mode:
                    base_loss = base_loss + loss
                else:
                    loss_or_scores = loss_or_scores + loss

            parts = {}
            if train_mode:
                if self.base_type_loss_weight > 0:
                    loss_or_scores = loss_or_scores + self.base_type_loss_weight * base_loss
                    parts["type_all"] = float(base_loss.detach())

                # ---- masked context-event recovery ----
                if recovery is not None and recovery["masked_eids"].numel() > 0:
                    h_u, h_v = recovery["h_u"], recovery["h_v"]

                    if self.masked_type_loss_weight > 0:
                        masked_type_loss = torch.zeros(1, device=h_u.device).squeeze()
                        for decoder in self.decoders:
                            masked_type_loss = masked_type_loss + decoder(
                                h_src=h_u,
                                h_dst=h_v,
                                x=None,
                                edge_index=None,
                                edge_type=recovery["edge_type"],
                                inference=False,
                                last_h_storage=None,
                                last_h_non_empty_nodes=None,
                            )
                        loss_or_scores = loss_or_scores + self.masked_type_loss_weight * masked_type_loss
                        parts["type_masked"] = float(masked_type_loss.detach())

                    if self.link_loss_weight > 0 and self.link_head is not None and recovery["h_neg"] is not None:
                        link_loss = self.link_head(
                            recovery["link_h_u"], recovery["link_h_v"],
                            recovery["h_neg"], recovery["neg_valid"])
                        loss_or_scores = loss_or_scores + self.link_loss_weight * link_loss
                        parts["link"] = float(link_loss.detach())
                        parts["link_acc"] = getattr(self.link_head, "last_acc", float("nan"))

                    if self.time_loss_weight > 0 and self.time_head is not None:
                        time_loss = self.time_head(h_u, h_v, recovery["dt"], recovery["dt_valid"])
                        loss_or_scores = loss_or_scores + self.time_loss_weight * time_loss
                        parts["time"] = float(time_loss.detach())

                # ---- Paper 2: domain-invariance loss (DANN) ----
                if domain_loss is not None and self.domain_loss_weight > 0:
                    loss_or_scores = loss_or_scores + self.domain_loss_weight * domain_loss
                    parts["domain"] = float(domain_loss.detach())
                for k, v in getattr(self.encoder, "_last_domain_stats", {}).items():
                    parts[k] = v

                self.last_loss_parts = parts

            return loss_or_scores
