import os
import re

import pickle
import torch
from torch_geometric.data import Data, TemporalData
from torch_geometric.loader import TemporalDataLoader

from src.encoders import OrthrusEncoder
from src.attr_schema import node_feature_layout, msg_disk_layout


def load_all_datasets(cfg):
    train_data = load_data_set(cfg, path=cfg.edge_featurization.embed_edges._edge_embeds_dir, split="train")
    val_data = load_data_set(cfg, path=cfg.edge_featurization.embed_edges._edge_embeds_dir, split="val")
    test_data = load_data_set(cfg, path=cfg.edge_featurization.embed_edges._edge_embeds_dir, split="test")

    full_data, max_node = _concat_full_data([train_data, val_data, test_data],
                                            cfg.dataset.name)

    return train_data, val_data, test_data, full_data, max_node


def load_all_datasets_multi(cfg, domain_names):
    """Load several collector datasets for joint multi-domain training.

    Each domain gets its own cfg clone (own dataset block and artifact
    paths) and its own node space; only the model parameters are shared.
    """
    per_domain = {}
    for name in domain_names:
        c2 = clone_cfg_for_dataset(cfg, name)
        train_data = load_data_set(c2, path=c2.edge_featurization.embed_edges._edge_embeds_dir, split="train")
        val_data = load_data_set(c2, path=c2.edge_featurization.embed_edges._edge_embeds_dir, split="val")
        test_data = load_data_set(c2, path=c2.edge_featurization.embed_edges._edge_embeds_dir, split="test")
        full_data, max_node = _concat_full_data([train_data, val_data, test_data], name)
        per_domain[name] = {"train": train_data, "val": val_data,
                            "test": test_data, "full": full_data,
                            "max_node": max_node, "cfg": c2}
    return per_domain


def clone_cfg_for_dataset(cfg, name):
    """Clone `cfg` with the dataset block of `name` and recomputed paths."""
    from yacs.config import CfgNode as CN
    from src.config import DATASET_DEFAULT_CONFIG, set_task_paths
    c = cfg.clone()
    c.defrost()
    c.dataset = CN()
    for k, v in DATASET_DEFAULT_CONFIG[name].items():
        c.dataset[k] = v
    set_task_paths(c)
    return c


def _concat_full_data(datasets, dataset_name):
    all_msg, all_t, all_edge_types = [], [], []
    all_src, all_dst = [], []
    max_node = 0
    train_event_count = 0
    for split_idx, dataset in enumerate(datasets):
        for data in dataset:
            all_msg.append(data.msg)
            all_t.append(data.t)
            all_edge_types.append(data.edge_type)
            all_src.append(data.src)
            all_dst.append(data.dst)
            max_node = max(max_node, torch.cat([data.src, data.dst]).max().item())
            if split_idx == 0:
                train_event_count += int(data.src.numel())

    all_msg = torch.cat(all_msg)
    all_t = torch.cat(all_t)
    all_edge_types = torch.cat(all_edge_types)
    # [Paper 1] src/dst are required by the masked-context recovery targets
    full_data = Data(msg=all_msg, t=all_t, edge_type=all_edge_types,
                     src=torch.cat(all_src), dst=torch.cat(all_dst))
    # The bridge curriculum may inspect both temporal directions, but only
    # inside the training prefix.  Keeping this boundary with the concatenated
    # stream prevents validation/test events from influencing which training
    # events are masked.
    full_data.train_event_count = train_event_count
    max_node = max_node + 1
    print(f"Max node in {dataset_name}: {max_node}")

    return full_data, max_node

def load_data_set(cfg, path: str, split: str) -> list[TemporalData]:
    """
    Returns a list of time window graphs for a given `split` (train/val/test set).
    """
    # In case we run unit tests, only some edges in the train set are present
    if cfg._test_mode:
        split = "train"

    data_list = []
    for f in sorted(os.listdir(os.path.join(path, split))):
        filepath = os.path.join(path, split, f)
        data = torch.load(filepath).to("cpu")
        # [Paper 2] the file name embeds the day date
        # ("2018-04-08_00-00-00~..."); expose it as the day domain label for
        # day-level domain-invariance training.
        m = re.search(r"(\d{4})-(\d{2})-(\d{2})", f)
        if m:
            # tensor (shape (1,)) 而非 int：PyG TemporalData 切片时会遍历属性
            # 调 .size(0)，int 会崩。
            data.day_id = torch.tensor([int(m.group(1) + m.group(2) + m.group(3))],
                                       dtype=torch.long)
        data_list.append(data)

    if cfg.edge_featurization.embed_nodes.used_method.strip() == "only_type":
        data_list = extract_msg_node_type_only(data_list, cfg)
    else:
        data_list = extract_msg_from_data(data_list, cfg)
    return data_list

def extract_msg_node_type_only(data_set: list[TemporalData], cfg) -> list[TemporalData]:
    """
    Initializes the attributes of a `Data` object based on the `msg`
    computed in previous tasks.
    """
    node_type_dim = cfg.dataset.num_node_types
    edge_type_dim = cfg.dataset.num_edge_types

    msg_len = data_set[0].msg.shape[1]
    expected_msg_len = (node_type_dim * 2) + edge_type_dim
    if msg_len != expected_msg_len:
        raise ValueError(f"The msg has an invalid shape, found {msg_len} instead of {expected_msg_len}")

    field_to_size = [
        ("src_type", node_type_dim),
        ("edge_type", edge_type_dim),
        ("dst_type", node_type_dim),
    ]
    for g in data_set:
        fields = {}
        idx = 0
        for field, size in field_to_size:
            fields[field] = g.msg[:, idx: idx + size]
            idx += size

        x_src = fields["src_type"]
        x_dst = fields["dst_type"]

        # If we want to predict the edge type, we remove the edge type from the message
        if "predict_edge_type" in cfg.detection.gnn_training.decoder.used_methods:
            msg = torch.cat([x_src, x_dst], dim=-1)
        else:
            msg = torch.cat([x_src, x_dst, fields["edge_type"]], dim=-1)
            
        edge_feats = build_edge_feats(fields, msg, cfg)

        g.x_src = x_src
        g.x_dst = x_dst
        g.msg = msg
        g.edge_type = fields["edge_type"]
        g.edge_feats = edge_feats
        g.edge_index = torch.stack([g.src, g.dst])

    return data_set

def extract_msg_from_data(data_set: list[TemporalData], cfg) -> list[TemporalData]:
    """
    Initializes the attributes of a `Data` object based on the `msg`
    computed in previous tasks.

    The per-event msg on disk is laid out as
    [src_type, src_emb, edge_type, dst_type, dst_emb, (src_pres, dst_pres)]
    (see src.attr_schema.msg_disk_layout); the node-feature blocks exposed to
    the GNN are defined by node_feature_layout (attributes / structure / both,
    plus the missingness channel).
    """
    layout = msg_disk_layout(cfg)
    expected_msg_len = sum(dim for _, dim in layout.values())
    msg_len = data_set[0].msg.shape[1]
    if msg_len != expected_msg_len:
        raise ValueError(
            f"The msg has an invalid shape, found {msg_len} instead of "
            f"{expected_msg_len}. If you changed edge_featurization.embed_edges"
            f".add_missingness, rebuild the edge embeds (the artifact hash "
            f"should have changed automatically).")

    node_blocks = node_feature_layout(cfg)

    def build_x(fields, side):
        src_map = {"emb": f"src_emb", "type": f"src_type", "pres": f"src_pres"}
        dst_map = {"emb": f"dst_emb", "type": f"dst_type", "pres": f"dst_pres"}
        m = src_map if side == "src" else dst_map
        return torch.cat([fields[m[name]] for name, dim in node_blocks if dim > 0],
                         dim=-1)

    for g in data_set:
        fields = {}
        for name, (off, dim) in layout.items():
            fields[name] = g.msg[:, off: off + dim]

        x_src = build_x(fields, "src")
        x_dst = build_x(fields, "dst")

        # If we want to predict the edge type, we remove the edge type from the message
        if "predict_edge_type" in cfg.detection.gnn_training.decoder.used_methods:
            msg = torch.cat([x_src, x_dst], dim=-1)
        else:
            msg = torch.cat([x_src, x_dst, fields["edge_type"]], dim=-1)

        edge_feats = build_edge_feats(fields, msg, cfg)

        g.x_src = x_src
        g.x_dst = x_dst
        g.msg = msg
        g.edge_type = fields["edge_type"]
        g.edge_feats = edge_feats
        g.edge_index = torch.stack([g.src, g.dst])

    return data_set

def build_edge_feats(fields, msg, cfg):
    edge_features = list(map(lambda x: x.strip(), cfg.detection.gnn_training.encoder.edge_features.split(",")))
    edge_feats = []
    if "edge_type" in edge_features:
        edge_feats.append(fields["edge_type"])
    if "msg" in edge_features:
        edge_feats.append(msg)
    edge_feats = torch.cat(edge_feats, dim=-1) if len(edge_feats) > 0 else None
    return edge_feats

def custom_temporal_data_loader(data: TemporalData, batch_size: int, *args, **kwargs):
    """
    A simple `TemporalDataLoader` which also update the edge_index with the
    sampled edges of size `batch_size`. By default, only attributes of shape (E, d)
    are updated, `edge_index` is thus not updated automatically.
    """
    loader = TemporalDataLoader(data, batch_size=batch_size, *args, **kwargs)
    for batch in loader:
        batch.edge_index = torch.stack([batch.src, batch.dst])
        yield batch

def temporal_data_to_data(data: TemporalData) -> Data:
    """
    NeighborLoader requires a `Data` object.
    We need to convert `TemporalData` to `Data` before using it.
    """
    return Data(num_nodes=data.x_src.shape[0], **{k: v for k, v in data._store.items()})

class GraphReindexer:
    """
    Simply transforms an edge_index and its src/dst node features of shape (E, d)
    to a reindexed edge_index with node IDs starting from 0 and src/dst node features of shape
    (max_num_node + 1, d).
    This reindexing is essential for the graph to be computed by a standard GNN model with PyG.
    """
    def __init__(self, num_nodes, device):
        self.num_nodes = num_nodes
        self.device = device
        
        self.assoc = None
        self.x_src_cache = None
        self.x_dst_cache = None

    def node_features_reshape(self, edge_index, x_src, x_dst, max_num_node=None):
        """
        Converts node features in shape (E, d) to a shape (N, d).
        Returns x as a tuple (x_src, x_dst).
        """
        if self.x_src_cache is None:
            self.x_src_cache = torch.zeros((self.num_nodes, x_src.shape[1]), device=self.device)
            self.x_dst_cache = torch.zeros((self.num_nodes, x_src.shape[1]), device=self.device)
            
        max_num_node = max_num_node + 1 if max_num_node else edge_index.max() + 1
        
        # To avoid storing gradients from all nodes, we detach() BEFORE caching. If we detach()
        # after storing, we loose the gradient for all operations happening before the reindexing.
        self.x_src_cache = self.x_src_cache.detach()
        self.x_dst_cache = self.x_dst_cache.detach()
        
        self.x_src_cache[edge_index[0, :]] = x_src
        self.x_dst_cache[edge_index[1, :]] = x_dst
        x = (self.x_src_cache[:max_num_node, :], self.x_dst_cache[:max_num_node, :])
        
        return x
    
    def reindex_graph(self, data):
        """
        Reindexes edge_index from 0 + reshapes node features.
        The old edge_index is stored in `data.original_edge_index`
        """
        data = data.clone()
        data.original_edge_index = data.edge_index
        (data.x_src, data.x_dst), data.edge_index = self._reindex_graph(data.edge_index, data.x_src, data.x_dst)
        return data
    
    def _reindex_graph(self, edge_index, x_src, x_dst):
        """
        Reindexes edge_index with indices starting from 0.
        Also reshapes the node features.
        """
        if self.assoc is None:
            self.assoc = torch.empty((self.num_nodes, ), dtype=torch.long, device=self.device)

        n_id = edge_index.unique()
        self.assoc[n_id] = torch.arange(n_id.size(0), device=edge_index.device)
        edge_index = self.assoc[edge_index]
        
        # Associates each feature vector to each reindexed node ID
        x = self.node_features_reshape(edge_index, x_src, x_dst)
        
        return x, edge_index

def save_model(model, path: str, neigh_loader: bool=True):
    os.makedirs(path, exist_ok=True)
    torch.save(model.state_dict(), os.path.join(path, "state_dict.pkl"), pickle_protocol=pickle.HIGHEST_PROTOCOL)

    if neigh_loader and isinstance(model.encoder, OrthrusEncoder):
        ctxs = model.encoder.ctxs
        if len(ctxs) == 1:
            torch.save(ctxs[0].neighbor_loader, os.path.join(path, "neighbor_loader.pkl"), pickle_protocol=pickle.HIGHEST_PROTOCOL)
            torch.save(ctxs[0].stream_tracker.state_dict(),
                       os.path.join(path, "stream_tracker.pkl"), pickle_protocol=pickle.HIGHEST_PROTOCOL)
        else:
            # Multi-domain: one dict of {domain_id: (loader, tracker_state)}.
            torch.save({d: (c.neighbor_loader, c.stream_tracker.state_dict())
                        for d, c in ctxs.items()},
                       os.path.join(path, "neighbor_loader.pkl"), pickle_protocol=pickle.HIGHEST_PROTOCOL)


def load_model(model, path: str, neigh_loader: bool=True, domain_id=None):
    # strict=False: 训练期独有的头（如 domain_disc DANN 判别器）推理模型不重建，
    # 加载时跳过这些 key（与 load_pretrained_weights / --from_weights 一致）。
    target_device = (model.encoder.device
                     if isinstance(model.encoder, OrthrusEncoder) else "cpu")
    model.load_state_dict(torch.load(
        os.path.join(path, "state_dict.pkl"), map_location=target_device),
        strict=False)

    if neigh_loader and isinstance(model.encoder, OrthrusEncoder):
        loader = torch.load(os.path.join(path, "neighbor_loader.pkl"),
                            map_location=target_device)
        if isinstance(loader, dict) and len(model.encoder.ctxs) == 1:
            if domain_id is None or domain_id not in loader:
                raise ValueError(
                    "multi-domain checkpoint needs a valid domain_id when "
                    "loaded into a single-domain evaluation model")
            selected_loader, tracker_state = loader[domain_id]
            model.encoder.ctxs[0].neighbor_loader = selected_loader
            model.encoder.ctxs[0].stream_tracker.load_state_dict(tracker_state)
        else:
            model.encoder.neighbor_loader = loader
        tracker_path = os.path.join(path, "stream_tracker.pkl")
        if not isinstance(loader, dict) and os.path.exists(tracker_path):
            model.encoder.stream_tracker.load_state_dict(
                torch.load(tracker_path, map_location=target_device))

    return model
