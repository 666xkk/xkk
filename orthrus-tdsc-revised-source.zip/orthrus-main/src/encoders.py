import torch
import torch.nn as nn
from torch_geometric.nn import SAGEConv, GATConv, TransformerConv
from torch_geometric.utils import scatter

from src.masking import StreamTimeTracker, compute_event_endpoint_gaps
from src.temporal import LastNeighborLoader


class GraphTransformer(nn.Module):
    def __init__(self, in_dim, hid_dim, out_dim, edge_dim, dropout, activation, num_heads):
        super(GraphTransformer, self).__init__()
        self.conv = TransformerConv(in_dim, hid_dim, heads=num_heads, dropout=dropout, edge_dim=edge_dim)
        self.conv2 = TransformerConv(hid_dim * num_heads, out_dim, heads=1, concat=False, dropout=dropout, edge_dim=edge_dim)
        self.dropout = nn.Dropout(dropout)
        self.activation = activation

    def forward(self, x, edge_index, edge_feats=None, **kwargs):
        x = self.activation(self.conv(x, edge_index, edge_feats))
        x = self.dropout(x)
        x = self.conv2(x, edge_index, edge_feats)
        return x


class GATEncoder(nn.Module):
    def __init__(self, in_dim, hid_dim, out_dim, edge_dim, dropout, activation, num_heads):
        super(GATEncoder, self).__init__()
        self.conv = GATConv(in_dim, hid_dim, heads=num_heads, dropout=dropout, edge_dim=edge_dim)
        self.conv2 = GATConv(hid_dim * num_heads, out_dim, heads=1, concat=False, dropout=dropout, edge_dim=edge_dim)
        self.dropout = nn.Dropout(dropout)
        self.activation = activation

    def forward(self, x, edge_index, edge_feats=None, **kwargs):
        x = self.activation(self.conv(x, edge_index, edge_feats))
        x = self.dropout(x)
        x = self.conv2(x, edge_index, edge_feats)
        return x


class SAGEEncoder(nn.Module):
    """Edge-aware GraphSAGE.

    Vanilla SAGEConv cannot consume edge features. To keep the backbone
    ablation fair, edge features are summarized per TARGET node and added to
    the initial node features before two SAGE layers.
    """

    def __init__(self, in_dim, hid_dim, out_dim, edge_dim=None, dropout=0.0, activation=None, num_heads=None):
        super(SAGEEncoder, self).__init__()
        self.conv = SAGEConv(in_dim, hid_dim)
        self.conv2 = SAGEConv(hid_dim, out_dim)
        self.dropout = nn.Dropout(dropout)
        self.activation = activation if activation is not None else nn.ReLU()
        self.edge_proj = nn.Linear(edge_dim, in_dim) if edge_dim else None

    def forward(self, x, edge_index, edge_feats=None, **kwargs):
        if self.edge_proj is not None and edge_feats is not None and edge_index.numel() > 0:
            edge_msg = scatter(edge_feats, edge_index[1], dim=0, dim_size=x.size(0), reduce="mean")
            x = x + self.edge_proj(edge_msg)
        x = self.activation(self.conv(x, edge_index))
        x = self.dropout(x)
        x = self.conv2(x, edge_index)
        return x


class LinearEncoder(nn.Module):
    """Graph-agnostic linear backbone (VELOX-style lower bound)."""

    def __init__(self, in_dim, hid_dim=None, out_dim=None, edge_dim=None, dropout=0.0, activation=None, num_heads=None):
        super(LinearEncoder, self).__init__()
        self.lin = nn.Linear(in_dim, out_dim)

    def forward(self, x, edge_index, edge_feats=None, **kwargs):
        return self.lin(x)


class DomainContext:
    """Per-domain streaming state: node space, neighbor window, time tracker.

    The encoder PARAMETERS are shared across domains (collectors / days);
    only these buffers differ, because each domain has its own node ids and
    its own event stream. Domain 0 is the primary/single-domain context.

    Paper 2: this is what makes joint multi-collector training possible with
    a single shared encoder under domain-invariance objectives.
    """

    def __init__(self, num_nodes, device, neighbor_size,
                 neighbor_loader=None, stream_tracker=None, reindexer=None):
        # Local import: data_utils imports this module at its top, and a
        # module-level import here would create a cycle.
        from src.data_utils import GraphReindexer
        self.num_nodes = num_nodes
        self.neighbor_loader = (neighbor_loader if neighbor_loader is not None
                                else LastNeighborLoader(num_nodes, size=neighbor_size, device=device))
        self.stream_tracker = (stream_tracker if stream_tracker is not None
                               else StreamTimeTracker(num_nodes=num_nodes, device=device))
        self.assoc = torch.empty(num_nodes, dtype=torch.long, device=device)
        self.reindexer = (reindexer if reindexer is not None
                          else GraphReindexer(num_nodes=num_nodes, device=device))


class OrthrusEncoder(nn.Module):
    def __init__(
        self,
        encoder,
        neighbor_loader,
        in_dim,
        temporal_dim,
        use_node_feats_in_gnn,
        graph_reindexer,
        edge_features,
        device,
        num_nodes,
        edge_dim,
        use_time_features=False,
        masker=None,
        link_negatives=5,
        # --- Paper 2: cross-collector invariance + bridge prior ---
        domain_ctxs=None,        # dict[int, DomainContext]; None -> single ctx 0
        domain_disc=None,        # DomainDiscriminator or None
        attr_dropout=0.0,        # P(blank attributes + presence) per batch node
        attr_dim=0,              # width of the attribute-embedding block of x
        type_dim=0,              # width of the node-type block of x
        pres_dim=0,              # width of the presence (missingness) block
        num_edge_types=None,     # for (src,dst,type) leak diagnostics
        bridge_strength=0.0,     # >0 enables the bridge sampling prior
        feat_gen=None,           # RNG for attribute dropout (determinism)
        track_triple_dups=False, # count duplicated (src,dst,type) context entries
        mask_unit="unordered_pair",
    ):
        super(OrthrusEncoder, self).__init__()
        self.encoder = encoder
        self.device = device
        self.num_nodes = num_nodes

        if domain_ctxs is None:
            domain_ctxs = {
                0: DomainContext(num_nodes=num_nodes, device=device,
                                 neighbor_size=neighbor_loader.size,
                                 neighbor_loader=neighbor_loader,
                                 reindexer=graph_reindexer),
            }
        self.ctxs = domain_ctxs

        self.edge_features = edge_features
        self.use_node_feats_in_gnn = use_node_feats_in_gnn
        if self.use_node_feats_in_gnn:
            self.src_linear = nn.Linear(in_dim, temporal_dim)
            self.dst_linear = nn.Linear(in_dim, temporal_dim)

        self.graph_reindexer = graph_reindexer   # primary ctx (compat)

        # --- Paper 1: context-event masked modeling ---
        self.masker = masker
        self.link_negatives = link_negatives
        self.use_time_features = use_time_features
        self._mask_lookup = None          # transient bool tensor, per forward

        # --- Paper 2: bridge prior / leak diagnostics ---
        self.bridge_strength = bridge_strength if masker is not None else 0.0
        self.use_bridge = self.masker is not None and self.masker.bridge_strength > 0.0
        self.num_edge_types = num_edge_types
        self.track_triple_dups = track_triple_dups
        if mask_unit not in ("entry", "directed_typed", "unordered_pair"):
            raise ValueError(f"invalid mask unit: {mask_unit}")
        self.mask_unit = mask_unit
        self._gap_cache = {}             # (id(full_data), train scope) -> gaps

        # --- Paper 2: attribute abstraction + domain invariance ---
        self.domain_disc = domain_disc
        self.attr_dropout = attr_dropout
        self.attr_dim = attr_dim
        self.type_dim = type_dim
        self.pres_dim = pres_dim
        self.attr_mask_token = (nn.Parameter(torch.zeros(attr_dim))
                                if (attr_dropout > 0.0 and attr_dim > 0) else None)
        self.feat_gen = feat_gen if feat_gen is not None else torch.Generator(device=device)
        self._last_domain_stats = {}

        # exposed for tests / debugging
        self.last_all_e_id = None
        self.last_visible_e_id = None

    # --------------------------------------------------- domain ctx plumbing
    @property
    def neighbor_loader(self):
        return self.ctxs[0].neighbor_loader

    @neighbor_loader.setter
    def neighbor_loader(self, value):
        if isinstance(value, dict):   # multi-domain save format
            for d, (loader, tracker_sd) in value.items():
                self.ctxs[d].neighbor_loader = loader
                self.ctxs[d].stream_tracker.load_state_dict(tracker_sd)
        else:
            self.ctxs[0].neighbor_loader = value

    @property
    def stream_tracker(self):
        return self.ctxs[0].stream_tracker

    @property
    def assoc(self):
        return self.ctxs[0].assoc

    # ---------------------------------------------------------------- helpers
    def _ensure_lookup_capacity(self, needed):
        if self._mask_lookup is not None and self._mask_lookup.numel() >= needed:
            return
        cap = needed if self._mask_lookup is None else self._mask_lookup.numel()
        while cap < needed:
            cap *= 2
        self._mask_lookup = torch.zeros(max(cap, 1), dtype=torch.bool, device=self.device)

    def _event_gaps(self, full_data):
        """Lazy offline prev/next endpoint gaps of the full stream (bridge prior).

        Cached per full_data object: the tensors are indexed by global event
        id, which is exactly the neighbor loader's cur_e_id ordering.
        """
        total = int(full_data.src.numel())
        scope_end = int(getattr(full_data, "train_event_count", total))
        if not 0 <= scope_end <= total:
            raise ValueError(
                f"invalid train_event_count={scope_end} for {total} events")
        key = (id(full_data), scope_end)
        if key in self._gap_cache:
            return self._gap_cache[key]
        prev_dt, prev_valid, next_dt, next_valid = compute_event_endpoint_gaps(
            full_data.src[:scope_end].cpu(), full_data.dst[:scope_end].cpu(),
            full_data.t[:scope_end].cpu())
        if scope_end < total:
            pad = total - scope_end
            prev_dt = torch.cat([prev_dt, torch.zeros(pad, dtype=prev_dt.dtype)])
            next_dt = torch.cat([next_dt, torch.zeros(pad, dtype=next_dt.dtype)])
            prev_valid = torch.cat([prev_valid, torch.zeros(pad, dtype=torch.bool)])
            next_valid = torch.cat([next_valid, torch.zeros(pad, dtype=torch.bool)])
        self._gap_cache[key] = (prev_dt, prev_valid, next_dt, next_valid)
        return self._gap_cache[key]

    def _apply_attr_dropout(self, x_src, x_dst, edge_index):
        """Blank the attribute block + presence channel of a random subset of
        batch nodes (training only).

        Simulates collectors that report fewer attributes (e.g. CADETS
        path=None), forcing the model to rely on structure + time. The
        presence one-hot is zeroed together with the attributes so the model
        cannot trust "attribute present" flags either.
        """
        x_src, x_dst = x_src.clone(), x_dst.clone()
        rows = edge_index.flatten().unique()
        if rows.numel() == 0:
            return x_src, x_dst
        drop = (torch.rand(rows.numel(), device=self.device,
                           generator=self.feat_gen) < self.attr_dropout)
        rows_drop = rows[drop]
        self._last_domain_stats["attr_dropout_rate"] = float(drop.float().mean())
        self._last_domain_stats["attr_dropout_nodes"] = int(rows_drop.numel())
        # Use one node-level draw for both endpoint roles. Independent source
        # and destination masks let a repeated node reveal its attributes via
        # the other role and do not model collector-level missingness.
        for xx in (x_src, x_dst):
            if rows_drop.numel() == 0:
                continue
            if self.attr_dim > 0 and self.attr_mask_token is not None:
                xx[rows_drop, :self.attr_dim] = self.attr_mask_token
            if self.pres_dim > 0:
                off = self.attr_dim + self.type_dim
                xx[rows_drop, off:off + self.pres_dim] = 0.0
        return x_src, x_dst

    def _sample_negatives(self, visible_edge_index, u_local, v_local, num_nodes):
        """Filtered uniform negatives for (u, v) pairs.
        Excluded: the true destination v, u itself, and any node adjacent to u
        in the VISIBLE context graph (either direction) -> no false negatives.
        Returns (neg_local [m, K], neg_valid [m, K])."""
        m = u_local.numel()
        K = self.link_negatives
        if m == 0 or K <= 0 or num_nodes < 3:
            return None, None
        K = min(K, num_nodes - 2)
        cand = torch.randint(0, num_nodes, (m, K), device=self.device)
        cand = torch.where(cand == u_local.unsqueeze(1), (cand + 1) % num_nodes, cand)

        if visible_edge_index.numel() > 0:
            a = visible_edge_index[0].long()
            b = visible_edge_index[1].long()
            keys_ab = torch.sort(a * num_nodes + b).values
            keys_ba = torch.sort(b * num_nodes + a).values
            q = u_local.unsqueeze(1) * num_nodes + cand
            adjacent = self._contains(keys_ab, q) | self._contains(keys_ba, q)
        else:
            adjacent = torch.zeros_like(cand, dtype=torch.bool)

        neg_valid = (~adjacent) & (cand != v_local.unsqueeze(1))
        return cand, neg_valid

    @staticmethod
    def _contains(sorted_keys, query):
        if sorted_keys.numel() == 0:
            return torch.zeros_like(query, dtype=torch.bool)
        idx = torch.searchsorted(sorted_keys, query).clamp(max=sorted_keys.numel() - 1)
        return sorted_keys[idx] == query

    # ---------------------------------------------------------------- forward
    def forward(self, edge_index, t, msg, x, full_data, inference=False,
                edge_types=None, domain_id=None, domain_labels=None, **kwargs):
        src, dst = edge_index
        x_src, x_dst = x
        batch_edge_index = edge_index.clone()

        # domain_id selects the streaming context in multi-domain runs and
        # doubles as the discriminator label (day ordinal in single-domain
        # day-invariance runs, where it does NOT select a context).
        ctx = self.ctxs[domain_id] if (domain_id is not None and domain_id in self.ctxs) \
            else self.ctxs[0]
        num_nodes = ctx.num_nodes

        # 1) temporal context
        n_id = torch.cat([src, dst]).unique()
        n_id, ctx_edge_index, e_id = ctx.neighbor_loader(n_id)
        ctx.assoc[n_id] = torch.arange(n_id.size(0), device=self.device)
        self.last_all_e_id = e_id

        # 2) leak-tight ARC-GROUP masking (v2): sample unordered pairs {u,v}
        #    and remove ALL their events (both directions) from THIS forward.
        recovery = None
        masked_eids = dt_m = dt_valid_m = None
        self._last_mask_stats = {}
        self._last_domain_stats = {}
        if self.masker is not None and not inference and e_id.numel() > 0:
            e_id_cpu = e_id.cpu()
            u = full_data.src[e_id_cpu].to(self.device).long()
            v = full_data.dst[e_id_cpu].to(self.device).long()
            lo = torch.minimum(u, v)
            hi = torch.maximum(u, v)
            unordered_key = lo * num_nodes + hi
            # Directed (src,dst,type) key supports the intermediate grouping
            # ablation and leak diagnostics for every unit.
            triple_key = None
            if ((self.track_triple_dups or self.mask_unit == "directed_typed")
                    and self.num_edge_types is not None):
                et_idx = full_data.edge_type[e_id_cpu].to(self.device).argmax(dim=-1).long()
                triple_key = (u * num_nodes + v) * self.num_edge_types + et_idx
            if self.mask_unit == "entry":
                group_key = torch.arange(e_id.numel(), device=self.device)
            elif self.mask_unit == "directed_typed":
                if triple_key is None:
                    raise RuntimeError("directed_typed masking needs edge types")
                group_key = triple_key
            else:
                group_key = unordered_key
            bridge_kwargs = {}
            if self.use_bridge:
                prev_dt, prev_v, next_dt, next_v = self._event_gaps(full_data)
                bridge_kwargs = dict(
                    bridge_prev=prev_dt[e_id_cpu].to(self.device),
                    bridge_prev_valid=prev_v[e_id_cpu].to(self.device),
                    bridge_next=next_dt[e_id_cpu].to(self.device),
                    bridge_next_valid=next_v[e_id_cpu].to(self.device),
                )
            out = self.masker.sample(e_id, group_key,
                                     ctx.stream_tracker.event_dt,
                                     ctx.stream_tracker.event_dt_valid,
                                     triple_key=triple_key, **bridge_kwargs)
            keep = out["keep"]
            if not bool(keep.all()):
                ctx_edge_index = ctx_edge_index[:, keep]
                e_id = e_id[keep]
            if out["masked_eids"].numel() > 0:
                masked_eids = out["masked_eids"]
                masked_group_rep_eids = out["masked_group_rep_eids"]
                dt_m, dt_valid_m = out["dt"], out["dt_valid"]
                # Keep arc-group count separate from event-target count. A selected
                # unordered pair may contain multiple historical events, so
                # masked_eids.numel() is NOT the number of masked groups.
                selected_groups = int(out["masked_group_rep_eids"].numel())
                selected_events = int(masked_eids.numel())
                self._last_mask_stats = {
                    "n_groups_masked": selected_groups,
                    "n_events_masked": selected_events,
                    "events_per_masked_group": float(selected_events / max(selected_groups, 1)),
                    "frac_groups_with_dups": float((out["group_size"] > 1).float().mean()),
                }
            for k, v in out.get("stats", {}).items():
                self._last_mask_stats[k] = v
        self.last_visible_e_id = e_id

        # 3) node features
        x_src, x_dst = ctx.reindexer.node_features_reshape(
            batch_edge_index, x_src, x_dst, max_num_node=n_id.max())
        if self.attr_dropout > 0.0 and not inference:
            x_src, x_dst = self._apply_attr_dropout(x_src, x_dst, batch_edge_index)
        x_proj = self.src_linear(x_src[n_id]) + self.dst_linear(x_dst[n_id])
        h = x_proj

        # 4) edge features of the VISIBLE context
        edge_feats = []
        if "edge_type" in self.edge_features:
            edge_feats.append(full_data.edge_type[e_id.cpu()].to(self.device))
        if "msg" in self.edge_features:
            edge_feats.append(full_data.msg[e_id.cpu()].to(self.device))
        if self.use_time_features and e_id.numel() > 0:
            dt_ctx = ctx.stream_tracker.event_dt[e_id]              # seconds
            edge_feats.append(torch.log1p(dt_ctx).unsqueeze(-1))
        edge_feats = torch.cat(edge_feats, dim=-1) if len(edge_feats) > 0 else None

        # 5) GNN forward (masked events are not in ctx_edge_index)
        h = self.encoder(h, ctx_edge_index, edge_feats=edge_feats)

        h_src = h[ctx.assoc[src]]
        h_dst = h[ctx.assoc[dst]]

        # 6) Domain-invariance loss (DANN).  Label current-event endpoint
        #    embeddings, rather than every retained context node: a context
        #    window can straddle day boundaries, so assigning the current
        #    graph's day to all historical context nodes creates label noise.
        domain_loss = None
        labels = domain_labels if domain_labels is not None else domain_id
        if self.domain_disc is not None and not inference and labels is not None:
            domain_h = torch.cat([h_src, h_dst], dim=0)
            domain_loss, domain_stats = self.domain_disc(domain_h, labels)
            if isinstance(domain_stats, dict):
                self._last_domain_stats.update(domain_stats)
            else:
                self._last_domain_stats["domain_acc"] = float(domain_stats)

        # 7) insert AFTER computing embeddings; update stream time state
        new_e_ids = ctx.neighbor_loader.insert(src, dst)
        ctx.stream_tracker.observe(src, dst, t,
                                   ctx.neighbor_loader.last_insert_first_e_id,
                                   ctx.neighbor_loader.cur_e_id)

        # 8) recovery payload for masked context events
        if masked_eids is not None and masked_eids.numel() > 0:
            # Event-level targets: all hidden events in selected arc groups.
            u = full_data.src[masked_eids.cpu()].to(self.device).long()
            v = full_data.dst[masked_eids.cpu()].to(self.device).long()
            u_local, v_local = ctx.assoc[u], ctx.assoc[v]
            h_u, h_v = h[u_local], h[v_local]

            # Link recovery uses one representative per arc group, avoiding
            # overweighting repeated events between the same unordered pair.
            rep_eids = masked_group_rep_eids
            ru = full_data.src[rep_eids.cpu()].to(self.device).long()
            rv = full_data.dst[rep_eids.cpu()].to(self.device).long()
            ru_local, rv_local = ctx.assoc[ru], ctx.assoc[rv]
            neg_local, neg_valid = self._sample_negatives(
                ctx_edge_index, ru_local, rv_local, n_id.numel())
            h_neg = h[neg_local] if neg_local is not None else None

            recovery = {
                "masked_eids": masked_eids,
                "h_u": h_u,
                "h_v": h_v,
                "h_neg": h_neg,
                "neg_valid": neg_valid,
                "link_h_u": h[ru_local],
                "link_h_v": h[rv_local],
                "edge_type": full_data.edge_type[masked_eids.cpu()].to(self.device),
                "dt": dt_m,
                "dt_valid": dt_valid_m,
            }

        return h_src, h_dst, recovery, domain_loss

    def reset_state(self, domain_id=None):
        for d, c in self.ctxs.items():
            if domain_id is None or d == domain_id:
                c.neighbor_loader.reset_state()
                c.stream_tracker.reset()
