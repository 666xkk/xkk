import json
import logging
import math
from datetime import datetime, timezone
from time import perf_counter as timer

import torch.nn as nn
import wandb

from src.encoders import OrthrusEncoder
from config import *
from src.data_utils import *
from src.factory import *


def load_pretrained_weights(model, pretrained_dir, device):
    """Load a stage-1 checkpoint and fail loudly on stale/empty directories.

    ``pretrained_dir`` may be either a trained_models directory containing
    ``model_epoch_N`` folders or a specific ``model_epoch_N`` folder. Recovery
    heads that do not exist in stage 2 are intentionally ignored, but at least
    one encoder parameter must match and load successfully.
    """
    pretrained_dir = os.path.abspath(os.path.expanduser(pretrained_dir))
    if os.path.isfile(os.path.join(pretrained_dir, "state_dict.pkl")):
        ckpt_path = os.path.join(pretrained_dir, "state_dict.pkl")
    else:
        candidates = []
        if os.path.isdir(pretrained_dir):
            for name in os.listdir(pretrained_dir):
                path = os.path.join(pretrained_dir, name)
                if not os.path.isdir(path) or not name.startswith("model_epoch_"):
                    continue
                try:
                    epoch = int(name.rsplit("_", 1)[1])
                except ValueError:
                    continue
                state_path = os.path.join(path, "state_dict.pkl")
                if os.path.isfile(state_path):
                    candidates.append((epoch, state_path))
        if not candidates:
            raise FileNotFoundError(
                f"No model_epoch_N/state_dict.pkl checkpoint found under: {pretrained_dir}")
        ckpt_path = max(candidates, key=lambda item: item[0])[1]

    state = torch.load(ckpt_path, map_location="cpu")
    current = model.state_dict()
    compatible = {k: v for k, v in state.items()
                  if k in current and tuple(v.shape) == tuple(current[k].shape)}
    encoder_keys = [k for k in compatible if k.startswith("encoder.")]
    if not encoder_keys:
        raise RuntimeError(
            f"Checkpoint {ckpt_path} has no shape-compatible encoder parameters; "
            "refusing to silently start stage 2 from random initialization.")
    missing, unexpected = model.load_state_dict(compatible, strict=False)
    log(f"[pretrain] loaded {ckpt_path}")
    log(f"[pretrain] compatible tensors: {len(compatible)}; encoder tensors: {len(encoder_keys)}")
    log(f"[pretrain] missing keys: {list(missing)} | ignored checkpoint keys: "
        f"{[k for k in state if k not in compatible]}")


def train(data,
          full_data,
          model,
          optimizer,
          cfg,
          domain_id=None,
          domain_labels=None,
          ):
    model.train()

    losses = []
    parts_accum = {}
    batch_loader = batch_loader_factory(cfg, data, model.graph_reindexer)

    for batch in batch_loader:
        optimizer.zero_grad()

        loss = model(batch, full_data, domain_id=domain_id,
                     domain_labels=domain_labels)

        if loss.requires_grad:
            loss.backward()
            optimizer.step()
            losses.append(loss.item())
        else:
            # e.g. the first batch of an epoch has an empty context under a
            # pure masked-reconstruction objective -> nothing to optimize
            losses.append(0.0)

        for k, v in model.last_loss_parts.items():
            parts_accum.setdefault(k, []).append(v)
        # [Paper 1] leak-tightness / coverage diagnostics from the encoder
        for k, v in getattr(model.encoder, "_last_mask_stats", {}).items():
            parts_accum.setdefault(k, []).append(float(v))
        # [Paper 2] domain-invariance diagnostics from the encoder
        for k, v in getattr(model.encoder, "_last_domain_stats", {}).items():
            parts_accum.setdefault(k, []).append(float(v))

    mean_parts = {k: float(np.mean(v)) for k, v in parts_accum.items()}
    return float(np.mean(losses)), mean_parts


def _resolve_day_domains(train_data, di_cfg):
    """Map distinct training days to ordinal domain ids (single-domain runs).

    Returns (num_domains, {day: ordinal}) or (None, None) if disabled or
    fewer than two days are resolvable."""
    if not di_cfg.enabled or di_cfg.domain_label not in ("day", "both"):
        return None, None
    days = sorted({int(g.day_id) for g in train_data
                   if getattr(g, "day_id", None) is not None})
    if len(days) < 2:
        log("[domain-invariance] fewer than 2 distinct training days; "
            "discriminator disabled.")
        return None, None
    day_ords = {d: i for i, d in enumerate(days)}
    log(f"[domain-invariance] day domain labels: {day_ords}")
    return len(days), day_ords


def _resolve_multi_domain_classes(per_domain, domain_names, di_cfg):
    """Resolve independent collector/day adversarial heads for joint training."""
    if not di_cfg.enabled:
        return {}, None
    if di_cfg.domain_label not in ("collector", "day", "both"):
        raise ValueError(
            "domain_invariance.domain_label must be collector, day, or both")

    classes = {}
    if di_cfg.domain_label in ("collector", "both"):
        classes["collector"] = len(domain_names)

    day_ords = None
    if di_cfg.domain_label in ("day", "both"):
        days = sorted({
            int(g.day_id.item())
            for name in domain_names for g in per_domain[name]["train"]
            if getattr(g, "day_id", None) is not None
        })
        if len(days) >= 2:
            day_ords = {day: i for i, day in enumerate(days)}
            classes["day"] = len(days)
        else:
            log("[domain-invariance] fewer than 2 distinct training days; "
                "day adversary disabled.")
    log(f"[domain-invariance] adversarial heads: {classes or 'disabled'}")
    return classes, day_ords


def main(cfg):
    gnn_models_dir = cfg.detection.gnn_training._trained_models_dir
    os.makedirs(gnn_models_dir, exist_ok=True)
    metrics_path = os.path.join(gnn_models_dir, "training_metrics.jsonl")
    manifest_path = os.path.join(gnn_models_dir, "run_manifest.json")
    safe_cfg = cfg.clone()
    safe_cfg.defrost()
    if hasattr(safe_cfg, "database") and hasattr(safe_cfg.database, "password"):
        safe_cfg.database.password = "<redacted>"
    with open(manifest_path, "w", encoding="utf-8") as f:
        json.dump({
            "created_utc": datetime.now(timezone.utc).isoformat(),
            "seed": int(cfg._seed),
            "config": safe_cfg.dump(),
        }, f, indent=2, sort_keys=True)
    # A rerun of the exact same seed/config is an explicit replacement.
    with open(metrics_path, "w", encoding="utf-8"):
        pass
    device = get_device(cfg)

    if device == torch.device("cuda"):
        torch.cuda.reset_peak_memory_stats(device=device)

    multi_names = [s.strip() for s in
                   (cfg.detection.gnn_training.multi_domain or "").split(",")
                   if s.strip()]
    di_cfg = cfg.detection.gnn_training.domain_invariance

    # Explicit run configuration in the log makes it possible to verify that
    # stage-1 masking/prior overrides actually reached the training process.
    mask_cfg = cfg.detection.gnn_training.mask
    log(
        "[mask-config] "
        f"enabled={mask_cfg.enabled}, unit={mask_cfg.unit}, rate={mask_cfg.mask_rate}, "
        f"prior={mask_cfg.sampling_prior}, strength={mask_cfg.prior_strength}, "
        f"bridge_strength={mask_cfg.bridge_strength}, "
        f"base_type={mask_cfg.base_type_loss_weight}, type={mask_cfg.type_loss_weight}, "
        f"link={mask_cfg.link_loss_weight}, time={mask_cfg.time_loss_weight}, "
        f"pretrained_dir={cfg.detection.gnn_training.pretrained_dir!r}"
    )
    log(
        "[domain-config] "
        f"enabled={di_cfg.enabled}, label={di_cfg.domain_label}, "
        f"loss_weight={di_cfg.loss_weight}, grad_weight={di_cfg.grad_weight}, "
        f"attr_dropout={di_cfg.attr_dropout}, "
        f"multi_domain={multi_names or 'off'}, "
        f"node_feature_mode={cfg.detection.gnn_training.encoder.node_feature_mode}"
    )

    if multi_names:
        # ---------------- joint multi-collector training ----------------
        if len(multi_names) < 2:
            raise ValueError("multi_domain needs >= 2 comma-separated datasets")
        per_domain = load_all_datasets_multi(cfg, multi_names)
        samples = {n: per_domain[n]["train"][0] for n in multi_names}
        max_nodes = {n: per_domain[n]["max_node"] for n in multi_names}
        num_domains = len(multi_names)
        domain_classes, day_ords = _resolve_multi_domain_classes(
            per_domain, multi_names, di_cfg)
        model = build_model_multi(samples=samples, max_nodes=max_nodes,
                                  device=device, cfg=cfg, num_domains=num_domains,
                                  domain_classes=domain_classes)
        model = model.to(device)
        train_sets = {n: per_domain[n]["train"] for n in multi_names}
        fulls = {n: per_domain[n]["full"] for n in multi_names}
        log(f"[multi-domain] training jointly over: {multi_names}")
    else:
        # ---------------- single-dataset training ----------------
        train_data, _, _, full_data, max_node_num = load_all_datasets(cfg)
        num_domains, day_ords = _resolve_day_domains(train_data, di_cfg)
        domain_classes = ({"day": num_domains} if num_domains is not None
                          else {})
        model = build_model(data_sample=train_data[0], device=device, cfg=cfg,
                            max_node_num=max_node_num, num_domains=num_domains,
                            domain_classes=domain_classes)
        model = model.to(device)
        train_sets = None

    if cfg._from_weights:
        model.load_state_dict(
            torch.load(os.path.join(cfg._from_weights_path, f"{cfg.dataset.name}.pkl")),
            strict=False)  # stock weights lack the recovery heads
    else:
        pretrained_dir = (cfg.detection.gnn_training.pretrained_dir or "").strip()
        if pretrained_dir != "":
            load_pretrained_weights(model, pretrained_dir, device)

    optimizer = optimizer_factory(cfg, parameters=set(model.parameters()))

    num_epochs = 1 if cfg._from_weights else cfg.detection.gnn_training.num_epochs
    tot_loss = 0.0
    epoch_times = []
    for epoch in tqdm(range(1, num_epochs + 1), desc="Training"):
        start = timer()

        tot_loss = 0
        tot_parts = {}
        if multi_names:
            # Each epoch sweeps all collectors; adversarial labels can include
            # collector, day, or both while domain_id selects stream state.
            n_graphs = 0
            for i, name in enumerate(multi_names):
                model.encoder.reset_state(domain_id=i)
                for g in train_sets[name]:
                    g.to(device=device)
                    labels = {}
                    if "collector" in domain_classes:
                        labels["collector"] = i
                    if ("day" in domain_classes and
                            getattr(g, "day_id", None) is not None):
                        labels["day"] = day_ords[int(g.day_id.item())]
                    loss, parts = train(
                        data=g,  # avoids alteration of the graph across epochs
                        full_data=fulls[name],
                        model=model,
                        optimizer=optimizer,
                        cfg=cfg,
                        domain_id=i,
                        domain_labels=labels or None,
                    )
                    tot_loss += loss
                    n_graphs += 1
                    for k, v in parts.items():
                        tot_parts.setdefault(k, []).append(v)
                    g.to("cpu")
            tot_loss /= max(n_graphs, 1)
        else:
            # Before each epoch, reset the temporal state (neighbor window + stream clock)
            model.encoder.reset_state()
            for g in train_data:
                g.to(device=device)
                domain_labels = None
                if day_ords is not None and getattr(g, "day_id", None) is not None:
                    domain_labels = {"day": day_ords[int(g.day_id.item())]}
                loss, parts = train(
                    data=g,  # avoids alteration of the graph across epochs
                    full_data=full_data,  # full list of edge messages (do not store on CPU)
                    model=model,
                    optimizer=optimizer,
                    cfg=cfg,
                    domain_id=None,
                    domain_labels=domain_labels,
                )
                tot_loss += loss
                for k, v in parts.items():
                    tot_parts.setdefault(k, []).append(v)
                g.to("cpu")

            tot_loss /= len(train_data)
        parts_str = ", ".join([f"{k}: {np.mean(v):.4f}" for k, v in tot_parts.items()])
        log(f'GNN training loss Epoch: {epoch:02d}, Loss: {tot_loss:.4f}' + (f' | {parts_str}' if parts_str else ''))
        epoch_times.append(timer() - start)

        peak_memory = (torch.cuda.max_memory_allocated(device=device) / (1024 ** 3)
                       if device.type == "cuda" else 0.0)
        log(f'Peak CUDA memory usage Epoch {epoch}: {peak_memory:.2f} GB')

        epoch_metrics = {
            "epoch": epoch,
            "seed": int(cfg._seed),
            "train_loss": float(tot_loss),
            "epoch_seconds": float(epoch_times[-1]),
            "peak_cuda_memory_gb": float(peak_memory),
        }
        for key, values in tot_parts.items():
            value = float(np.mean(values))
            epoch_metrics[key] = value if math.isfinite(value) else None
        with open(metrics_path, "a", encoding="utf-8") as f:
            f.write(json.dumps(epoch_metrics, sort_keys=True) + "\n")

        wandb.log({
            "train_epoch": epoch,
            "train_loss": round(tot_loss, 4),
            "peak_cuda_memory_GB": round(peak_memory, 2),
            **{f"train_{k}": round(float(np.mean(v)), 4) for k, v in tot_parts.items()},
        })

        if cfg._test_mode or epoch % 1 == 0:
            model_path = os.path.join(gnn_models_dir, f"model_epoch_{epoch}")
            save_model(model, model_path)

    wandb.log({
        "train_epoch_time": round(np.mean(epoch_times), 2),
    })


if __name__ == "__main__":
    args = get_runtime_required_args()
    cfg = get_yml_cfg(args)

    main(cfg)
