from tqdm import tqdm

from src.config import rel2id, get_runtime_required_args, get_yml_cfg
from src.encoders import OrthrusEncoder
from .evaluation_utils import*
from src.data_utils import *
from config import *
from src.model import *
from src.factory import *
import torch


@torch.no_grad()
def test(
        data,
        full_data,
        model,
        nodeid2msg,
        split,
        model_epoch_file,
        cfg,
        device,
):
    model.eval()

    time_with_loss = {}  # key: time，  value： the losses
    edge_list = []
    unique_nodes = torch.tensor([]).to(device=device)
    start_time = data.t[0]
    event_count = 0
    tot_loss = 0
    start = time.perf_counter()

    # NOTE: warning, this may reindexes the graph
    batch_loader = batch_loader_factory(cfg, data, model.graph_reindexer)

    for batch in batch_loader:
        unique_nodes = torch.cat([unique_nodes, batch.edge_index.flatten()]).unique()

        each_edge_loss = model(batch, full_data, inference=True)
        tot_loss += each_edge_loss.sum().item()

        # If the graph has been reindexed in the loader, we retrieve original node IDs
        # to later find the labels
        if hasattr(batch, "original_edge_index"):
            edge_index = batch.original_edge_index
        else:
            edge_index = batch.edge_index

        num_events = each_edge_loss.shape[0]
        edge_types = torch.argmax(batch.edge_type, dim=1) + 1
        for i in range(num_events):
            srcnode = int(edge_index[0, i])
            dstnode = int(edge_index[1, i])

            srcmsg = nodeid2msg[srcnode]
            dstmsg = nodeid2msg[dstnode]
            t_var = int(batch.t[i])
            edge_type_idx = edge_types[i].item()
            edge_type = rel2id[edge_type_idx]
            loss = each_edge_loss[i]

            temp_dic = {
                'loss': float(loss),
                'srcnode': srcnode,
                'dstnode': dstnode,
                'srcmsg': srcmsg,
                'dstmsg': dstmsg,
                'edge_type': edge_type,
                'time': t_var,
            }
            edge_list.append(temp_dic)

        event_count += num_events
    tot_loss /= event_count

    # Here is a checkpoint, which records all edge losses in the current time window
    time_interval = ns_time_to_datetime_US(start_time) + "~" + ns_time_to_datetime_US(edge_list[-1]["time"])

    end = time.perf_counter()
    logs_dir = os.path.join(cfg.detection.gnn_testing._edge_losses_dir, split, model_epoch_file)
    os.makedirs(logs_dir, exist_ok=True)
    csv_file = os.path.join(logs_dir, time_interval + ".csv")

    df = pd.DataFrame(edge_list)
    df.to_csv(csv_file, sep=',', header=True, index=False, encoding='utf-8')

    # log(
    #     f'Time: {time_interval}, Loss: {tot_loss:.4f}, Nodes_count: {len(unique_nodes)}, Edges_count: {event_count}, Cost Time: {(end - start):.2f}s')


@torch.no_grad()
def warm_up(data, full_data, model, cfg, device):
    """Populate target stream state without fitting or retaining scores.

    A leave-one-collector-out checkpoint has no neighbor-loader state for the
    held-out target. Replaying its training prefix in inference mode supplies
    the causal benign history available at deployment, without gradients or
    validation/test information.
    """
    model.eval()
    for graph in tqdm(data, desc="target train warm-up"):
        graph.to(device=device)
        for batch in batch_loader_factory(cfg, graph, model.graph_reindexer):
            model(batch, full_data, inference=True)
        graph.to("cpu")


def main(cfg):
    # load the map between nodeID and node labels
    cur, _ = init_database_connection(cfg)
    nodeid2msg = gen_nodeid2msg(cur=cur)
    nodeid2msg = {k: str(v) for k, v in nodeid2msg.items()}  # pre-compute because it's too slow in main loop

    train_data, val_data, test_data, full_data, max_node_num = load_all_datasets(cfg)

    # For each model trained at a given epoch, we test
    gnn_models_dir = (cfg._checkpoint_dir or
                      cfg.detection.gnn_training._trained_models_dir)
    all_trained_models = (["model_epoch_1"] if cfg._from_weights else [
        name for name in listdir_sorted(gnn_models_dir)
        if name.startswith("model_epoch_") and
        os.path.isdir(os.path.join(gnn_models_dir, name))
    ])
    if not all_trained_models:
        raise FileNotFoundError(
            f"no model_epoch_N checkpoints found in {gnn_models_dir}")

    device = get_device(cfg)
    multi_names = [s.strip() for s in
                   (cfg.detection.gnn_training.multi_domain or "").split(",")
                   if s.strip()]
    checkpoint_domain_id = (multi_names.index(cfg.dataset.name)
                            if cfg.dataset.name in multi_names else None)

    for trained_model in all_trained_models:
        log(f"Evaluation with model {trained_model}...")
        torch.cuda.empty_cache()
        # model = build_model(data_sample=test_data[0], device=device, cfg=cfg, max_node_num=max_node_num)
        # model = load_model(model, os.path.join(gnn_models_dir, trained_model))
        model = build_model(data_sample=test_data[0], device=device, cfg=cfg, max_node_num=max_node_num)
        checkpoint_path = os.path.join(gnn_models_dir, trained_model)
        if multi_names and checkpoint_domain_id is None:
            model = load_model(model, checkpoint_path, neigh_loader=False)
        else:
            model = load_model(model, checkpoint_path,
                               domain_id=checkpoint_domain_id)
        model = model.to(device)   # [hotfix] 同上

        if cfg._from_weights:
            model.load_state_dict(
                torch.load(os.path.join(cfg._from_weights_path, f"{cfg.dataset.name}.pkl")),
                strict=False,  # [Paper 1] stock weights lack the recovery heads
            )
        if multi_names and checkpoint_domain_id is None:
            log("[protocol] held-out collector: warming target context on its "
                "training prefix without gradients")
            warm_up(train_data, full_data, model, cfg, device)
        # TODO: we may want to move the validation set into the training for early stopping
        for graphs, split in [
            (val_data, "val"),
            (test_data, "test"),
        ]:
            log(f"    Testing {split} set...")
            for g in tqdm(graphs, desc=f"{split} set with {trained_model}"):
                g.to(device=device)
                test(
                    data=g,
                    full_data=full_data,
                    model=model,
                    nodeid2msg=nodeid2msg,
                    split=split,
                    model_epoch_file=trained_model,
                    cfg=cfg,
                    device=device,
                )
                g.to("cpu")

        del model


if __name__ == "__main__":
    args = get_runtime_required_args()
    cfg = get_yml_cfg(args)

    main(cfg)
