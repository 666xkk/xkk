#!/usr/bin/env bash
# Stage-2 fine-tuning from an explicitly supplied stage-1 checkpoint directory.
# Usage: S1_DIR=/absolute/path/to/trained_models ./scripts/run_paper1_stage2.sh uniform
set -euo pipefail

PRIOR="${1:-}"
case "$PRIOR" in uniform|temporal) ;; *) echo "Usage: S1_DIR=/path $0 {uniform|temporal}" >&2; exit 2 ;; esac
: "${S1_DIR:?Set S1_DIR to the exact trained_models directory from the matching stage-1 run}"
DATASET="${DATASET:-CADETS_E3}"
SEED="${SEED:-4}"
EPOCHS="${EPOCHS:-20}"
LR="${LR:-0.001}"

[[ -d "$S1_DIR" ]] || { echo "ERROR: S1_DIR does not exist: $S1_DIR" >&2; exit 2; }
COUNT=$(find "$S1_DIR" -mindepth 2 -maxdepth 2 -type f -name state_dict.pkl | wc -l)
[[ "$COUNT" -ge 1 ]] || { echo "ERROR: no model_epoch_N/state_dict.pkl checkpoints under $S1_DIR" >&2; exit 2; }
mkdir -p runs/PATCHED
export PYTHONHASHSEED=0
LOG="runs/PATCHED/${PRIOR}_s2.log"

python -u -m src.orthrus "$DATASET" --run_from_training --seed="$SEED" \
  --detection.gnn_training.lr="$LR" \
  --detection.gnn_training.num_epochs="$EPOCHS" \
  --detection.gnn_training.mask.enabled=false \
  --detection.gnn_training.mask.mask_rate=0.15 \
  --detection.gnn_training.mask.sampling_prior="$PRIOR" \
  --detection.gnn_training.pretrained_dir="$S1_DIR" \
  --detection.evaluation.node_evaluation.use_kmeans=false \
  --exp="PATCHED_${PRIOR}_s2" 2>&1 | tee "$LOG"

grep -E '\[mask-config\]|\[pretrain\] loaded|compatible tensors|encoder tensors|Run finished' "$LOG"
grep -q '\[pretrain\] loaded' "$LOG" || { echo "ERROR: no pretrained checkpoint load confirmation in $LOG" >&2; exit 3; }
