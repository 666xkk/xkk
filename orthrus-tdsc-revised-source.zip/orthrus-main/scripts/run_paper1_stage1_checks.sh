#!/usr/bin/env bash
# Paper-1 masking stage-1 examples with masking explicitly enabled.
# Run from the repository root. These commands train only; stage-2 evaluation
# should use the exact stage-1 checkpoint directory printed/stored by the user.
set -euo pipefail

DATASET="${DATASET:-CADETS_E3}"
SEED="${SEED:-4}"
EPOCHS="${EPOCHS:-20}"
LR="${LR:-0.001}"
mkdir -p runs/PATCHED
export PYTHONHASHSEED=0

run_stage1() {
  local prior="$1"
  local exp="PATCHED_${prior}_s1"
  local log_file="runs/PATCHED/${prior}_s1.log"
  python -u -m src.orthrus "$DATASET" --run_from_training --seed="$SEED" --train_only \
    --detection.gnn_training.lr="$LR" \
    --detection.gnn_training.num_epochs="$EPOCHS" \
    --detection.gnn_training.mask.enabled=true \
    --detection.gnn_training.mask.mask_rate=0.15 \
    --detection.gnn_training.mask.sampling_prior="$prior" \
    --detection.gnn_training.mask.base_type_loss_weight=0.0 \
    --exp="$exp" 2>&1 | tee "$log_file"
  grep -F '[mask-config]' "$log_file"
  grep -E 'n_groups_masked|n_events_masked|frac_groups_with_dups' "$log_file" | head -5 || true
}

case "${1:-}" in
  uniform|temporal) run_stage1 "$1" ;;
  *) echo "Usage: $0 {uniform|temporal}" >&2; exit 2 ;;
esac
