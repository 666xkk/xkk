#!/usr/bin/env bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT_DIR"
PYTHON_BIN="${PYTHON_BIN:-python}"

"$PYTHON_BIN" -m py_compile \
  src/attr_schema.py src/masking.py src/domain_invariance.py \
  src/encoders.py src/data_utils.py src/model.py src/factory.py \
  src/detection/orthrus_gnn_training.py \
  src/detection/orthrus_gnn_testing.py

PYTHONPATH=. "$PYTHON_BIN" -m pytest -q \
  tests/test_paper1_masking_unit.py tests/test_paper2_mechanisms.py

PYTHONPATH=. "$PYTHON_BIN" - <<'PY'
from src.config import get_runtime_required_args, get_yml_cfg

paths = []
for seed in (0, 1):
    args = get_runtime_required_args(
        args=["CADETS_E3", "--model", "tdsc", "--cpu", f"--seed={seed}"])
    cfg = get_yml_cfg(args)
    paths.append(cfg.detection.gnn_training._trained_models_dir)
assert paths[0] != paths[1], "seeded runs must have distinct artifact paths"
print("TDSC configuration and seed isolation: OK")
PY
