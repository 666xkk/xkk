# TDSC readiness audit

## Decision

The archive contains credible implementations of all four proposed mechanisms,
but the supplied evidence is not sufficient for a TDSC submission. The included
logs cover an incomplete single-dataset pretraining run and do not establish
downstream gain, cross-collector generalization, statistical significance, or
cost. Code correctness is necessary evidence; it is not an empirical result.

This revision closes implementation issues that would otherwise invalidate the
claims:

| Proposed mechanism | Implementation evidence | Revision made here |
| --- | --- | --- |
| Leak-tight masking | `ContextEventMasker` removes every retained entry for a selected unordered endpoint pair and deduplicates event targets. | Added `entry`, `directed_typed`, and `unordered_pair` units for a controlled ablation. Every batch reports residual group and triple-copy leaks; randomized arc-group tests require zero. |
| Temporal-bridge masking | Offline endpoint predecessor/successor gaps drive a bridge-weighted masking curriculum; inference remains causal. | A bridge now requires valid gaps on both sides. Gap computation is bounded by `train_event_count`, so validation/test events cannot affect training masks. |
| Canonical attributes and missingness | One schema, shared missing token, presence channel, and attribute dropout are implemented. | Added deterministic `canonical_hash` features so collectors share an actual coordinate system. Pure `structure` mode now excludes the collector-revealing presence channel. |
| Dual-domain robustness | Per-domain stream contexts and GRL discriminators are implemented. | Added simultaneous collector/day adversarial heads, endpoint-aligned domain labels, target-context selection, and causal held-out-collector warm-up. |

Use `config/tdsc.yml` with `--model tdsc`. It enables canonical hashing,
bridge-first masking, the dual adversary, attribute dropout, and strict
validation-derived thresholding. Exact-seed outputs now have different artifact
paths. Every training directory records a redacted `run_manifest.json` and
machine-readable `training_metrics.jsonl`.

For leave-one-collector-out evaluation, use `--test_only --checkpoint_dir`
with `multi_domain` set to the source collectors. This loads shared weights,
builds held-out target context only from its training prefix, derives model
selection and thresholds from validation, and scores test last.

## Claims that the code can support

After the experiments below, the paper can claim that the method (1) measures
and eliminates residual duplicate exposure under its stated arc-group masking
unit, (2) concentrates pretraining on temporally isolated training events
without validation/test leakage, and (3) combines collector-independent lexical
coordinates with explicit collector/day adversarial regularization.

Do not claim graph-theoretic bridge detection, distribution-free invariance, or
TDSC-level superiority from the unit tests. The bridge is temporal; DANN is a
regularizer; the post-hoc held-out-domain result is the evidence of invariance.

## Minimum publishable experiment matrix

1. Run at least five fixed seeds for the original ORTHRUS baseline; entry,
   directed-typed, and unordered-pair mask units; uniform, temporal, and bridge
   priors; canonical hashing only,
   attribute dropout only, collector DANN only, day DANN only, and the full
   method. Preserve identical splits, budgets, epoch selection, and validation
   thresholds.
2. Report CADETS, THEIA, and CLEARSCOPE E3/E5 in-domain results and all
   leave-one-collector-out transfers. A held-out collector must never appear in
   feature fitting, masking statistics, checkpoint selection, or threshold
   selection.
3. Report AP, ROC-AUC, MCC, recall, precision, F1, FPR, and FPR at fixed recall,
   with mean, standard deviation, 95% confidence intervals, and paired tests
   against the strongest baseline. Include absolute FP counts because the data
   are highly imbalanced.
4. Add robustness curves for controlled attribute removal, timestamp jitter,
   duplicate-event injection, and collector/day drift. Include an adaptive
   attacker that manipulates frequent attributes or creates bursty events.
5. Report training/inference time, peak memory, parameter count, and throughput.
   Compare at the same hardware and batch size.
6. Compare with current provenance IDS baselines under the same split and
   threshold protocol. If a baseline cannot be reproduced, state the exact
   artifact/version and failure instead of substituting a weaker result.

The cross-collector table and the matched ablation table are the likely main
TDSC evidence. Without them, the project remains an implementation prototype
rather than a journal-ready contribution.

## Verification

Install `requirements-mechanisms.txt`, then run:

```bash
PYTHON_BIN=python bash scripts/run_tdsc_checks.sh
```

Full training still requires the DARPA TC databases and the services described
in the original README/Docker setup. No end-to-end performance claim is made by
this audit because those databases are not included in the archive.
