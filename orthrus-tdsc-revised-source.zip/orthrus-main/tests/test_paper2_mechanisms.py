"""Dependency-light unit tests for the Paper-2 mechanisms:
  1. leak-tight (src,dst,type) duplicate diagnostics (arc-group masking v2),
  2. temporal bridge prior (offline prev/next endpoint gaps),
  3. attribute abstraction (missingness masks, attribute dropout),
  4. domain-invariance (gradient reversal + discriminator, multi-domain ctxs).

Run: python tests/test_paper2_mechanisms.py
"""
import sys
from pathlib import Path
from types import SimpleNamespace

import torch
import torch.nn as nn
import torch.nn.functional as F
from torch_geometric.data import Data

REPO_ROOT = Path(__file__).resolve().parents[1]
if str(REPO_ROOT) not in sys.path:
    sys.path.insert(0, str(REPO_ROOT))

from src.masking import (StreamTimeTracker, ContextEventMasker,
                         compute_event_endpoint_gaps)
from src.domain_invariance import (GradientReversal, grad_reverse,
                                   DomainDiscriminator,
                                   MultiHeadDomainDiscriminator)
from src.attr_schema import (attr_presence_bits, is_missing,
                             node_feature_layout, canonical_hash_embedding)
from src.temporal import LastNeighborLoader
from src.encoders import OrthrusEncoder, LinearEncoder, DomainContext
from src.data_utils import GraphReindexer, save_model, load_model


def make_full_data(num_nodes=12, num_events=24, dim=8, num_edge_types=10, seed=0):
    g = torch.Generator().manual_seed(seed)
    src = torch.randint(0, num_nodes, (num_events,), generator=g)
    dst = torch.randint(0, num_nodes, (num_events,), generator=g)
    # strictly increasing stream times
    t = torch.sort(torch.randint(0, 10_000_000, (num_events,), generator=g)).values * 1000
    edge_type = F.one_hot(torch.randint(0, num_edge_types, (num_events,), generator=g),
                          num_edge_types).float()
    msg = torch.randn(num_events, dim, generator=g)
    return Data(msg=msg, t=t, edge_type=edge_type, src=src, dst=dst)


def build_encoder(num_nodes, dim, num_edge_types, seed=0, mask_rate=0.5,
                  sampling_prior="uniform", link_negatives=4, bridge_strength=0.0,
                  domain_ctxs=None, domain_disc=None, attr_dropout=0.0,
                  attr_dim=0, type_dim=0, pres_dim=0, use_node_feats=True):
    device = torch.device("cpu")
    loader = LastNeighborLoader(num_nodes=num_nodes, size=5, device=device)
    inner = LinearEncoder(in_dim=16, hid_dim=16, out_dim=dim)
    gen = torch.Generator(device=device).manual_seed(seed)
    masker = ContextEventMasker(mask_rate=mask_rate, sampling_prior=sampling_prior,
                                prior_strength=1.0, generator=gen,
                                bridge_strength=bridge_strength)
    return OrthrusEncoder(
        encoder=inner,
        neighbor_loader=loader,
        in_dim=dim,
        temporal_dim=16,
        use_node_feats_in_gnn=use_node_feats,
        graph_reindexer=GraphReindexer(num_nodes=num_nodes, device=device),
        edge_features=["edge_type"],
        device=device,
        num_nodes=num_nodes,
        edge_dim=num_edge_types,
        use_time_features=False,
        masker=masker,
        link_negatives=link_negatives,
        domain_ctxs=domain_ctxs,
        domain_disc=domain_disc,
        attr_dropout=attr_dropout,
        attr_dim=attr_dim,
        type_dim=type_dim,
        pres_dim=pres_dim,
        num_edge_types=num_edge_types,
        bridge_strength=bridge_strength,
        feat_gen=torch.Generator(device=device).manual_seed(seed + 7),
        track_triple_dups=True,
    )


def run_batch(enc, full_data, lo, hi, dim, domain_id=None):
    bi = torch.arange(lo, hi)
    e = bi.numel()
    x_src = torch.randn(e, dim, generator=torch.Generator().manual_seed(123))
    x_dst = torch.randn(e, dim, generator=torch.Generator().manual_seed(456))
    return enc.forward(
        edge_index=torch.stack([full_data.src[bi], full_data.dst[bi]]),
        t=full_data.t[bi], msg=full_data.msg[bi], x=(x_src, x_dst),
        full_data=full_data, domain_id=domain_id)


# ------------------------------------------------------------------ (2) gaps
def test_gaps_match_reference():
    g = torch.Generator().manual_seed(3)
    E, N = 300, 15
    src = torch.randint(0, N, (E,), generator=g)
    dst = torch.randint(0, N, (E,), generator=g)
    t = torch.sort(torch.randint(0, 100_000_000, (E,), generator=g)).values * 1000

    prev_dt, prev_v, next_dt, next_v = compute_event_endpoint_gaps(src, dst, t)

    last = {}
    for i in range(E):
        u, v = int(src[i]), int(dst[i])
        endps = {u} if u == v else {u, v}
        prev = max((last[n] for n in endps if n in last), default=-1)
        ok = prev >= 0
        assert bool(prev_v[i]) == ok, f"prev validity mismatch at event {i}"
        if ok:
            assert abs(float(prev_dt[i]) - (int(t[i]) - prev) / 1e9) < 1e-6
        for n in endps:
            last[n] = int(t[i])

    nxt = {}
    for i in range(E - 1, -1, -1):
        u, v = int(src[i]), int(dst[i])
        endps = {u} if u == v else {u, v}
        n = min((nxt[k] for k in endps if k in nxt), default=None)
        if n is not None:
            assert bool(next_v[i]), f"next validity mismatch at event {i}"
            assert abs(float(next_dt[i]) - (n - int(t[i])) / 1e9) < 1e-6
        else:
            assert not bool(next_v[i]), f"next gap should be invalid at event {i}"
        for k in endps:
            nxt[k] = int(t[i])
    print("[ok] prev/next endpoint gaps match the event-by-event reference")


def test_gaps_consistency_with_stream_tracker():
    src = torch.tensor([0, 1, 0, 2, 1, 0])
    dst = torch.tensor([1, 2, 2, 0, 0, 1])
    t = torch.tensor([10, 20, 30, 40, 50, 60], dtype=torch.long)
    prev_dt, prev_v, _, _ = compute_event_endpoint_gaps(src, dst, t)
    tracker = StreamTimeTracker(num_nodes=3, device="cpu", init_capacity=8)
    got_dt, got_valid = tracker.observe(src, dst, t, first_e_id=0, cur_e_id=6)
    assert torch.allclose(prev_dt, got_dt, atol=1e-6)
    assert prev_v.tolist() == got_valid.tolist()
    print("[ok] offline prev gaps equal the online StreamTimeTracker")


# ------------------------------------------------------ (2) bridge prior
def test_bridge_prior_upweights_isolated_groups():
    # Two arc groups: A has tiny gaps on both sides, B is a temporal bridge
    # (huge prev AND next gaps).
    eids = torch.tensor([0, 1, 2, 3])
    arc = torch.tensor([10, 10, 20, 20])
    dt = torch.tensor([0.5, 0.5, 5.0, 5.0])
    valid = torch.ones(4, dtype=torch.bool)
    bridge_prev = torch.tensor([0.1, 0.1, 1000.0, 1000.0])
    bridge_next = torch.tensor([0.1, 0.1, 1000.0, 1000.0])

    def draw(seed):
        m = ContextEventMasker(mask_rate=0.5, sampling_prior="bridge",
                               prior_strength=1.0, bridge_strength=100.0,
                               generator=torch.Generator().manual_seed(seed))
        out = m.sample(eids, arc, dt, valid,
                       bridge_prev=bridge_prev, bridge_prev_valid=valid,
                       bridge_next=bridge_next, bridge_next_valid=valid)
        return out

    for seed in range(25):
        out = draw(seed)
        # exactly one group masked per draw; the bridge group must always win
        assert out["masked_group_rep_eids"].numel() == 1
        masked = out["masked_eids"].tolist()
        assert all(eid in (2, 3) for eid in masked), \
            f"bridge prior failed to select the isolated group (seed {seed})"
        stats = out["stats"]
        assert stats["bridge_mean_masked"] > stats["bridge_mean_ctx"]
        assert stats["bridge_top_frac"] == 1.0

    # "bridge" prior implies bridge_strength defaults to prior_strength
    m = ContextEventMasker(mask_rate=0.5, sampling_prior="bridge",
                           prior_strength=2.0)
    assert m.bridge_strength == 2.0
    print("[ok] bridge prior concentrates masks on temporally isolated groups")


def test_bridge_requires_both_temporal_sides():
    """Stream-boundary events are not bridges, even with one huge gap."""
    eids = torch.tensor([0, 1])
    arc = torch.tensor([10, 20])
    dt = torch.ones(2)
    valid = torch.ones(2, dtype=torch.bool)
    prev = torch.tensor([1_000_000.0, 10.0])
    nxt = torch.tensor([1_000_000.0, 10.0])
    prev_valid = torch.tensor([False, True])
    next_valid = torch.tensor([True, True])

    for seed in range(20):
        masker = ContextEventMasker(
            mask_rate=0.5, sampling_prior="bridge", bridge_strength=1e6,
            generator=torch.Generator().manual_seed(seed))
        out = masker.sample(
            eids, arc, dt, valid, bridge_prev=prev,
            bridge_prev_valid=prev_valid, bridge_next=nxt,
            bridge_next_valid=next_valid)
        assert out["masked_eids"].tolist() == [1]
        assert out["stats"]["bridge_eligible_frac"] == 0.5
    print("[ok] temporal bridges require valid predecessor and successor gaps")


def test_bridge_gap_scope_excludes_holdout_events():
    # Event 2 is a validation/test event sharing endpoint 0 with the final
    # training event. It must not become that training event's successor.
    fd = Data(
        src=torch.tensor([2, 0, 0]), dst=torch.tensor([3, 1, 4]),
        t=torch.tensor([10, 20, 10_000], dtype=torch.long),
        edge_type=F.one_hot(torch.tensor([0, 0, 0]), 10).float(),
        msg=torch.zeros(3, 8),
    )
    fd.train_event_count = 2
    enc = build_encoder(5, 8, 10, sampling_prior="bridge",
                        bridge_strength=1.0)
    _, _, _, next_valid = enc._event_gaps(fd)
    assert not bool(next_valid[1]), "holdout event leaked into training bridge score"
    assert not bool(next_valid[2]), "events outside the training scope stay invalid"
    print("[ok] bridge gaps are computed on the training prefix only")


# ------------------------------------------------------ (1) leak diagnostics
def test_triple_dup_diagnostics_and_arc_group_removal():
    # One arc group {u,v} (key 10) holds 3 events of 2 types; triple keys
    # reveal 2 duplicated triples out of 3 distinct triples.
    eids = torch.tensor([0, 1, 2, 3, 4])
    arc = torch.tensor([10, 10, 10, 20, 30])
    triple = torch.tensor([100, 100, 100, 200, 300])
    dt = torch.arange(5, dtype=torch.float32)
    valid = torch.ones(5, dtype=torch.bool)

    masker = ContextEventMasker(mask_rate=0.9, sampling_prior="uniform",
                                max_mask_frac=1.0,
                                generator=torch.Generator().manual_seed(1))
    out = masker.sample(eids, arc, dt, valid, triple_key=triple)
    assert out["masked_eids"].tolist() == [0, 1, 2, 3, 4], \
        "the whole arc group (incl. duplicated triples) must be removed together"
    assert not out["keep"].any()
    stats = out["stats"]
    assert abs(stats["triple_dup_frac"] - 1 / 3) < 1e-6
    assert abs(stats["entries_triple_dup_frac"] - 3 / 5) < 1e-6
    assert stats["residual_arc_leak_count"] == 0
    assert stats["residual_arc_leak_frac"] == 0.0
    print("[ok] (src,dst,type) duplicate diagnostics + joint arc-group removal")


def test_randomized_masking_has_zero_residual_arc_leaks():
    gen = torch.Generator().manual_seed(91)
    for seed in range(25):
        eids = torch.arange(200)
        arc = torch.randint(0, 25, (200,), generator=gen)
        dt = torch.rand(200, generator=gen)
        valid = torch.rand(200, generator=gen) > 0.1
        out = ContextEventMasker(
            mask_rate=0.3, sampling_prior="uniform",
            generator=torch.Generator().manual_seed(seed)).sample(
                eids, arc, dt, valid)
        assert out["stats"]["residual_arc_leak_count"] == 0
        masked_arcs = set(arc[~out["keep"]].tolist())
        visible_arcs = set(arc[out["keep"]].tolist())
        assert masked_arcs.isdisjoint(visible_arcs)
    print("[ok] randomized arc-group masking leaves zero visible copies")


def test_mask_unit_ablation_exposes_and_closes_duplicate_copying():
    eids = torch.tensor([0, 1])
    triple = torch.tensor([100, 100])
    dt = torch.ones(2)
    valid = torch.ones(2, dtype=torch.bool)

    entry = ContextEventMasker(
        mask_rate=0.5, sampling_prior="uniform",
        generator=torch.Generator().manual_seed(0)).sample(
            eids, torch.arange(2), dt, valid, triple_key=triple)
    assert entry["stats"]["residual_triple_copy_count"] == 1

    grouped = ContextEventMasker(
        mask_rate=0.5, sampling_prior="uniform",
        generator=torch.Generator().manual_seed(0)).sample(
            eids, triple, dt, valid, triple_key=triple)
    assert grouped["stats"]["residual_triple_copy_count"] == 0
    assert not grouped["keep"].any()
    print("[ok] entry baseline leaks a duplicate; typed grouping removes it")


# ------------------------------------------------------ (4) DANN primitives
def test_gradient_reversal_and_discriminator():
    x = torch.tensor([1.0, 2.0], requires_grad=True)
    y = grad_reverse(x, 2.0)
    y.backward(torch.ones_like(y))
    assert torch.equal(x.grad, torch.tensor([-2.0, -2.0])), "GRL must negate and scale"

    disc = DomainDiscriminator(in_dim=8, hid_dim=16, num_domains=3, lam=1.0)
    h = torch.randn(20, 8)
    loss, acc = disc(h, 1)
    assert loss.ndim == 0 and 0.0 <= float(acc) <= 1.0
    disc.zero_grad()
    loss.backward()
    assert all(p.grad is not None for p in disc.parameters())
    print("[ok] gradient reversal + domain discriminator forward/backward")


def test_discriminator_learns_separable_domains():
    torch.manual_seed(0)
    disc = DomainDiscriminator(in_dim=4, hid_dim=16, num_domains=2, lam=1.0)
    opt = torch.optim.Adam(disc.parameters(), lr=0.05)
    # two separable clusters
    X0 = torch.randn(256, 4) + torch.tensor([3.0, 0, 0, 0])
    X1 = torch.randn(256, 4) + torch.tensor([-3.0, 0, 0, 0])
    for step in range(60):
        opt.zero_grad()
        l0, _ = disc(X0, 0)
        l1, _ = disc(X1, 1)
        (l0 + l1).backward()
        opt.step()
    _, acc0 = disc(X0, 0)
    _, acc1 = disc(X1, 1)
    assert float(acc0) > 0.9 and float(acc1) > 0.9, "discriminator should separate the clusters"
    print("[ok] discriminator reaches high accuracy on separable domains")


def test_dual_domain_adversary_backpropagates_both_heads():
    torch.manual_seed(4)
    disc = MultiHeadDomainDiscriminator(
        in_dim=8, hid_dim=12, domain_sizes={"collector": 3, "day": 4},
        lam=0.5)
    h = torch.randn(16, 8, requires_grad=True)
    loss, stats = disc(h, {"collector": 1, "day": 2})
    loss.backward()
    assert loss.ndim == 0 and h.grad is not None
    assert set(stats) == {
        "domain_acc_collector", "domain_loss_collector",
        "domain_acc_day", "domain_loss_day",
    }
    assert all(p.grad is not None for p in disc.parameters())
    print("[ok] collector/day adversaries optimize jointly through one encoder")


# ------------------------------------------------------ (3) attribute dropout
def _build_dropout_encoder(dropout, attr_dim=8, type_dim=3, pres_dim=4):
    """Encoder whose x blocks are [attr(8), type(3), pres(4)] (15 cols)."""
    x_width = attr_dim + type_dim + pres_dim
    return build_encoder(12, x_width, 10, seed=0, mask_rate=0.5,
                         attr_dropout=dropout, attr_dim=attr_dim,
                         type_dim=type_dim, pres_dim=pres_dim)


def _single_dropout_forward(dropout, x_seed):
    # A single FIRST-batch forward: context is empty, so every node in the
    # aggregation is a batch endpoint and the dropout applies to all of them.
    torch.manual_seed(0)   # deterministic weight init across the two calls
    enc = _build_dropout_encoder(dropout)
    fd = make_full_data(num_nodes=12, num_events=24, dim=8, seed=7)
    bi = torch.arange(0, 12)
    e = bi.numel()
    g = torch.Generator().manual_seed(x_seed)
    attr = torch.randn(e, 8, generator=g)                                # dropped
    ntype = F.one_hot(torch.full((e,), 1, dtype=torch.long), 3).float()  # kept
    pres = torch.randn(e, 4, generator=g)                                # dropped
    x = torch.cat([attr, ntype, pres], dim=-1)
    return enc.forward(
        edge_index=torch.stack([fd.src[bi], fd.dst[bi]]),
        t=fd.t[bi], msg=fd.msg[bi], x=(x, x.clone()), full_data=fd)[0]


def test_attr_dropout_erases_attributes():
    h_a = _single_dropout_forward(dropout=1.0, x_seed=123)
    h_b = _single_dropout_forward(dropout=1.0, x_seed=999)
    assert torch.allclose(h_a, h_b, atol=1e-6), \
        "with attr_dropout=1 the node attributes must be fully erased"
    print("[ok] attribute dropout erases the attribute/presence blocks")


def test_attr_dropout_disabled_preserves_attributes():
    h_a = _single_dropout_forward(dropout=0.0, x_seed=123)
    h_b = _single_dropout_forward(dropout=0.0, x_seed=999)
    assert not torch.allclose(h_a, h_b, atol=1e-6), \
        "without dropout the attributes must influence the embeddings"
    print("[ok] attribute dropout off -> attributes flow through")


def test_attr_dropout_is_node_consistent_across_endpoint_roles():
    enc = _build_dropout_encoder(dropout=1.0)
    width = 8 + 3 + 4
    x_src = torch.randn(6, width)
    x_dst = torch.randn(6, width)
    # Node 2 appears as both source and destination.
    edge_index = torch.tensor([[2, 3], [4, 2]])
    out_src, out_dst = enc._apply_attr_dropout(x_src, x_dst, edge_index)
    assert torch.equal(out_src[2, :8], out_dst[2, :8])
    assert not out_src[2, -4:].any() and not out_dst[2, -4:].any()
    assert enc._last_domain_stats["attr_dropout_rate"] == 1.0
    print("[ok] one dropout decision applies to both roles of the same node")


# ------------------------------------------------------ (3) presence masks
def test_presence_bits():
    assert attr_presence_bits("subject", path="/bin/sh", cmd_line="-c ls") == 0b0011
    assert attr_presence_bits("subject", path=None, cmd_line="x") == 0b0010
    assert attr_presence_bits("file", path="None") == 0
    assert attr_presence_bits("netflow", remote_ip="1.2.3.4", remote_port=80) == 0b1100
    assert is_missing("none") and is_missing("") and not is_missing("/tmp/x")
    print("[ok] presence bitmasks + missingness detection")


def test_structure_mode_excludes_collector_missingness():
    def cfg(mode):
        return SimpleNamespace(
            detection=SimpleNamespace(gnn_training=SimpleNamespace(
                encoder=SimpleNamespace(
                    node_feature_mode=mode,
                    use_node_type_in_node_feats=True))),
            edge_featurization=SimpleNamespace(
                embed_nodes=SimpleNamespace(emb_dim=8),
                embed_edges=SimpleNamespace(
                    add_missingness=True, missingness_dim=16)),
            dataset=SimpleNamespace(num_node_types=3),
        )

    assert node_feature_layout(cfg("structure")) == [("type", 3)]
    assert ("pres", 16) in node_feature_layout(cfg("both"))
    print("[ok] pure structure mode contains no collector missingness fingerprint")


def test_canonical_hash_is_shared_and_reproducible():
    a1 = canonical_hash_embedding(["/", "usr", "bin", "None"], 64, seed=7)
    a2 = canonical_hash_embedding(["/", "usr", "bin", "none"], 64, seed=7)
    b = canonical_hash_embedding(["/", "opt", "malware"], 64, seed=7)
    assert (a1 == a2).all(), "missing aliases must share one representation"
    assert not (a1 == b).all(), "different attributes need distinct features"
    assert abs(float((a1 ** 2).sum()) - 1.0) < 1e-6
    print("[ok] canonical hashing aligns attribute coordinates across collectors")


# ------------------------------------------------------ (4) multi-domain ctxs
def test_multi_domain_context_switching():
    dim = 8
    ctx0 = DomainContext(num_nodes=20, device="cpu", neighbor_size=5)
    ctx1 = DomainContext(num_nodes=30, device="cpu", neighbor_size=5)
    enc = build_encoder(20, dim, 10, seed=0, mask_rate=0.5,
                        domain_ctxs={0: ctx0, 1: ctx1})
    fd0 = make_full_data(num_nodes=20, num_events=12, dim=dim, seed=11)
    fd1 = make_full_data(num_nodes=30, num_events=12, dim=dim, seed=13)

    run_batch(enc, fd0, 0, 6, dim, domain_id=0)
    _, _, rec0, _ = run_batch(enc, fd0, 6, 12, dim, domain_id=0)
    assert enc.ctxs[0].stream_tracker.event_dt_valid.any(), "domain 0 stream tracked"

    # domain 1 has a fresh stream: first batch must have an empty context
    enc.ctxs[1].neighbor_loader.reset_state()
    enc.ctxs[1].stream_tracker.reset()
    _, _, rec1, _ = run_batch(enc, fd1, 0, 6, dim, domain_id=1)
    assert rec1 is None, "fresh domain context must start with empty context"
    assert enc.ctxs[0].stream_tracker.event_dt_valid.any(), "domain 0 state must survive"

    # both domains accumulate independently
    run_batch(enc, fd1, 6, 12, dim, domain_id=1)
    assert enc.ctxs[1].stream_tracker.event_dt_valid.any()
    print("[ok] per-domain streaming contexts are independent")


def test_multi_domain_checkpoint_selects_target_context(tmp_path):
    ctx0 = DomainContext(num_nodes=12, device="cpu", neighbor_size=5)
    ctx1 = DomainContext(num_nodes=12, device="cpu", neighbor_size=5)
    source = build_encoder(12, 8, 10, domain_ctxs={0: ctx0, 1: ctx1})
    fd = make_full_data(num_nodes=12, num_events=8, dim=8, seed=41)
    run_batch(source, fd, 0, 8, 8, domain_id=1)

    class Wrapper(nn.Module):
        def __init__(self, encoder):
            super().__init__()
            self.encoder = encoder

    save_model(Wrapper(source), str(tmp_path))
    target = Wrapper(build_encoder(12, 8, 10))
    load_model(target, str(tmp_path), domain_id=1)
    assert target.encoder.ctxs[0].neighbor_loader.cur_e_id == 8
    assert target.encoder.ctxs[0].stream_tracker.event_dt_valid.numel() > 0
    print("[ok] multi-domain checkpoint restores the selected target stream")


# ------------------------------------------------------ end-to-end with DANN
def test_end_to_end_forward_with_dann_and_bridge():
    dim = 8
    fd0 = make_full_data(num_nodes=12, num_events=24, dim=dim, seed=21)
    fd1 = make_full_data(num_nodes=12, num_events=24, dim=dim, seed=22)
    ctx0 = DomainContext(num_nodes=12, device="cpu", neighbor_size=5)
    ctx1 = DomainContext(num_nodes=12, device="cpu", neighbor_size=5)
    disc = DomainDiscriminator(in_dim=dim, hid_dim=16, num_domains=2, lam=1.0)
    enc = build_encoder(12, dim, 10, seed=0, mask_rate=0.5,
                        sampling_prior="bridge", bridge_strength=1.0,
                        domain_ctxs={0: ctx0, 1: ctx1}, domain_disc=disc)

    for d, fd in ((0, fd0), (1, fd1)):
        run_batch(enc, fd, 0, 12, dim, domain_id=d)
        h_src, h_dst, recovery, dom_loss = run_batch(enc, fd, 12, 24, dim, domain_id=d)
        assert recovery is not None, "masked context events expected"
        assert dom_loss is not None and dom_loss.requires_grad, "domain loss expected"
        dom_loss.backward()
        assert any(p.grad is not None for p in disc.parameters())
        # bridge diagnostics present (bridge_strength > 0)
        assert "bridge_mean_masked" in enc._last_mask_stats
        # leak diagnostics present (track_triple_dups=True)
        assert "triple_dup_frac" in enc._last_mask_stats
        # domain accuracy diagnostic present
        assert "domain_acc" in enc._last_domain_stats
    print("[ok] end-to-end forward: bridge prior + DANN domain loss + diagnostics")


if __name__ == "__main__":
    test_gaps_match_reference()
    test_gaps_consistency_with_stream_tracker()
    test_bridge_prior_upweights_isolated_groups()
    test_bridge_requires_both_temporal_sides()
    test_bridge_gap_scope_excludes_holdout_events()
    test_triple_dup_diagnostics_and_arc_group_removal()
    test_randomized_masking_has_zero_residual_arc_leaks()
    test_mask_unit_ablation_exposes_and_closes_duplicate_copying()
    test_gradient_reversal_and_discriminator()
    test_discriminator_learns_separable_domains()
    test_dual_domain_adversary_backpropagates_both_heads()
    test_attr_dropout_erases_attributes()
    test_attr_dropout_disabled_preserves_attributes()
    test_attr_dropout_is_node_consistent_across_endpoint_roles()
    test_presence_bits()
    test_structure_mode_excludes_collector_missingness()
    test_canonical_hash_is_shared_and_reproducible()
    test_multi_domain_context_switching()
    test_multi_domain_checkpoint_selects_target_context(tmp_path=Path("/tmp/orthrus-test-ctx"))
    test_end_to_end_forward_with_dann_and_bridge()
    print("\nAll Paper-2 mechanism tests passed.")
