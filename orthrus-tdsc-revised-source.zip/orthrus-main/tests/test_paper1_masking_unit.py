"""Dependency-light unit tests for Paper-1 temporal masking primitives.
Run: python tests/test_paper1_masking_unit.py
"""
import sys
from pathlib import Path

import torch

# Make direct invocation (`python tests/test_paper1_masking_unit.py`) work from
# the repository root without requiring an external PYTHONPATH setting.
REPO_ROOT = Path(__file__).resolve().parents[1]
if str(REPO_ROOT) not in sys.path:
    sys.path.insert(0, str(REPO_ROOT))

from src.masking import StreamTimeTracker, ContextEventMasker


def test_stream_gaps_include_previous_events_in_same_batch():
    # Deliberately repeated endpoints inside one batch. The reference loop is
    # the exact event-by-event definition used by the temporal prior/target.
    src = torch.tensor([0, 1, 0, 2, 1, 0])
    dst = torch.tensor([1, 2, 2, 0, 0, 1])
    t = torch.tensor([10, 20, 30, 40, 50, 60], dtype=torch.long)
    tracker = StreamTimeTracker(num_nodes=3, device="cpu", init_capacity=8)
    got_dt, got_valid = tracker.observe(src, dst, t, first_e_id=0, cur_e_id=len(t))

    last = [-1, -1, -1]
    expected_dt, expected_valid = [], []
    for i in range(len(t)):
        prev = max(last[int(src[i])], last[int(dst[i])])
        valid = prev >= 0
        expected_valid.append(valid)
        expected_dt.append((max(0, int(t[i]) - prev) / 1e9) if valid else 0.0)
        last[int(src[i])] = max(last[int(src[i])], int(t[i]))
        last[int(dst[i])] = max(last[int(dst[i])], int(t[i]))
    assert torch.allclose(got_dt, torch.tensor(expected_dt), atol=1e-12)
    assert got_valid.tolist() == expected_valid


def test_arc_group_hides_all_entries_but_supervises_unique_events():
    # Event IDs 1 and 2 appear twice because each endpoint can expose an
    # adjacency entry. Arc keys 10 and 20 are selected as whole groups.
    eids = torch.tensor([0, 1, 1, 2, 2, 3, 4, 4, 5])
    arc = torch.tensor([10, 20, 20, 20, 20, 30, 40, 40, 50])
    dt = torch.arange(6, dtype=torch.float32)
    valid = torch.ones(6, dtype=torch.bool)
    masker = ContextEventMasker(mask_rate=0.5, sampling_prior="uniform",
                                generator=torch.Generator().manual_seed(17))
    out = masker.sample(eids, arc, dt, valid)
    masked = out["masked_eids"].tolist()
    assert len(masked) == len(set(masked)), "repeated adjacency entries duplicated targets"
    for eid in masked:
        assert not out["keep"][eids == eid].any(), "a hidden event leaked via another adjacency entry"
    assert out["masked_group_rep_eids"].numel() == out["group_size"].numel()


if __name__ == "__main__":
    test_stream_gaps_include_previous_events_in_same_batch()
    test_arc_group_hides_all_entries_but_supervises_unique_events()
    print("Paper-1 masking primitive tests passed.")
