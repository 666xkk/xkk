# Paper 2 mechanisms: leak-tight masking, bridge prior, cross-collector invariance

This document describes three mechanisms implemented on top of ORTHRUS
(Paper 1), why they are needed, what was already present vs. newly added, the
exact config surface, and the ablation protocol that makes them defensible at
a top venue (USENIX Security-class).

---

## 1. Masking unit = unique event group (leak-tight)

**Problem.** If the context-event masker samples *individual event slots*, a
masked edge can still be copied from a duplicate of the same `(src, dst, type)`
left visible in the context (the neighbor loader may expose one event through
both endpoint histories, and repeated events of the same arc are common). The
link head then "cheats" and learns nothing.

**Status.** Already implemented in `src/masking.py` as **v2 arc-group masking**:
the sampling unit is the *unordered node pair* `{u,v}`, and **all** context
entries between `u` and `v` — both orientations, all edge types, all duplicated
events — are removed together. This is strictly stronger than `(src,dst,type)`
grouping. The `hard` prior additionally up-weights arcs whose evidence is
unique/irreplaceable (`group_size == 1`).

**What this patch adds.** Measurable leak-tightness diagnostics, so the claim is
an evidence table rather than an assertion:
- `entries_triple_dup_frac` / `triple_dup_frac`: fraction of context entries /
  distinct `(src,dst,type)` triples that are duplicated in the context
  (i.e. the residual exposure *before* masking).
- `frac_groups_with_dups`, `events_per_masked_group`: arc-group dedup coverage.

**Key config:** `detection.gnn_training.mask.sampling_prior` (`uniform |
temporal | hard | bridge`), `prior_strength`.

For the masking-unit ablation use `detection.gnn_training.mask.unit`:
`entry` (leaky context-slot baseline), `directed_typed` (all repeated
`src,dst,type` events), or `unordered_pair` (the proposed strongest unit).
`residual_triple_copy_count` directly measures whether a masked answer remains
visible.

---

## 2. Temporal prior upgraded to "bridge first"

**Problem.** The prior `temporal` prior is a *log-gap-biased sampler* over the
backward inter-arrival gap only. It does not identify *temporal bridges* — the
events that sit in a temporal hole for their endpoints, where both the previous
and the next endpoint occurrence are far away. Those are exactly the events
that can only be recovered by genuine long-range temporal reasoning (everything
else can be interpolated/copied from a close neighbor).

**What this patch adds.**
- `compute_event_endpoint_gaps(src, dst, t)` in `src/masking.py`: offline,
  vectorized prev/next endpoint gaps over the full training corpus, mirroring
  `StreamTimeTracker.observe` exactly (verified by a unit test).
- Both sides must be valid: stream-boundary events are ineligible. The gap
  cache is explicitly truncated at `full_data.train_event_count`, preventing
  validation/test events from affecting the curriculum.
- A **bridge score** per arc group: `min(log1p(prev_gap), log1p(next_gap))`,
  normalized over the context. The `bridge` sampling prior weights masks by
  `(1 + bridge_strength * bridge_score)` on top of the temporal base, so the
  curriculum concentrates on temporally isolated events.
- Diagnostics: `bridge_mean_ctx`, `bridge_mean_masked` (selection bias of the
  prior), `bridge_top_frac` (fraction of masked groups in the top bridge
  half).

**Design decision (important for the paper).** The bridge score is computed
*offline over the training corpus* and used **only** to choose which events to
mask (a curriculum). No future information enters any reconstruction target:
the time head remains supervised on the **causal** backward gap. Masking does
not run at inference. This keeps the detection-time model strictly causal while
the pretraining curriculum is non-causal — state this explicitly to preempt a
reviewer objection.

**Key config:** `detection.gnn_training.mask.bridge_strength` (`>0` composes
with any prior; `sampling_prior: bridge` implies it).

---

## 3. Cross-collector invariance (THEIA / CADETS / CLEARSCOPE)

**Problem.** Attribute completeness differs wildly across collectors (CADETS has
many `path=None`, Android lacks classic paths). The word2vec node features are
trained per dataset, so a missing attribute is treated as a *legitimate token*
(`"None"`), and there is no mechanism to (a) represent absence explicitly or
(b) make the encoder invariant to the collector. This is the root cause the
CADETS→THEIA zero-shot transfer failure (FPR ~400x) is expected to expose.

**What this patch adds.**

1. **Attribute abstraction layer** (`src/attr_schema.py`):
   - One canonical schema over the three node types (`subject: path, cmd_line`,
     `file: path`, `netflow: remote_ip, remote_port`) shared by every collector.
   - A per-node **presence bitmask** over the four canonical attributes,
     emitted as a one-hot **missingness channel** (16 dims) appended to the node
     features. The GNN can now condition on *what evidence exists*.
   - A shared `__missing__` token replacing every absent value in the word2vec
     tokenizers, so absence is represented identically across collectors instead
     of as collector-specific strings.
   - Optional `canonical_hash` features place identical tokens in identical,
     deterministic coordinates across collectors. Independently trained
     Word2Vec spaces must not be used as evidence of semantic alignment.

2. **Attribute dropout** (`domain_invariance.attr_dropout`): during training,
   blank the attribute block + zero the presence channel of a random subset of
   batch nodes. This simulates collectors that report fewer attributes and
   forces reliance on structure + time. (The node-type block is deliberately
   kept — type is universally available.)

3. **Domain-invariance training** (`src/domain_invariance.py`): independent
   collector and day DANN heads operate jointly through gradient reversal. They
   receive current-event endpoint embeddings, avoiding incorrect day labels on
   historical context nodes. Per-head losses and accuracies are logged.

4. **Pure structural branch** (`encoder.node_feature_mode: structure`): node
   features = node type only (no lexical or presence features). This branch is
   collector-invariant *by construction* and supports zero-shot transfer to a
   new collector without any attribute-vocabulary mismatch. `both` fuses it
   with the attribute branch.

5. **Joint multi-collector training** (`detection.gnn_training.multi_domain`,
   e.g. `"THEIA_E3,CADETS_E3,CLEARSCOPE_E3"`): one shared encoder + per-domain
   streaming contexts (own node space, neighbor window, time tracker), swept
   per epoch with the collector as the discriminator domain.

**Key config:**
- `edge_featurization.embed_edges.add_missingness` / `missingness_dim` (the
  presence channel; changing these changes the artifact hash → rebuild).
- `edge_featurization.embed_nodes.feature_word2vec.tokenize_missing` (shared
  `__missing__` token).
- `detection.gnn_training.encoder.node_feature_mode` (`attributes | structure |
  both`).
- `detection.gnn_training.domain_invariance.{enabled, domain_label, loss_weight,
  grad_weight, discriminator_hid, attr_dropout}`.
- `detection.gnn_training.multi_domain`.

---

## Ablation protocol (for the paper)

Every mechanism must be compared under **matched seeds / data splits /
checkpoint-selection / thresholding**, at least 3 seeds, reporting mean ± std:

1. **Leak-tightness (mech 1):** report `entries_triple_dup_frac` and
   `events_per_masked_group` for the retained context; show that a masked arc
   has zero residual visible copies. Ablate `uniform` vs `temporal` vs `hard`
   vs `bridge` on stage-1 masked-reconstruction loss and stage-2 AP/F1/FPR.
2. **Bridge prior (mech 2):** report `bridge_mean_masked / bridge_mean_ctx`
   (prior selection bias) and `bridge_top_frac`; ablate `temporal` vs `bridge`
   at fixed `mask_rate`. The expected claim is *not* "bridge always wins AP" but
   "bridge concentrates supervision on the events that are impossible to copy,
   improving downstream detection under temporal drift / at low FPR."
3. **Cross-collector invariance (mech 3):**
   - Intra-collector: `domain_invariance.enabled` on/off with day labels; show
     `domain_acc` falls toward chance while detection AP holds.
   - Cross-collector: `multi_domain` joint training vs per-domain training,
     evaluated on the existing 2x2 transfer matrix (CADETS→THEIA etc.); the
     expected claim is that invariance + attribute abstraction shrinks the
     FPR blowup, while the pure-structure branch provides a lower-bound that is
     unaffected by attribute drift.
   - Attribute dropout: sweep `attr_dropout` and show robustness to held-out
     attribute missingness.

## Honest limitations to state

- The bridge score is a *temporal* bridge, not a graph-theoretic bridge (edge
  whose removal disconnects the graph). Do not conflate them; if the paper
  claims "bridge", define it as "temporal bridge" explicitly.
- DANN is a soft regularizer, not a proof of invariance; report the
  discriminator accuracy and a held-out-domain evaluation rather than claiming
  distribution-free invariance.
- Attribute dropout is per-node and stochastic; a node appearing in context
  but not as a current-batch endpoint retains its (un-dropped) cached feature
  until it next appears. This is standard feature-dropout behavior, but the
  ablation should report the effective dropout rate over nodes.
- Multi-collector joint training requires all three databases/edge-embeds
  available in one process; the code path is implemented and unit-tested on
  synthetic data but end-to-end training needs the datasets.
