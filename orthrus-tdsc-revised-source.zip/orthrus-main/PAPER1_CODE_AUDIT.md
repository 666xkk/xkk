# ORTHRUS Paper 1: code audit and corrective changes

Scope: Paper 1 only. `paper2/` was not modified.

## Summary

The original code had real implementation inconsistencies that could plausibly explain why the ablations did not show the expected benefit. The fixes below correct objective/target alignment and temporal-gap computation; they do **not** guarantee higher AP/F1, and should not be described as a performance improvement until controlled experiments confirm it.

## Files changed

### 1. `src/masking.py`

- `StreamTimeTracker.observe`: previously computed every event's gap against `last_time` from the preceding batch, then updated node times once after the batch. Earlier events within the same batch were ignored. Since batches contain many events, this makes the supposedly event-level gap target and temporal sampling prior inaccurate. The new implementation orders endpoint occurrences by node and event index, computes each event's prior endpoint times within the batch, then updates cross-batch state.
- Arc-group sizes: previously counted adjacency slots. `LastNeighborLoader` may expose one event in both endpoint histories, so a single event could look like duplicated evidence. Group size now counts distinct `(arc group, event ID)` pairs.
- Temporal group score: previously used the first representative event's gap. That representative might have an invalid/short gap while another event in the same group had a valid/larger gap. The sampler now aggregates the maximum valid gap per arc group for sampling.
- Reconstruction targets: masking removes the whole unordered endpoint-pair group, but previously only one representative event per group was supervised for type/time reconstruction. The sampler now returns all unique event IDs hidden by selected groups for event-type/time recovery, while retaining one representative per group for link recovery.
- Deduplication: repeated adjacency entries no longer duplicate event-level reconstruction targets.

### 2. `src/encoders.py`

- Separates event-level targets (all unique hidden events) from link targets (one endpoint pair per masked arc group).
- Link loss now uses `link_h_u`/`link_h_v` aligned to the per-group negative samples. This avoids shape/semantic mismatch after correcting event-level target coverage.

### 3. `src/model.py`

- Uses the group-level embeddings for link recovery and event-level embeddings for masked type/time recovery.

### 4. `src/detection/orthrus_gnn_training.py`

- Makes stage-1 checkpoint loading explicit and safer: accepts either the trained-models directory or a specific `model_epoch_N` directory, selects the highest numeric epoch with an existing checkpoint, checks tensor shapes, and refuses to silently proceed if no encoder parameters can be loaded.
- This addresses a reproducibility risk, not a claim that the old run necessarily loaded the wrong checkpoint.

### 5. `src/config.py`

- Updates the documented allowed sampling-prior values to include the already implemented `hard` option.

### 6. `tests/test_paper1_masking_unit.py`

- New dependency-light tests compare batch gap computation against an event-by-event reference and verify that duplicate adjacency entries do not leak a masked event or duplicate targets.

## Validation performed here

- `python -m py_compile src/masking.py src/encoders.py src/model.py src/detection/orthrus_gnn_training.py src/config.py`: passed.
- `PYTHONPATH=. python tests/test_paper1_masking_unit.py`: passed.
- Existing `check_masking.py` could not be run in this execution environment because `torch_geometric` is not installed here. Run it in the project's training environment, along with `PYTHONPATH=. python tools/mask_smoke.py CADETS_E3`.
- No end-to-end training/evaluation was run here, so no new AP/F1 claims are made.

## Important methodological qualification

The current `temporal` prior is a **log-gap-biased sampler**. It does not compute graph-theoretic bridges (edges whose removal disconnects a graph). If “bridge event” in the paper means a true structural bridge, that is still not implemented and needs an explicit definition plus a separate ablation. Do not claim the current temporal prior detects graph bridges.

## Recommended experiment protocol

1. First run the primitive tests above and `check_masking.py`/`mask_smoke.py` in the actual ORTHRUS environment.
2. Compare `uniform` versus `temporal` with identical seeds, epochs, learning rate, masking rate, checkpoint-selection rule, and evaluation thresholding.
3. Use at least three seeds and report mean ± standard deviation for AP, recall, F1, FPR, plus masked-group coverage and valid time-target fraction.
4. For two-stage training, log the exact stage-1 checkpoint path and the number of encoder tensors loaded; compare against a same-compute no-pretraining control.
5. Do not increase prior strength or change loss weights solely to make the proposed method win; first confirm the mechanism is correct and then report null results honestly if they persist.
