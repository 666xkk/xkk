# ORTHRUS Paper-1 audit patch notes

This patch is intentionally conservative: it fixes observability and an incorrect
masking diagnostic without changing the intended learning objective or model
architecture.

## Changes

1. `src/detection/orthrus_gnn_training.py` logs the effective mask configuration
   at startup (`[mask-config]`). For stage-1, verify `enabled=True`, the intended
   prior, `mask_rate=0.15`, and the intended loss weights before trusting a run.
2. `src/encoders.py` previously logged `masked_eids.numel()` as
   `n_groups_masked`. That value counts unique event targets, not selected
   unordered node-pair groups. It now logs the actual group count as
   `n_groups_masked`, and adds `n_events_masked` and
   `events_per_masked_group`. This changes the meaning/value of that diagnostic;
   do not compare new `n_groups_masked` directly with historical values produced
   by the old mislabeled implementation. `frac_groups_with_dups` remains the
   fraction of selected arc groups containing more than one distinct event.
3. `scripts/run_paper1_stage1_checks.sh` makes `mask.enabled=true` explicit and
   checks the effective configuration in the resulting log.

## What this patch does not claim

- It does not establish that temporal sampling is superior to uniform sampling.
- It does not automatically select a stage-1 checkpoint for stage-2. Record the
  exact `trained_models` path produced by each stage-1 run and pass that path to
  the matching stage-2 command; do not rely on `ls -dt ... | head -1` if runs can
  overlap or if old runs are being touched.
- The full CADETS_E3 experiment was not run in this environment because it needs
  the user's dataset/database, model dependencies, and GPU/runtime setup.

## Validation performed

- Python bytecode compilation of `src` and `tests`.
- `PYTHONPATH=. python tests/test_paper1_masking_unit.py`.

For a defensible comparison, run B0, uniform, and temporal with matched seeds,
identical data splits and evaluation configuration; repeat across multiple seeds.
4. `scripts/run_paper1_stage2.sh` requires an explicit `S1_DIR`, checks that it
   contains checkpoints, and surfaces the checkpoint-load confirmation. This
   avoids silently selecting a stale stage-1 directory with a broad `ls -dt`.
