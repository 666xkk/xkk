"""G1 checks for context-event masked modeling.

Run (inside the project environment):  python check_masking.py

Verifies:
  1. first batch (empty context): no masking;
  2. masking is per-forward and removes events from THIS forward's aggregation
     (masked ids absent from the visible ids; counts consistent);
  3. recovery payload matches the masked set;
  4. link negatives exclude visible neighbours and the true destination;
  5. inference performs NO masking;
  6. same seed -> identical masks (determinism).
"""
import os
import sys

REPO = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(REPO, "src"))

import torch
import torch.nn.functional as F
from torch_geometric.data import Data

from src.temporal import LastNeighborLoader
from src.masking import ContextEventMasker
from src.encoders import OrthrusEncoder, LinearEncoder
from src.data_utils import GraphReindexer


def make_full_data(num_nodes=12, num_events=24, dim=8, num_edge_types=10, seed=0):
    g = torch.Generator().manual_seed(seed)
    src = torch.randint(0, num_nodes, (num_events,), generator=g)
    dst = torch.randint(0, num_nodes, (num_events,), generator=g)
    t = torch.arange(num_events, dtype=torch.long) * 1_000_000_000
    edge_type = F.one_hot(torch.randint(0, num_edge_types, (num_events,), generator=g),
                          num_edge_types).float()
    msg = torch.randn(num_events, dim, generator=g)
    return Data(msg=msg, t=t, edge_type=edge_type, src=src, dst=dst)


def build_encoder(num_nodes, dim, num_edge_types, seed=0, mask_rate=0.5,
                  sampling_prior="uniform", link_negatives=4):
    device = torch.device("cpu")
    loader = LastNeighborLoader(num_nodes=num_nodes, size=5, device=device)
    inner = LinearEncoder(in_dim=dim, hid_dim=16, out_dim=dim)
    gen = torch.Generator(device=device).manual_seed(seed)
    masker = ContextEventMasker(mask_rate=mask_rate, sampling_prior=sampling_prior,
                                prior_strength=1.0, generator=gen)
    return OrthrusEncoder(
        encoder=inner,
        neighbor_loader=loader,
        in_dim=dim,
        temporal_dim=dim,
        use_node_feats_in_gnn=True,
        graph_reindexer=GraphReindexer(num_nodes=num_nodes, device=device),
        edge_features=["edge_type"],
        device=device,
        num_nodes=num_nodes,
        edge_dim=num_edge_types,
        use_time_features=False,
        masker=masker,
        link_negatives=link_negatives,
    )


def run_batch(enc, full_data, lo, hi, dim, inference=False):
    bi = torch.arange(lo, hi)
    e = bi.numel()
    x_src = torch.randn(e, dim, generator=torch.Generator().manual_seed(123))
    x_dst = torch.randn(e, dim, generator=torch.Generator().manual_seed(456))
    h_src, h_dst, recovery, domain_loss = enc.forward(
        edge_index=torch.stack([full_data.src[bi], full_data.dst[bi]]),
        t=full_data.t[bi], msg=full_data.msg[bi], x=(x_src, x_dst),
        full_data=full_data, inference=inference)
    assert domain_loss is None, "no domain discriminator configured in G1 checks"
    return h_src, h_dst, recovery


def main():
    dim = 8

    # -------- 1/2/3: removal semantics --------
    fd = make_full_data(seed=7)
    enc = build_encoder(12, dim, 10, seed=0, mask_rate=0.5)
    _, _, rec1 = run_batch(enc, fd, 0, 12, dim)
    assert rec1 is None, "first batch has empty context -> no masking expected"
    assert enc.last_all_e_id.numel() == 0

    _, _, rec2 = run_batch(enc, fd, 12, 24, dim)
    assert rec2 is not None and rec2["masked_eids"].numel() > 0, \
        "no context events sampled; increase mask_rate or change data seed"
    all_e, vis_e, masked = enc.last_all_e_id, enc.last_visible_e_id, rec2["masked_eids"]
    assert torch.isin(masked, all_e).all(), "masked ids must come from the context"
    assert not torch.isin(masked, vis_e).any(), "masked events leaked into aggregation"
    expected_visible = all_e[~torch.isin(all_e, masked)]
    assert vis_e.numel() == expected_visible.numel(), "visible count mismatch"
    assert rec2["h_u"].size(0) == masked.numel() == rec2["dt"].numel()
    print(f"[ok] masking removes {masked.numel()} events "
          f"({all_e.numel()} context entries -> {vis_e.numel()} left)")

    # -------- 4: filtered negatives --------
    fd2 = make_full_data(seed=3)
    enc2 = build_encoder(12, dim, 10, seed=0, mask_rate=0.5, link_negatives=4)
    captured = {}
    orig = enc2._sample_negatives

    def spy(vei, ul, vl, n):
        out = orig(vei, ul, vl, n)
        captured["args"] = (vei.clone(), ul.clone(), vl.clone())
        captured["out"] = (out[0].clone(), out[1].clone())
        return out

    enc2._sample_negatives = spy
    run_batch(enc2, fd2, 0, 12, dim)
    run_batch(enc2, fd2, 12, 24, dim)
    assert "out" in captured, "no masked events were sampled for the negative test"
    vei, ul, vl = captured["args"]
    cand, valid = captured["out"]
    adj = set()
    for a, b in zip(vei[0].tolist(), vei[1].tolist()):
        adj.add((a, b)); adj.add((b, a))
    for i in range(ul.numel()):
        for k in range(cand.size(1)):
            if bool(valid[i, k]):
                u, c, v = int(ul[i]), int(cand[i, k]), int(vl[i])
                assert c != v, "negative equals true destination"
                assert c != u, "negative equals source"
                assert (u, c) not in adj and (c, u) not in adj, \
                    "negative is a visible neighbour (false negative)"
    print("[ok] filtered negatives exclude visible neighbours and true destination")

    # -------- 5: no masking at inference --------
    fd3 = make_full_data(seed=11)
    enc3 = build_encoder(12, dim, 10, seed=0, mask_rate=0.5)
    run_batch(enc3, fd3, 0, 12, dim, inference=True)
    _, _, rec = run_batch(enc3, fd3, 12, 24, dim, inference=True)
    assert rec is None, "masking must not run at inference"
    assert enc3.last_visible_e_id.numel() == enc3.last_all_e_id.numel()
    print("[ok] no masking at inference")

    # -------- 6: determinism --------
    fd4 = make_full_data(seed=5)
    enc_a = build_encoder(12, dim, 10, seed=42, mask_rate=0.5)
    enc_b = build_encoder(12, dim, 10, seed=42, mask_rate=0.5)
    run_batch(enc_a, fd4, 0, 12, dim); _, _, ra = run_batch(enc_a, fd4, 12, 24, dim)
    run_batch(enc_b, fd4, 0, 12, dim); _, _, rb = run_batch(enc_b, fd4, 12, 24, dim)
    assert ra is not None and rb is not None
    assert torch.equal(ra["masked_eids"], rb["masked_eids"]), "masking is not deterministic for a fixed seed"
    print("[ok] masking is deterministic for a fixed seed")

    print("\nAll G1 checks passed.")


if __name__ == "__main__":
    main()